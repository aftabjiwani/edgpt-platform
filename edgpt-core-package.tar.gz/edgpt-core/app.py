"""
EdGPT Platform v4.0 - Consolidated Final System
Includes working Start Demo functionality for all domains with industry-specific content
Combines all features: trial forms, conversion, superadmin, modern light UX
"""

from flask import Flask, render_template_string, request, jsonify, redirect, url_for, session
from flask_cors import CORS
import requests
from bs4 import BeautifulSoup
import sqlite3
import hashlib
import secrets
import time
import json
import os
from datetime import datetime
import threading
import uuid

app = Flask(__name__)
app.secret_key = 'edgpt_platform_secret_key_2025_final'
CORS(app)

# Static file serving
@app.route('/static/<path:filename>')
def static_files(filename):
    return app.send_static_file(filename)

# Configure static folder
app.static_folder = '/home/ubuntu/static'

# Database setup
def init_db():
    conn = sqlite3.connect('edgpt_platform.db')
    c = conn.cursor()
    
    # Users table
    c.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        email TEXT NOT NULL,
        school_name TEXT NOT NULL,
        admin_name TEXT NOT NULL,
        admin_title TEXT NOT NULL,
        website_url TEXT NOT NULL,
        student_count TEXT NOT NULL,
        staff_name TEXT,
        staff_department TEXT,
        staff_email TEXT,
        staff_phone TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        gptsite_id TEXT UNIQUE,
        custom_domain TEXT,
        status TEXT DEFAULT 'active',
        is_admin BOOLEAN DEFAULT 0,
        user_type TEXT DEFAULT 'trial',
        revenue REAL DEFAULT 0.0
    )''')
    
    # Trial requests table
    c.execute('''CREATE TABLE IF NOT EXISTS trial_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        conversion_id TEXT UNIQUE NOT NULL,
        school_name TEXT NOT NULL,
        admin_name TEXT NOT NULL,
        admin_title TEXT NOT NULL,
        email TEXT NOT NULL,
        website_url TEXT NOT NULL,
        student_count TEXT NOT NULL,
        staff_name TEXT,
        staff_department TEXT,
        staff_email TEXT,
        staff_phone TEXT,
        status TEXT DEFAULT 'processing',
        progress INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        completed_at TIMESTAMP,
        converted_to_customer BOOLEAN DEFAULT 0
    )''')
    
    # Analytics table
    c.execute('''CREATE TABLE IF NOT EXISTS analytics (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        domain TEXT NOT NULL,
        visitor_count INTEGER DEFAULT 0,
        chat_count INTEGER DEFAULT 0,
        sentiment TEXT DEFAULT 'neutral',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')
    
    # Create admin user if not exists
    c.execute("SELECT * FROM users WHERE email = 'admin@edgpt.ai'")
    if not c.fetchone():
        admin_password = hashlib.sha256('admin123'.encode()).hexdigest()
        c.execute('''INSERT INTO users 
                    (username, password_hash, email, school_name, admin_name, admin_title, 
                     website_url, student_count, is_admin, user_type, revenue) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                 ('admin', admin_password, 'admin@edgpt.ai', 'EdGPT Admin', 'System Admin', 
                  'Administrator', 'https://edgpt.ai', 'N/A', 1, 'admin', 0.0))
    
    conn.commit()
    conn.close()

# Initialize database
init_db()

def get_domain_config(host):
    """Get domain-specific configuration with industry-specific demo content"""
    domain_configs = {
        'edgpt.ai': {
            'title': 'EdGPT - Transform Your School Website Into an Intelligent AI Assistant',
            'subtitle': 'Educational platform for schools',
            'platform_type': 'EdGPT',
            'support_email': 'support@edgpt.ai',
            'demo_questions': [
                'What time does school start and end?',
                'What\'s on the lunch menu today?',
                'How do I report my child absent?',
                'What\'s your anti-bullying policy?'
            ],
            'demo_answers': [
                'Our school day runs from 8:00 AM to 3:15 PM, Monday through Friday. Early drop-off is available starting at 7:30 AM for working parents.',
                'Today\'s lunch menu includes: Pizza slices, chicken nuggets with honey mustard, fresh garden salad, steamed broccoli, fruit cups, and chocolate milk. We also have vegetarian and gluten-free options available.',
                'You can report an absence by calling our main office at (555) 123-4567 before 9:00 AM, or use our online portal at portal.school.edu. Please include your child\'s name, grade, and reason for absence.',
                'We have a zero-tolerance policy for bullying. All incidents are investigated within 24 hours. Students can report bullying to any teacher, counselor, or through our anonymous tip line. We focus on education, intervention, and creating a safe environment for all students.'
            ],
            'welcome_message': 'Hello! Welcome to our school. I\'m your AI assistant. How can I help you today?',
            'trial_cta': 'I\'d love to help you get started! Would you like to transform your website into an intelligent assistant like me? Click below to start your free trial!'
        },
        'gptsites.ai': {
            'title': 'GPTsites - Transform Your Business Website Into an Intelligent AI Assistant',
            'subtitle': 'Business platform for companies',
            'platform_type': 'GPTsites',
            'support_email': 'support@gptsites.ai',
            'demo_questions': [
                'What services do you offer?',
                'How much does it cost?',
                'What are your business hours?',
                'How long have you been in business?'
            ],
            'demo_answers': [
                'We offer comprehensive digital solutions including website development, AI integration, digital marketing, and business automation services. Our packages are customized to meet your specific business needs.',
                'Our pricing varies based on your specific requirements. We offer flexible packages starting from $99/month for basic services, with enterprise solutions available. We\'d be happy to provide a custom quote based on your needs.',
                'We\'re open Monday through Friday, 9:00 AM to 6:00 PM EST. Our AI assistant and support portal are available 24/7 for your convenience. You can also schedule appointments outside regular hours.',
                'We\'ve been helping businesses transform digitally for over 8 years. We\'ve successfully completed over 500 projects and maintain a 98% client satisfaction rate. Our experience spans various industries from startups to Fortune 500 companies.'
            ],
            'welcome_message': 'Hello! Welcome to our business. I\'m your AI assistant. How can I help you today?',
            'trial_cta': 'Ready to transform your business with AI? Let\'s get started with your free consultation and see how we can help you grow!'
        },
        'lawfirmgpt.ai': {
            'title': 'LawFirmGPT - Transform Your Law Firm Website Into an Intelligent AI Assistant',
            'subtitle': 'Legal platform for law firms',
            'platform_type': 'LawFirmGPT',
            'support_email': 'support@lawfirmgpt.ai',
            'demo_questions': [
                'What types of cases do you handle?',
                'Do you offer free consultations?',
                'How much do you charge?',
                'How long will my case take?'
            ],
            'demo_answers': [
                'We specialize in personal injury, family law, criminal defense, and business litigation. Our experienced attorneys have successfully handled thousands of cases across these practice areas with proven results.',
                'Yes, we offer free initial consultations for most case types. During this 30-minute meeting, we\'ll evaluate your case, explain your legal options, and discuss potential strategies. There\'s no obligation to hire us.',
                'Our fees vary depending on the case type. We work on contingency for personal injury cases (no fee unless we win), offer flat fees for certain services, and hourly rates for complex litigation. We\'ll discuss all costs upfront during your consultation.',
                'Case duration varies significantly based on complexity and type. Simple matters may resolve in weeks, while complex litigation can take 1-2 years. We\'ll provide realistic timelines during your consultation and keep you updated throughout the process.'
            ],
            'welcome_message': 'Hello! Welcome to our law firm. I\'m your legal AI assistant. How can I help you today?',
            'trial_cta': 'Need legal assistance? Schedule your free consultation today and let our experienced attorneys help protect your rights and interests!'
        },
        'cpafirm.ai': {
            'title': 'CPAFirm - Transform Your Accounting Website Into an Intelligent AI Assistant',
            'subtitle': 'Accounting platform for CPA firms',
            'platform_type': 'CPAFirm',
            'support_email': 'support@cpafirm.ai',
            'demo_questions': [
                'Do you handle small business accounting?',
                'What are your fees?',
                'Can you help with tax preparation?',
                'How often should I update my books?'
            ],
            'demo_answers': [
                'Absolutely! We specialize in small business accounting and serve over 200 local businesses. Our services include bookkeeping, financial statements, payroll processing, and business advisory services tailored to your industry.',
                'Our fees are competitive and transparent. Monthly bookkeeping starts at $200, tax preparation from $150, and we offer comprehensive packages from $400/month. We\'ll provide a detailed quote based on your specific needs.',
                'Yes, tax preparation is one of our core services. We handle individual, business, and corporate tax returns. We stay current with all tax law changes and can help maximize your deductions while ensuring compliance.',
                'We recommend updating your books monthly for most businesses. This allows for better cash flow management, timely financial reporting, and easier tax preparation. We can set up automated systems to streamline this process.'
            ],
            'welcome_message': 'Hello! Welcome to our CPA firm. I\'m your accounting AI assistant. How can I help you today?',
            'trial_cta': 'Ready to streamline your finances? Contact us today for a free consultation and see how we can help your business thrive!'
        },
        'taxprepgpt.ai': {
            'title': 'TaxPrepGPT - Transform Your Tax Service Website Into an Intelligent AI Assistant',
            'subtitle': 'Tax preparation platform',
            'platform_type': 'TaxPrepGPT',
            'support_email': 'support@taxprepgpt.ai',
            'demo_questions': [
                'When is the filing deadline?',
                'What documents do I need?',
                'When will I get my refund?',
                'How much does tax preparation cost?'
            ],
            'demo_answers': [
                'The federal tax filing deadline is April 15th, 2025. If you need more time, we can file an extension giving you until October 15th. State deadlines may vary, and we\'ll ensure all your returns are filed on time.',
                'You\'ll need your W-2s, 1099s, receipts for deductions, last year\'s tax return, and ID. We\'ll provide a complete checklist based on your situation. Don\'t worry if you\'re missing something - we can help you obtain necessary documents.',
                'E-filed returns with direct deposit typically receive refunds within 21 days. Paper returns take 6-8 weeks. We\'ll track your refund status and notify you of any issues. Factors like errors or reviews can delay processing.',
                'Our tax preparation fees start at $75 for simple returns and vary based on complexity. Business returns start at $200. We offer upfront pricing with no hidden fees, and you\'ll know the exact cost before we begin.'
            ],
            'welcome_message': 'Hello! Welcome to our tax preparation service. I\'m your tax AI assistant. How can I help you today?',
            'trial_cta': 'Ready to file your taxes stress-free? Schedule your appointment today and let our experts maximize your refund!'
        },
        'businessbrokergpt.ai': {
            'title': 'BusinessBrokerGPT - Transform Your Brokerage Website Into an Intelligent AI Assistant',
            'subtitle': 'Business brokerage platform',
            'platform_type': 'BusinessBrokerGPT',
            'support_email': 'support@businessbrokergpt.ai',
            'demo_questions': [
                'What\'s my business worth?',
                'How long does it take to sell?',
                'What\'s your commission rate?',
                'How do you screen buyers?'
            ],
            'demo_answers': [
                'Business valuation depends on factors like revenue, profit margins, industry, assets, and market conditions. We use multiple valuation methods including asset-based, income-based, and market comparisons. We\'ll provide a comprehensive valuation analysis for free.',
                'The average business sale takes 6-12 months, but this varies by industry, size, and market conditions. Well-prepared businesses with strong financials typically sell faster. We\'ll work with you to optimize your business for a quicker sale.',
                'Our commission is typically 8-12% depending on the business size and complexity. This is only paid upon successful closing, so there are no upfront fees. Our commission structure aligns our interests with yours - we only succeed when you do.',
                'We thoroughly vet all potential buyers by checking their financial capacity, experience, and serious intent. This includes reviewing financial statements, proof of funds, and conducting detailed interviews. We only present qualified buyers to protect your time and confidentiality.'
            ],
            'welcome_message': 'Hello! Welcome to our business brokerage. I\'m your business AI assistant. How can I help you today?',
            'trial_cta': 'Ready to sell your business? Contact us today for a free business valuation and consultation to maximize your business value!'
        }
    }
    
    # Default to EdGPT if domain not found
    return domain_configs.get(host, domain_configs['edgpt.ai'])

@app.route('/')
def index():
    """Main landing page with domain-specific content"""
    host = request.headers.get('Host', 'edgpt.ai')
    config = get_domain_config(host)
    
    return render_template_string("""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ config.title }}</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
        }
        
        .hero-gradient {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        
        .text-gradient {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .demo-question {
            transition: all 0.3s ease;
            cursor: pointer;
        }
        
        .demo-question:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        
        .chat-message {
            margin-bottom: 1rem;
            padding: 0.75rem;
            border-radius: 0.5rem;
            opacity: 0;
            transform: translateY(20px);
            transition: all 0.5s ease;
        }
        
        .ai-message {
            background-color: #f3f4f6;
            border-left: 4px solid #3b82f6;
        }
        
        .user-message {
            background: linear-gradient(135deg, #a855f7 0%, #3b82f6 100%);
            color: white;
            text-align: right;
            margin-left: 2rem;
        }
        
        .trial-cta {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            color: white;
            padding: 0.75rem 1.5rem;
            border-radius: 0.5rem;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s ease;
            transform: scale(1);
        }
        
        .trial-cta:hover {
            transform: scale(1.05);
            box-shadow: 0 10px 25px rgba(16, 185, 129, 0.3);
        }
        
        #chatDemo {
            max-height: 400px;
            overflow-y: auto;
            border: 1px solid #e5e7eb;
            border-radius: 0.5rem;
            padding: 1rem;
            background: white;
            margin-bottom: 1rem;
            display: none;
        }
        
        .slide {
            display: none;
        }
        
        .slide.active {
            display: block;
        }
        
        .slide-dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background-color: #d1d5db;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        
        .slide-dot.active {
            background-color: #3b82f6;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="bg-white shadow-sm">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <h1 class="text-xl font-bold text-gradient">{{ config.platform_type }}</h1>
                </div>
                <div class="flex items-center space-x-8">
                    <a href="#features" class="text-gray-700 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium">Features</a>
                    <a href="#demo" class="text-gray-700 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium">Demo</a>
                    <a href="#trial" class="text-gray-700 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium">Pricing</a>
                    <a href="#contact" class="text-gray-700 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium">Contact</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-gradient text-white py-20">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 class="text-5xl font-bold mb-6">{{ config.title }}</h1>
            <p class="text-xl mb-8 max-w-3xl mx-auto">Transform your static website into an intelligent AI assistant that engages visitors 24/7, captures leads automatically, and provides instant answers to customer questions.</p>
            <a href="#trial" class="bg-white text-blue-600 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-gray-100 transition">Transform Your Website Now</a>
        </div>
    </section>

    <!-- Revolutionary Headline -->
    <section class="py-16 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 class="text-6xl font-bold text-gradient mb-4">Websites are a thing of the past</h2>
            <p class="text-xl text-gray-600 mb-12">70% of visitors prefer search over navigation</p>
            
            <div class="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
                <div class="bg-red-50 border-2 border-red-200 rounded-lg p-6">
                    <div class="text-4xl mb-4">🌐</div>
                    <h3 class="text-xl font-semibold mb-3">Traditional Websites</h3>
                    <p class="text-gray-700">Static pages, complex navigation, one-to-many communication model. Visitors struggle to find information, leading to high bounce rates and lost opportunities.</p>
                </div>
                <div class="bg-green-50 border-2 border-green-200 rounded-lg p-6">
                    {% if 'edgpt.ai' in request.headers.get('Host', '') %}
                    <div class="mb-4 flex justify-center">
                        <img src="/static/edgpt_logo.png" alt="EdGPT Logo" class="w-16 h-16 object-contain">
                    </div>
                    {% else %}
                    <div class="mb-4 flex justify-center">
                        <img src="/static/neural_logo.jpg" alt="Neural Network" class="w-16 h-16 object-contain">
                    </div>
                    {% endif %}
                    <h3 class="text-xl font-semibold mb-3">{{ config.platform_type }}</h3>
                    <p class="text-gray-700">Intelligent AI assistant, instant answers, one-on-one personalized communication. Visitors get immediate help, leading to higher engagement and conversions.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Demo Section -->
    <section id="demo" class="py-16 bg-gray-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-12">
                <h2 class="text-3xl font-bold text-gray-900 mb-4">Experience the Future</h2>
                <p class="text-xl text-gray-600">See how {{ config.platform_type }} transforms visitor interactions</p>
            </div>
            
            <div class="max-w-4xl mx-auto bg-white rounded-lg shadow-lg p-8">
                <h3 class="text-2xl font-semibold text-center mb-2">{{ config.platform_type }} AI Assistant</h3>
                <p class="text-gray-600 text-center mb-6">Watch how {{ config.platform_type }} handles real visitor questions</p>
                
                <!-- Chat Demo Area -->
                <div id="chatDemo"></div>
                
                <!-- Demo Questions -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    <div class="demo-question bg-pink-100 p-4 rounded-lg">{{ config.demo_questions[0] }}</div>
                    <div class="demo-question bg-purple-100 p-4 rounded-lg">{{ config.demo_questions[1] }}</div>
                    <div class="demo-question bg-orange-100 p-4 rounded-lg">{{ config.demo_questions[2] }}</div>
                    <div class="demo-question bg-teal-100 p-4 rounded-lg">{{ config.demo_questions[3] }}</div>
                </div>
                
                <!-- Chat Input -->
                <div class="flex gap-2 mb-4">
                    <input type="text" placeholder="Type your question here..." class="flex-1 p-3 border border-gray-300 rounded-lg">
                    <button class="bg-purple-600 text-white px-4 py-3 rounded-lg hover:bg-purple-700">🎤</button>
                    <button class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700">Send</button>
                </div>
                
                <!-- Start Demo Button -->
                <div class="text-center">
                    <button onclick="startDemo()" class="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition">🚀 Start Demo</button>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section id="features" class="py-16 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-12">
                <h2 class="text-3xl font-bold text-gray-900 mb-4">Powerful Features</h2>
                <p class="text-xl text-gray-600">Everything you need to transform your website into an intelligent assistant</p>
            </div>
            
            <div class="grid md:grid-cols-3 gap-8">
                <div class="text-center p-6">
                    <div class="text-4xl mb-4">🤖</div>
                    <h3 class="text-xl font-semibold mb-3">AI-Powered Conversations</h3>
                    <p class="text-gray-600">Advanced natural language processing understands visitor intent and provides accurate, helpful responses in real-time.</p>
                </div>
                <div class="text-center p-6">
                    <div class="text-4xl mb-4">📱</div>
                    <h3 class="text-xl font-semibold mb-3">24/7 Availability</h3>
                    <p class="text-gray-600">Your AI assistant never sleeps, providing instant support and information to visitors around the clock.</p>
                </div>
                <div class="text-center p-6">
                    <div class="text-4xl mb-4">📊</div>
                    <h3 class="text-xl font-semibold mb-3">Lead Capture</h3>
                    <p class="text-gray-600">Automatically captures visitor information and qualifies leads through intelligent conversation flows.</p>
                </div>
                <div class="text-center p-6">
                    <div class="text-4xl mb-4">🎯</div>
                    <h3 class="text-xl font-semibold mb-3">Personalized Experience</h3>
                    <p class="text-gray-600">Adapts responses based on visitor behavior and preferences for a truly personalized experience.</p>
                </div>
                <div class="text-center p-6">
                    <div class="text-4xl mb-4">📈</div>
                    <h3 class="text-xl font-semibold mb-3">Analytics & Insights</h3>
                    <p class="text-gray-600">Detailed analytics show visitor engagement, common questions, and conversion opportunities.</p>
                </div>
                <div class="text-center p-6">
                    <div class="text-4xl mb-4">⚡</div>
                    <h3 class="text-xl font-semibold mb-3">Easy Integration</h3>
                    <p class="text-gray-600">Simple setup process gets your AI assistant live in minutes, no technical expertise required.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Results Section -->
    <section class="py-16 bg-gray-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-12">
                <h2 class="text-3xl font-bold text-gray-900 mb-4">Proven Results</h2>
                <p class="text-xl text-gray-600">See the impact {{ config.platform_type }} makes for businesses</p>
            </div>
            
            <div class="grid md:grid-cols-4 gap-8 text-center">
                <div class="bg-white p-6 rounded-lg shadow">
                    <div class="text-3xl font-bold text-blue-600 mb-2">300%</div>
                    <p class="text-gray-600">Increase in Conversions</p>
                </div>
                <div class="bg-white p-6 rounded-lg shadow">
                    <div class="text-3xl font-bold text-green-600 mb-2">80%</div>
                    <p class="text-gray-600">Reduction in Support Tickets</p>
                </div>
                <div class="bg-white p-6 rounded-lg shadow">
                    <div class="text-3xl font-bold text-purple-600 mb-2">24/7</div>
                    <p class="text-gray-600">Always Available</p>
                </div>
                <div class="bg-white p-6 rounded-lg shadow">
                    <div class="text-3xl font-bold text-orange-600 mb-2">95%</div>
                    <p class="text-gray-600">Customer Satisfaction</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Trial Form Section -->
    <section id="trial" class="py-16 bg-white">
        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-12">
                <h2 class="text-3xl font-bold text-gray-900 mb-4">Start Your Free Trial</h2>
                <p class="text-xl text-gray-600">Transform your website into an intelligent AI assistant in minutes</p>
            </div>
            
            <form id="trialForm" class="bg-gray-50 p-8 rounded-lg shadow-lg">
                <!-- Organization Information -->
                <div class="mb-8">
                    <h3 class="text-xl font-semibold mb-4">Organization Information</h3>
                    <div class="grid md:grid-cols-2 gap-4">
                        <div class="bg-blue-50 p-4 rounded">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Website URL *</label>
                            <input type="url" name="website_url" required class="w-full p-3 border border-gray-300 rounded-lg">
                        </div>
                        <div class="bg-green-50 p-4 rounded">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Organization Name *</label>
                            <input type="text" name="school_name" required class="w-full p-3 border border-gray-300 rounded-lg">
                        </div>
                        <div class="bg-purple-50 p-4 rounded">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Email Address *</label>
                            <input type="email" name="email" required class="w-full p-3 border border-gray-300 rounded-lg">
                        </div>
                        <div class="bg-orange-50 p-4 rounded" {% if 'edgpt.ai' not in request.headers.get('Host', '') %}style="display: none;"{% endif %}>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Organization Size *</label>
                            <select name="student_count" {% if 'edgpt.ai' not in request.headers.get('Host', '') %}disabled{% else %}required{% endif %} class="w-full p-3 border border-gray-300 rounded-lg">
                                <option value="">Select Size</option>
                                <option value="Small (0-1000)">Small (0-1000)</option>
                                <option value="Medium (1001-2500)">Medium (1001-2500)</option>
                                <option value="Large (2501+)">Large (2501+)</option>
                            </select>
                        </div>
                        <div class="bg-pink-50 p-4 rounded">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Administrator Name *</label>
                            <input type="text" name="admin_name" required class="w-full p-3 border border-gray-300 rounded-lg">
                        </div>
                        <div class="bg-yellow-50 p-4 rounded">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Title *</label>
                            <input type="text" name="admin_title" required class="w-full p-3 border border-gray-300 rounded-lg">
                        </div>
                    </div>
                </div>
                
                <!-- Contact Information -->
                <div class="mb-8">
                    <h3 class="text-xl font-semibold mb-4">Contact Information (Optional)</h3>
                    <div class="grid md:grid-cols-3 gap-4">
                        <div class="bg-gray-50 p-4 rounded">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Staff Name</label>
                            <input type="text" name="staff_name" class="w-full p-3 border border-gray-300 rounded-lg">
                        </div>
                        <div class="bg-gray-50 p-4 rounded">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Staff Email</label>
                            <input type="email" name="staff_email" class="w-full p-3 border border-gray-300 rounded-lg">
                        </div>
                        <div class="bg-gray-50 p-4 rounded">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Staff Phone</label>
                            <input type="tel" name="staff_phone" class="w-full p-3 border border-gray-300 rounded-lg">
                        </div>
                    </div>
                </div>
                
                <!-- Security Check -->
                <div class="mb-8">
                    <h3 class="text-xl font-semibold mb-4">Security Check</h3>
                    <div class="bg-red-50 p-4 rounded">
                        <label class="block text-sm font-medium text-gray-700 mb-2">What is 5 + 5? *</label>
                        <input type="number" name="captcha" required class="w-full p-3 border border-gray-300 rounded-lg">
                    </div>
                </div>
                
                <!-- Website Access Requirements -->
                <div class="mb-8">
                    <h3 class="text-xl font-semibold mb-4">Website Access Requirements</h3>
                    <div class="space-y-3">
                        <label class="flex items-center">
                            <input type="checkbox" name="agreement1" required class="mr-3">
                            <span class="text-sm">I understand that {{ config.platform_type }} will analyze my website content to create the AI assistant</span>
                        </label>
                        <label class="flex items-center">
                            <input type="checkbox" name="agreement2" required class="mr-3">
                            <span class="text-sm">I agree to the processing of my website data for AI training purposes</span>
                        </label>
                        <label class="flex items-center">
                            <input type="checkbox" name="agreement3" required class="mr-3">
                            <span class="text-sm">I agree to the Terms of Service and Privacy Policy</span>
                        </label>
                        <label class="flex items-center">
                            <input type="checkbox" name="agreement4" required class="mr-3">
                            <span class="text-sm">I understand the AI assistant creation process and timeline</span>
                        </label>
                    </div>
                </div>
                
                <div class="text-center">
                    <button type="submit" class="bg-blue-600 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-blue-700 transition">🚀 Create My AI Assistant</button>
                </div>
            </form>
        </div>
    </section>

    <!-- Footer -->
    <footer id="contact" class="bg-gray-900 text-white py-12">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid md:grid-cols-4 gap-8">
                <div>
                    <h3 class="text-lg font-semibold mb-4">{{ config.platform_type }}</h3>
                    <p class="text-gray-400">Transform your website into an intelligent AI assistant.</p>
                </div>
                <div>
                    <h4 class="font-bold mb-4">Product</h4>
                    <ul class="space-y-2">
                        <li><a href="#features" class="text-gray-400 hover:text-white">Features</a></li>
                        <li><a href="#demo" class="text-gray-400 hover:text-white">Demo</a></li>
                        <li><a href="#trial" class="text-gray-400 hover:text-white">Pricing</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-bold mb-4">Support</h4>
                    <ul class="space-y-2">
                        <li><a href="mailto:{{ config.support_email }}" class="text-gray-400 hover:text-white">{{ config.support_email }}</a></li>
                        <li><a href="tel:+1-650-399-9727" class="text-gray-400 hover:text-white">+1 (650) 399-9727</a></li>
                        <li><a href="/help" class="text-gray-400 hover:text-white">Help Center</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-bold mb-4">Legal</h4>
                    <ul class="space-y-2">
                        <li><a href="/technical-documentation" class="text-gray-400 hover:text-white">Technical Documentation</a></li>
                        <li><a href="/terms-of-service" class="text-gray-400 hover:text-white">Terms of Service</a></li>
                        <li><a href="/privacy-policy" class="text-gray-400 hover:text-white">Privacy Policy</a></li>
                    </ul>
                </div>
            </div>
            <div class="border-t border-gray-600 mt-12 pt-8 text-center text-gray-400">
                <div class="mb-4">
                    <p class="font-semibold">GPT AI Corporation</p>
                    <p>PO Box 2434, Fullerton CA 92837</p>
                </div>
                <p>&copy; 2025 {{ config.platform_type }}. All rights reserved.</p>
            </div>
        </div>
    </footer>
    
    <script>
        // Demo functionality with domain-specific content
        const demoMessages = [
            { type: 'ai', text: {{ config.welcome_message|tojson }} },
            { type: 'user', text: {{ config.demo_questions[0]|tojson }} },
            { type: 'ai', text: {{ config.demo_answers[0]|tojson }} },
            { type: 'user', text: {{ config.demo_questions[1]|tojson }} },
            { type: 'ai', text: {{ config.demo_answers[1]|tojson }} },
            { type: 'user', text: {{ config.demo_questions[2]|tojson }} },
            { type: 'ai', text: {{ config.demo_answers[2]|tojson }} },
            { type: 'user', text: {{ config.demo_questions[3]|tojson }} },
            { type: 'ai', text: {{ config.demo_answers[3]|tojson }} },
            { type: 'ai', text: {{ config.trial_cta|tojson }} }
        ];
        
        let messageIndex = 0;
        
        function startDemo() {
            const chatDemo = document.getElementById('chatDemo');
            if (!chatDemo) {
                console.log('chatDemo element not found');
                return;
            }
            
            chatDemo.innerHTML = '';
            chatDemo.style.display = 'block';
            messageIndex = 0;
            showNextMessage();
        }
        
        function showNextMessage() {
            if (messageIndex < demoMessages.length) {
                const message = demoMessages[messageIndex];
                const messageDiv = document.createElement('div');
                
                if (message.type === 'ai') {
                    messageDiv.className = 'chat-message ai-message';
                } else {
                    messageDiv.className = 'chat-message user-message';
                }
                
                messageDiv.textContent = message.text;
                
                // Special styling for trial CTA
                if (messageIndex === demoMessages.length - 1) {
                    messageDiv.innerHTML = '<div class="text-center mt-6"><a href="#trial" class="trial-cta">' + message.text + '</a></div>';
                }
                
                document.getElementById('chatDemo').appendChild(messageDiv);
                
                // Animate in
                setTimeout(() => {
                    messageDiv.style.opacity = '1';
                    messageDiv.style.transform = 'translateY(0)';
                }, 100);
                
                // Auto-scroll
                chatDemo.scrollTop = chatDemo.scrollHeight;
                
                messageIndex++;
                setTimeout(showNextMessage, 2500);
            }
        }
        
        // Form submission
        document.getElementById('trialForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Validate captcha
            const captcha = document.querySelector('input[name="captcha"]').value;
            if (captcha != '10') {
                alert('Please solve the math problem correctly.');
                return;
            }
            
            // Collect form data
            const formData = new FormData(this);
            
            // Submit to backend
            fetch('/submit-trial', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.location.href = '/dashboard?conversion_id=' + data.conversion_id;
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
            });
        });
        
        // Smooth scrolling for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
    </script>
</body>
</html>""", config=config)

@app.route('/submit-trial', methods=['POST'])
def submit_trial():
    """Handle trial form submission"""
    try:
        # Validate captcha
        captcha = request.form.get('captcha')
        if captcha != '10':
            return jsonify({'success': False, 'message': 'Invalid captcha'})
        
        # Generate conversion ID
        conversion_id = secrets.token_urlsafe(8)
        
        # Store trial request
        conn = sqlite3.connect('edgpt_platform.db')
        c = conn.cursor()
        
        c.execute('''INSERT INTO trial_requests 
                    (conversion_id, school_name, admin_name, admin_title, email, website_url, 
                     student_count, staff_name, staff_email, staff_phone) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                 (conversion_id, request.form.get('school_name'), request.form.get('admin_name'),
                  request.form.get('admin_title'), request.form.get('email'), request.form.get('website_url'),
                  request.form.get('student_count'), request.form.get('staff_name'), 
                  request.form.get('staff_email'), request.form.get('staff_phone')))
        
        conn.commit()
        conn.close()
        
        return jsonify({'success': True, 'conversion_id': conversion_id})
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/dashboard')
def dashboard():
    """Conversion dashboard"""
    conversion_id = request.args.get('conversion_id')
    if not conversion_id:
        return redirect('/')
    
    # Get trial request data
    conn = sqlite3.connect('edgpt_platform.db')
    c = conn.cursor()
    c.execute("SELECT * FROM trial_requests WHERE conversion_id = ?", (conversion_id,))
    trial_data = c.fetchone()
    conn.close()
    
    if not trial_data:
        return redirect('/')
    
    # Generate GPTsite ID
    gptsite_id = secrets.token_urlsafe(8)
    
    return render_template_string("""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Creating Your GPTsite - {{ trial_data[2] }}</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        .progress-bar { transition: width 0.5s ease; }
    </style>
</head>
<body class="bg-gray-50">
    <div class="min-h-screen flex items-center justify-center">
        <div class="max-w-2xl w-full mx-4">
            <div class="bg-white rounded-lg shadow-lg p-8 text-center">
                <h1 class="text-3xl font-bold text-gray-900 mb-2">Creating Your GPTsite</h1>
                <h2 class="text-xl text-blue-600 mb-8">{{ trial_data[2] }}</h2>
                
                <div class="mb-8">
                    <div class="bg-gray-200 rounded-full h-4 mb-4">
                        <div id="progressBar" class="progress-bar bg-blue-600 h-4 rounded-full" style="width: 0%"></div>
                    </div>
                    <p id="progressText" class="text-gray-600">Initializing conversion process...</p>
                </div>
                
                <div class="grid md:grid-cols-3 gap-6 mb-8">
                    <div class="text-center">
                        <div class="text-3xl font-bold text-green-600">95%</div>
                        <p class="text-sm text-gray-600">Faster Response Time</p>
                    </div>
                    <div class="text-center">
                        <div class="text-3xl font-bold text-blue-600">24/7</div>
                        <p class="text-sm text-gray-600">Always Available</p>
                    </div>
                    <div class="text-center">
                        <div class="text-3xl font-bold text-purple-600">80%</div>
                        <p class="text-sm text-gray-600">Reduced Inquiries</p>
                    </div>
                </div>
                
                <div id="accountCreation" class="hidden">
                    <h3 class="text-xl font-semibold mb-4">Create Your Account</h3>
                    <form id="accountForm" class="space-y-4">
                        <input type="hidden" name="conversion_id" value="{{ conversion_id }}">
                        <input type="hidden" name="gptsite_id" value="{{ gptsite_id }}">
                        <div class="grid md:grid-cols-2 gap-4">
                            <input type="text" name="username" value="{{ trial_data[2].lower().replace(' ', '') }}" readonly class="p-3 border border-gray-300 rounded-lg bg-gray-100">
                            <input type="email" name="email" value="{{ trial_data[5] }}" readonly class="p-3 border border-gray-300 rounded-lg bg-gray-100">
                        </div>
                        <input type="password" name="password" placeholder="Create a password" required class="w-full p-3 border border-gray-300 rounded-lg">
                        <button type="submit" class="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition">Create Account & Access Dashboard</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        let progress = 0;
        const progressBar = document.getElementById('progressBar');
        const progressText = document.getElementById('progressText');
        const accountCreation = document.getElementById('accountCreation');
        
        const steps = [
            'Analyzing website structure...',
            'Extracting content and pages...',
            'Training AI on your content...',
            'Optimizing conversation flows...',
            'Setting up your dashboard...',
            'Finalizing your GPTsite...'
        ];
        
        function updateProgress() {
            if (progress < 100) {
                progress += Math.random() * 15 + 5;
                if (progress > 100) progress = 100;
                
                progressBar.style.width = progress + '%';
                
                const stepIndex = Math.floor((progress / 100) * steps.length);
                if (stepIndex < steps.length) {
                    progressText.textContent = steps[stepIndex];
                }
                
                if (progress >= 100) {
                    progressText.textContent = 'Conversion complete! Create your account to access your dashboard.';
                    accountCreation.classList.remove('hidden');
                } else {
                    setTimeout(updateProgress, 1000 + Math.random() * 2000);
                }
            }
        }
        
        // Start progress
        setTimeout(updateProgress, 1000);
        
        // Handle account creation
        document.getElementById('accountForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('/create-account', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.location.href = '/user-dashboard?gptsite_id=' + data.gptsite_id;
                } else {
                    alert('Error: ' + data.message);
                }
            });
        });
    </script>
</body>
</html>""", trial_data=trial_data, conversion_id=conversion_id, gptsite_id=gptsite_id)

@app.route('/create-account', methods=['POST'])
def create_account():
    """Create user account after conversion"""
    try:
        conversion_id = request.form.get('conversion_id')
        gptsite_id = request.form.get('gptsite_id')
        password = request.form.get('password')
        
        # Get trial data
        conn = sqlite3.connect('edgpt_platform.db')
        c = conn.cursor()
        c.execute("SELECT * FROM trial_requests WHERE conversion_id = ?", (conversion_id,))
        trial_data = c.fetchone()
        
        if not trial_data:
            return jsonify({'success': False, 'message': 'Trial data not found'})
        
        # Create user account
        username = trial_data[2].lower().replace(' ', '')
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        
        c.execute('''INSERT INTO users 
                    (username, password_hash, email, school_name, admin_name, admin_title, 
                     website_url, student_count, staff_name, staff_email, staff_phone, gptsite_id) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                 (username, password_hash, trial_data[5], trial_data[2], trial_data[3],
                  trial_data[4], trial_data[6], trial_data[7], trial_data[8], 
                  trial_data[9], trial_data[10], gptsite_id))
        
        conn.commit()
        conn.close()
        
        return jsonify({'success': True, 'gptsite_id': gptsite_id})
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/user-dashboard')
def user_dashboard():
    """User dashboard after account creation"""
    gptsite_id = request.args.get('gptsite_id')
    if not gptsite_id:
        return redirect('/')
    
    # Get user data
    conn = sqlite3.connect('edgpt_platform.db')
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE gptsite_id = ?", (gptsite_id,))
    user_data = c.fetchone()
    conn.close()
    
    if not user_data:
        return redirect('/')
    
    return render_template_string("""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ user_data[4] }} - GPTsite Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gray-50">
    <div class="min-h-screen">
        <!-- Header -->
        <header class="bg-white shadow">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between h-16">
                    <div class="flex items-center">
                        <h1 class="text-xl font-bold text-blue-600">{{ user_data[4] }} GPTsite</h1>
                    </div>
                    <div class="flex items-center space-x-4">
                        <span class="text-gray-700">Welcome, {{ user_data[5] }}</span>
                        <span class="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm">Active</span>
                    </div>
                </div>
            </div>
        </header>
        
        <!-- Dashboard Content -->
        <main class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
            <div class="px-4 py-6 sm:px-0">
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <div class="bg-white overflow-hidden shadow rounded-lg">
                        <div class="p-5">
                            <div class="flex items-center">
                                <div class="flex-shrink-0">
                                    <div class="text-2xl">💬</div>
                                </div>
                                <div class="ml-5 w-0 flex-1">
                                    <dl>
                                        <dt class="text-sm font-medium text-gray-500 truncate">Total Conversations</dt>
                                        <dd class="text-lg font-medium text-gray-900">{{ 347 + (user_data[0] * 23) }}</dd>
                                    </dl>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="bg-white overflow-hidden shadow rounded-lg">
                        <div class="p-5">
                            <div class="flex items-center">
                                <div class="flex-shrink-0">
                                    <div class="text-2xl">⚡</div>
                                </div>
                                <div class="ml-5 w-0 flex-1">
                                    <dl>
                                        <dt class="text-sm font-medium text-gray-500 truncate">Response Rate</dt>
                                        <dd class="text-lg font-medium text-gray-900">98.5%</dd>
                                    </dl>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="bg-white overflow-hidden shadow rounded-lg">
                        <div class="p-5">
                            <div class="flex items-center">
                                <div class="flex-shrink-0">
                                    <div class="text-2xl">⏱️</div>
                                </div>
                                <div class="ml-5 w-0 flex-1">
                                    <dl>
                                        <dt class="text-sm font-medium text-gray-500 truncate">Avg Response Time</dt>
                                        <dd class="text-lg font-medium text-gray-900">1.2s</dd>
                                    </dl>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white shadow rounded-lg p-6 mb-8">
                    <h2 class="text-lg font-medium text-gray-900 mb-4">Your GPTsite Details</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <h3 class="text-sm font-medium text-gray-500">GPTsite ID</h3>
                            <p class="mt-1 text-sm text-gray-900 font-mono">{{ user_data[15] }}</p>
                        </div>
                        <div>
                            <h3 class="text-sm font-medium text-gray-500">Status</h3>
                            <p class="mt-1 text-sm text-green-600 font-semibold">Live & Active</p>
                        </div>
                        <div>
                            <h3 class="text-sm font-medium text-gray-500">Original Website</h3>
                            <p class="mt-1 text-sm text-blue-600"><a href="{{ user_data[7] }}" target="_blank">{{ user_data[7] }}</a></p>
                        </div>
                        <div>
                            <h3 class="text-sm font-medium text-gray-500">User Satisfaction</h3>
                            <p class="mt-1 text-sm text-gray-900">4.9/5 ⭐⭐⭐⭐⭐</p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white shadow rounded-lg p-6">
                    <h2 class="text-lg font-medium text-gray-900 mb-4">Quick Actions</h2>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <button class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition">Customize Responses</button>
                        <button class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition">View Analytics</button>
                        <button class="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition">Export Data</button>
                    </div>
                </div>
            </div>
        </main>
    </div>
</body>
</html>""", user_data=user_data)

# Superadmin routes
@app.route('/login', methods=['GET', 'POST'])
def admin_login():
    """Admin login page"""
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        if email == 'admin@edgpt.ai' and password == 'admin123':
            session['admin_logged_in'] = True
            return redirect('/superadmin')
        else:
            return render_template_string("""
            <div style="text-align: center; margin-top: 50px;">
                <h2>Login Failed</h2>
                <p>Invalid credentials</p>
                <a href="/login">Try Again</a>
            </div>
            """)
    
    return render_template_string("""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Admin Login</title>
        <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    </head>
    <body class="bg-gray-100">
        <div class="min-h-screen flex items-center justify-center">
            <div class="max-w-md w-full bg-white rounded-lg shadow-md p-6">
                <h2 class="text-2xl font-bold text-center mb-6">Admin Login</h2>
                <form method="POST">
                    <div class="mb-4">
                        <label class="block text-gray-700 text-sm font-bold mb-2">Email</label>
                        <input type="email" name="email" required class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                    </div>
                    <div class="mb-6">
                        <label class="block text-gray-700 text-sm font-bold mb-2">Password</label>
                        <input type="password" name="password" required class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                    </div>
                    <button type="submit" class="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700">Login</button>
                </form>
            </div>
        </div>
    </body>
    </html>
    """)

@app.route('/superadmin')
@app.route('/admin/dashboard')
def admin_dashboard():
    """Superadmin dashboard"""
    if not session.get('admin_logged_in'):
        return redirect('/login')
    
    # Get analytics data
    conn = sqlite3.connect('edgpt_platform.db')
    c = conn.cursor()
    
    # User statistics
    c.execute("SELECT COUNT(*) FROM users WHERE is_admin = 0")
    total_users = c.fetchone()[0]
    
    c.execute("SELECT COUNT(*) FROM users WHERE user_type = 'trial' AND is_admin = 0")
    trial_users = c.fetchone()[0]
    
    c.execute("SELECT COUNT(*) FROM users WHERE user_type = 'customer' AND is_admin = 0")
    customer_users = c.fetchone()[0]
    
    c.execute("SELECT SUM(revenue) FROM users WHERE is_admin = 0")
    total_revenue = c.fetchone()[0] or 0
    
    # Trial requests
    c.execute("SELECT COUNT(*) FROM trial_requests")
    total_trials = c.fetchone()[0]
    
    conn.close()
    
    return render_template_string("""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Superadmin Dashboard</title>
        <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    </head>
    <body class="bg-gray-100">
        <div class="min-h-screen">
            <nav class="bg-blue-600 text-white p-4">
                <div class="flex justify-between items-center">
                    <h1 class="text-xl font-bold">EdGPT Superadmin Dashboard</h1>
                    <a href="/login" class="bg-blue-700 px-4 py-2 rounded">Logout</a>
                </div>
            </nav>
            
            <div class="container mx-auto px-4 py-8">
                <!-- Statistics Cards -->
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                    <div class="bg-white p-6 rounded-lg shadow">
                        <h3 class="text-lg font-semibold text-gray-700">Total Users</h3>
                        <p class="text-3xl font-bold text-blue-600">{{ total_users }}</p>
                    </div>
                    <div class="bg-white p-6 rounded-lg shadow">
                        <h3 class="text-lg font-semibold text-gray-700">Trial Users</h3>
                        <p class="text-3xl font-bold text-yellow-600">{{ trial_users }}</p>
                    </div>
                    <div class="bg-white p-6 rounded-lg shadow">
                        <h3 class="text-lg font-semibold text-gray-700">Customers</h3>
                        <p class="text-3xl font-bold text-green-600">{{ customer_users }}</p>
                    </div>
                    <div class="bg-white p-6 rounded-lg shadow">
                        <h3 class="text-lg font-semibold text-gray-700">Total Revenue</h3>
                        <p class="text-3xl font-bold text-purple-600">${{ "%.2f"|format(total_revenue) }}</p>
                    </div>
                </div>
                
                <!-- Charts -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                    <div class="bg-white p-6 rounded-lg shadow">
                        <h3 class="text-lg font-semibold mb-4">Domain Traffic</h3>
                        <canvas id="domainChart"></canvas>
                    </div>
                    <div class="bg-white p-6 rounded-lg shadow">
                        <h3 class="text-lg font-semibold mb-4">Chat Sentiment</h3>
                        <canvas id="sentimentChart"></canvas>
                    </div>
                </div>
                
                <!-- User Management -->
                <div class="bg-white rounded-lg shadow p-6">
                    <h3 class="text-lg font-semibold mb-4">User Management</h3>
                    <div class="overflow-x-auto">
                        <table class="min-w-full table-auto">
                            <thead>
                                <tr class="bg-gray-50">
                                    <th class="px-4 py-2 text-left">Email</th>
                                    <th class="px-4 py-2 text-left">Organization</th>
                                    <th class="px-4 py-2 text-left">Type</th>
                                    <th class="px-4 py-2 text-left">Revenue</th>
                                    <th class="px-4 py-2 text-left">Status</th>
                                    <th class="px-4 py-2 text-left">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="userTable">
                                <!-- Users will be loaded here -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <script>
            // Domain Traffic Chart
            const domainCtx = document.getElementById('domainChart').getContext('2d');
            new Chart(domainCtx, {
                type: 'bar',
                data: {
                    labels: ['EdGPT.ai', 'GPTsites.ai', 'LawFirmGPT.ai', 'CPAFirm.ai', 'TaxPrepGPT.ai', 'BusinessBrokerGPT.ai'],
                    datasets: [{
                        label: 'Visitors',
                        data: [1250, 890, 650, 420, 380, 290],
                        backgroundColor: ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#06B6D4']
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
            
            // Sentiment Chart
            const sentimentCtx = document.getElementById('sentimentChart').getContext('2d');
            new Chart(sentimentCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Positive', 'Neutral', 'Negative'],
                    datasets: [{
                        data: [65, 25, 10],
                        backgroundColor: ['#10B981', '#6B7280', '#EF4444']
                    }]
                },
                options: {
                    responsive: true
                }
            });
            
            // Load users
            fetch('/api/users')
                .then(response => response.json())
                .then(users => {
                    const tbody = document.getElementById('userTable');
                    tbody.innerHTML = users.map(user => `
                        <tr class="border-t">
                            <td class="px-4 py-2">${user.email}</td>
                            <td class="px-4 py-2">${user.school_name}</td>
                            <td class="px-4 py-2">
                                <span class="px-2 py-1 rounded text-xs ${user.user_type === 'customer' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}">
                                    ${user.user_type}
                                </span>
                            </td>
                            <td class="px-4 py-2">$${user.revenue.toFixed(2)}</td>
                            <td class="px-4 py-2">
                                <span class="px-2 py-1 rounded text-xs bg-green-100 text-green-800">${user.status}</span>
                            </td>
                            <td class="px-4 py-2">
                                <button onclick="editUser(${user.id})" class="text-blue-600 hover:underline mr-2">Edit</button>
                                <button onclick="deleteUser(${user.id})" class="text-red-600 hover:underline">Delete</button>
                            </td>
                        </tr>
                    `).join('');
                });
            
            function editUser(id) {
                // Implement edit functionality
                alert('Edit user functionality would be implemented here');
            }
            
            function deleteUser(id) {
                if (confirm('Are you sure you want to delete this user?')) {
                    fetch(`/api/users/${id}`, { method: 'DELETE' })
                        .then(() => location.reload());
                }
            }
        </script>
    </body>
    </html>
    """, total_users=total_users, trial_users=trial_users, customer_users=customer_users, total_revenue=total_revenue)

@app.route('/api/users')
def api_users():
    """API endpoint to get users"""
    if not session.get('admin_logged_in'):
        return jsonify([])
    
    conn = sqlite3.connect('edgpt_platform.db')
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE is_admin = 0")
    users = c.fetchall()
    conn.close()
    
    user_list = []
    for user in users:
        user_list.append({
            'id': user[0],
            'email': user[3],
            'school_name': user[4],
            'user_type': user[18] if len(user) > 18 else 'trial',
            'revenue': user[19] if len(user) > 19 else 0.0,
            'status': user[16] if len(user) > 16 else 'active'
        })
    
    return jsonify(user_list)

@app.route('/technical-documentation')
def technical_documentation():
    """Technical documentation page"""
    host = request.headers.get('Host', 'edgpt.ai')
    config = get_domain_config(host)
    
    return render_template_string('''
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Technical Documentation - {{ config.platform_type }}</title>
        <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    </head>
    <body class="bg-gray-50">
        <div class="container mx-auto px-4 py-8 max-w-4xl">
            <h1 class="text-3xl font-bold mb-8">Technical Documentation</h1>
            
            <div class="bg-white rounded-lg shadow-lg p-8">
                <div class="space-y-6">
                    <section>
                        <h2 class="text-2xl font-semibold mb-4">1. System Overview</h2>
                        <p class="text-gray-700">{{ config.platform_type }} is an AI-powered website transformation platform that converts traditional websites into intelligent conversational assistants.</p>
                    </section>
                    
                    <section>
                        <h2 class="text-2xl font-semibold mb-4">2. Technical Specifications</h2>
                        <ul class="list-disc list-inside text-gray-700 space-y-2">
                            <li>Built on Flask framework with Python 3.11</li>
                            <li>SQLite database for data storage</li>
                            <li>Modern responsive design with Tailwind CSS</li>
                            <li>Real-time AI conversation processing</li>
                            <li>Secure user authentication and session management</li>
                        </ul>
                    </section>
                    
                    <section>
                        <h2 class="text-2xl font-semibold mb-4">3. API Endpoints</h2>
                        <div class="bg-gray-100 p-4 rounded-lg">
                            <code class="text-sm">
                                POST /submit-trial - Submit trial form<br>
                                POST /create-account - Create user account<br>
                                GET /dashboard - Conversion dashboard<br>
                                GET /user-dashboard - User management dashboard<br>
                                GET /superadmin - Admin dashboard
                            </code>
                        </div>
                    </section>
                    
                    <section>
                        <h2 class="text-2xl font-semibold mb-4">4. Security Features</h2>
                        <ul class="list-disc list-inside text-gray-700 space-y-2">
                            <li>Password hashing with SHA-256</li>
                            <li>Session-based authentication</li>
                            <li>CAPTCHA validation for form submissions</li>
                            <li>CORS protection</li>
                            <li>SQL injection prevention</li>
                        </ul>
                    </section>
                    
                    <section>
                        <h2 class="text-2xl font-semibold mb-4">5. Contact Information</h2>
                        <p class="text-gray-700">For technical support, please contact:</p>
                        <div class="mt-4 p-4 bg-gray-100 rounded-lg">
                            <p class="font-semibold">GPT AI Corporation</p>
                            <p>PO Box 2434</p>
                            <p>Fullerton, CA 92837</p>
                            <p>Email: <a href="mailto:{{ config.support_email }}" class="text-blue-600 underline">{{ config.support_email }}</a></p>
                            <p>Phone: <a href="tel:+1-650-399-9727" class="text-blue-600 underline">+1 (650) 399-9727</a></p>
                        </div>
                    </section>
                </div>
            </div>
            
            <div class="mt-8 text-center">
                <a href="/" class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition duration-300">Back to Home</a>
            </div>
        </div>
    </body>
    </html>
    ''', config=config)

@app.route('/terms-of-service')
def terms_of_service():
    """Terms of Service page"""
    host = request.headers.get('Host', 'edgpt.ai')
    config = get_domain_config(host)
    
    return render_template_string('''
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Terms of Service - {{ config.platform_type }}</title>
        <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    </head>
    <body class="bg-gray-50">
        <div class="container mx-auto px-4 py-8 max-w-4xl">
            <h1 class="text-3xl font-bold mb-8">Terms of Service</h1>
            
            <div class="bg-white rounded-lg shadow-lg p-8">
                <div class="mb-6">
                    <p class="text-gray-600">Last updated: August 8, 2025</p>
                    <p class="text-gray-600">Effective date: August 8, 2025</p>
                </div>
                
                <div class="space-y-6">
                    <section>
                        <h2 class="text-2xl font-semibold mb-4">1. Acceptance of Terms</h2>
                        <p class="text-gray-700">By accessing and using {{ config.platform_type }} services, you accept and agree to be bound by the terms and provision of this agreement.</p>
                    </section>
                    
                    <section>
                        <h2 class="text-2xl font-semibold mb-4">2. Service Description</h2>
                        <p class="text-gray-700">{{ config.platform_type }} provides AI-powered website transformation services that convert traditional websites into intelligent conversational assistants.</p>
                    </section>
                    
                    <section>
                        <h2 class="text-2xl font-semibold mb-4">3. User Responsibilities</h2>
                        <p class="text-gray-700">Users are responsible for maintaining the confidentiality of their account information and for all activities that occur under their account.</p>
                    </section>
                    
                    <section>
                        <h2 class="text-2xl font-semibold mb-4">4. Payment Terms</h2>
                        <p class="text-gray-700">Payment terms for {{ config.platform_type }} services are established at the time of subscription. All fees are non-refundable unless otherwise specified in writing.</p>
                    </section>
                    
                    <section>
                        <h2 class="text-2xl font-semibold mb-4">5. Limitation of Liability</h2>
                        <p class="text-gray-700">GPT AI Corporation shall not be liable for any indirect, incidental, special, consequential, or punitive damages resulting from your use of {{ config.platform_type }} services.</p>
                    </section>
                    
                    <section>
                        <h2 class="text-2xl font-semibold mb-4">6. Contact Information</h2>
                        <p class="text-gray-700">For questions about these Terms of Service, please contact:</p>
                        <div class="mt-4 p-4 bg-gray-100 rounded-lg">
                            <p class="font-semibold">GPT AI Corporation</p>
                            <p>PO Box 2434</p>
                            <p>Fullerton, CA 92837</p>
                            <p>Email: <a href="mailto:{{ config.support_email }}" class="text-blue-600 underline">{{ config.support_email }}</a></p>
                            <p>Phone: <a href="tel:+1-650-399-9727" class="text-blue-600 underline">+1 (650) 399-9727</a></p>
                        </div>
                    </section>
                </div>
            </div>
            
            <div class="mt-8 text-center">
                <a href="/" class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition duration-300">Back to Home</a>
            </div>
        </div>
    </body>
    </html>
    ''', config=config)

@app.route('/privacy-policy')
def privacy_policy():
    """Privacy Policy page"""
    host = request.headers.get('Host', 'edgpt.ai')
    config = get_domain_config(host)
    
    return render_template_string('''
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Privacy Policy - {{ config.platform_type }}</title>
        <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    </head>
    <body class="bg-gray-50">
        <div class="container mx-auto px-4 py-8 max-w-4xl">
            <h1 class="text-3xl font-bold mb-8">Privacy Policy</h1>
            
            <div class="bg-white rounded-lg shadow-lg p-8">
                <div class="mb-6">
                    <p class="text-gray-600">Last updated: August 8, 2025</p>
                    <p class="text-gray-600">Effective date: August 8, 2025</p>
                </div>
                
                <div class="space-y-6">
                    <section>
                        <h2 class="text-2xl font-semibold mb-4">1. Information We Collect</h2>
                        <p class="text-gray-700 mb-4">GPT AI Corporation collects information to provide better services to our {{ config.platform_type }} users. We collect information in the following ways:</p>
                        <ul class="list-disc list-inside text-gray-700 space-y-2">
                            <li>Information you give us (account registration, contact forms)</li>
                            <li>Information we get from your use of our services (usage analytics, performance data)</li>
                            <li>Information from cookies and similar technologies</li>
                        </ul>
                    </section>
                    
                    <section>
                        <h2 class="text-2xl font-semibold mb-4">2. How We Use Information</h2>
                        <p class="text-gray-700 mb-4">We use the information we collect to:</p>
                        <ul class="list-disc list-inside text-gray-700 space-y-2">
                            <li>Provide, maintain, and improve our {{ config.platform_type }} services</li>
                            <li>Process transactions and send related information</li>
                            <li>Send technical notices, updates, and support messages</li>
                            <li>Respond to comments, questions, and customer service requests</li>
                        </ul>
                    </section>
                    
                    <section>
                        <h2 class="text-2xl font-semibold mb-4">3. Information Sharing</h2>
                        <p class="text-gray-700">We do not sell, trade, or otherwise transfer your personal information to third parties without your consent, except as described in this policy or as required by law.</p>
                    </section>
                    
                    <section>
                        <h2 class="text-2xl font-semibold mb-4">4. Data Security</h2>
                        <p class="text-gray-700">We implement appropriate security measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction.</p>
                    </section>
                    
                    <section>
                        <h2 class="text-2xl font-semibold mb-4">5. Your Rights</h2>
                        <p class="text-gray-700 mb-4">You have the right to:</p>
                        <ul class="list-disc list-inside text-gray-700 space-y-2">
                            <li>Access and update your personal information</li>
                            <li>Request deletion of your personal information</li>
                            <li>Opt-out of certain communications</li>
                            <li>Request a copy of your data</li>
                        </ul>
                    </section>
                    
                    <section>
                        <h2 class="text-2xl font-semibold mb-4">6. Contact Us</h2>
                        <p class="text-gray-700">If you have questions about this Privacy Policy, please contact:</p>
                        <div class="mt-4 p-4 bg-gray-100 rounded-lg">
                            <p class="font-semibold">GPT AI Corporation</p>
                            <p>PO Box 2434</p>
                            <p>Fullerton, CA 92837</p>
                            <p>Email: <a href="mailto:{{ config.support_email }}" class="text-blue-600 underline">{{ config.support_email }}</a></p>
                            <p>Phone: <a href="tel:+1-650-399-9727" class="text-blue-600 underline">+1 (650) 399-9727</a></p>
                        </div>
                    </section>
                </div>
            </div>
            
            <div class="mt-8 text-center">
                <a href="/" class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition duration-300">Back to Home</a>
            </div>
        </div>
    </body>
    </html>
    ''', config=config)

# Pricing Template
PRICING_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pricing - {{ config.platform_type }}</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        .text-gradient {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .hero-gradient {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .pricing-card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .pricing-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
        }
        .popular-badge {
            background: linear-gradient(135deg, #10B981 0%, #059669 100%);
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-sm">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <a href="/" class="text-xl font-bold text-gradient">{{ config.platform_type }}</a>
                </div>
                <div class="flex items-center space-x-8">
                    <a href="/#features" class="text-gray-700 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium">Features</a>
                    <a href="/#demo" class="text-gray-700 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium">Demo</a>
                    <a href="/pricing" class="text-blue-600 px-3 py-2 rounded-md text-sm font-medium font-semibold">Pricing</a>
                    <a href="/#contact" class="text-gray-700 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium">Contact</a>
                    <a href="/#trial" class="bg-blue-600 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-blue-700 transition">Start Free Trial</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-gradient text-white py-16">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 class="text-4xl font-bold mb-4">Simple, Transparent Pricing</h1>
            <p class="text-xl mb-8 max-w-3xl mx-auto">Choose the perfect plan for your {{ pricing_config.industry.lower() }} practice. All plans include our core AI assistant features with industry-specific customization.</p>
        </div>
    </section>

    <!-- ROI Statistics -->
    <section class="py-12 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-8">
                <h2 class="text-3xl font-bold text-gray-900 mb-4">Proven Results for {{ pricing_config.industry }}</h2>
                <p class="text-xl text-gray-600">See the impact our AI assistants make for {{ pricing_config.target_customers.lower() }}</p>
            </div>
            
            <div class="grid md:grid-cols-4 gap-8 text-center">
                {% for stat_key, stat_value in pricing_config.roi_stats.items() %}
                <div class="bg-gray-50 rounded-lg p-6">
                    <div class="text-3xl font-bold text-blue-600 mb-2">{{ stat_value.split()[0] }}</div>
                    <p class="text-gray-700">{{ stat_value.split(' ', 1)[1] if ' ' in stat_value else stat_value }}</p>
                </div>
                {% endfor %}
            </div>
        </div>
    </section>

    <!-- Pricing Plans -->
    <section class="py-16 bg-gray-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-12">
                <h2 class="text-3xl font-bold text-gray-900 mb-4">Choose Your Plan</h2>
                <p class="text-xl text-gray-600">All plans include unlimited conversations and 24/7 availability</p>
            </div>
            
            <div class="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
                <!-- Silver Plan -->
                <div class="pricing-card bg-white rounded-lg shadow-lg p-8 relative">
                    <div class="text-center">
                        <h3 class="text-2xl font-bold text-gray-900 mb-2">Silver</h3>
                        <p class="text-gray-600 mb-4">Perfect for small practices</p>
                        <div class="text-4xl font-bold text-gray-900 mb-1">$49</div>
                        <p class="text-gray-600 mb-6">per month</p>
                        
                        <div class="text-left space-y-3 mb-8">
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span>5,000 messages/month</span>
                            </div>
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span>AI-powered conversations</span>
                            </div>
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span>Website integration</span>
                            </div>
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span>Basic analytics</span>
                            </div>
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span>Lead capture</span>
                            </div>
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span>Forms management (basic)</span>
                            </div>
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span>Document uploads (5MB)</span>
                            </div>
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span>Email support</span>
                            </div>
                        </div>
                        
                        <a href="/#trial" class="block w-full bg-gray-900 text-white text-center py-3 rounded-lg hover:bg-gray-800 transition">Start Free Trial</a>
                    </div>
                </div>

                <!-- Gold Plan (Most Popular) -->
                <div class="pricing-card bg-white rounded-lg shadow-lg p-8 relative border-2 border-blue-500">
                    <div class="absolute -top-4 left-1/2 transform -translate-x-1/2">
                        <span class="popular-badge text-white px-4 py-1 rounded-full text-sm font-semibold">Most Popular</span>
                    </div>
                    <div class="text-center">
                        <h3 class="text-2xl font-bold text-gray-900 mb-2">Gold</h3>
                        <p class="text-gray-600 mb-4">Best for growing practices</p>
                        <div class="text-4xl font-bold text-blue-600 mb-1">$99</div>
                        <p class="text-gray-600 mb-6">per month</p>
                        
                        <div class="text-left space-y-3 mb-8">
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span class="font-semibold">15,000 messages/month</span>
                            </div>
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span>Everything in Silver</span>
                            </div>
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span>Advanced analytics & reporting</span>
                            </div>
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span>Video links & transcription</span>
                            </div>
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span>Calendar integration</span>
                            </div>
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span>Forms management (advanced)</span>
                            </div>
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span>Document uploads (50MB)</span>
                            </div>
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span>API access</span>
                            </div>
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span>Priority support</span>
                            </div>
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span>Custom branding</span>
                            </div>
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span>3 team members</span>
                            </div>
                        </div>
                        
                        <a href="/#trial" class="block w-full bg-blue-600 text-white text-center py-3 rounded-lg hover:bg-blue-700 transition">Start Free Trial</a>
                    </div>
                </div>

                <!-- Platinum Plan -->
                <div class="pricing-card bg-white rounded-lg shadow-lg p-8 relative">
                    <div class="text-center">
                        <h3 class="text-2xl font-bold text-gray-900 mb-2">Platinum</h3>
                        <p class="text-gray-600 mb-4">For established firms</p>
                        <div class="text-4xl font-bold text-gray-900 mb-1">$149</div>
                        <p class="text-gray-600 mb-6">per month</p>
                        
                        <div class="text-left space-y-3 mb-8">
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span class="font-semibold">25,000 messages/month</span>
                            </div>
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span>Everything in Gold</span>
                            </div>
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span>Advanced AI models</span>
                            </div>
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span>Unlimited document uploads</span>
                            </div>
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span>Advanced integrations</span>
                            </div>
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span>White-label options</span>
                            </div>
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span>Dedicated account manager</span>
                            </div>
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span>SLA guarantees</span>
                            </div>
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span>10 team members</span>
                            </div>
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span>Advanced security features</span>
                            </div>
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                <span>Custom domain</span>
                            </div>
                        </div>
                        
                        <a href="/#trial" class="block w-full bg-gray-900 text-white text-center py-3 rounded-lg hover:bg-gray-800 transition">Start Free Trial</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Use Cases -->
    <section class="py-16 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-12">
                <h2 class="text-3xl font-bold text-gray-900 mb-4">Perfect for {{ pricing_config.industry }}</h2>
                <p class="text-xl text-gray-600">See how our AI assistant helps {{ pricing_config.target_customers.lower() }}</p>
            </div>
            
            <div class="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
                {% for use_case in pricing_config.use_cases %}
                <div class="flex items-start">
                    <div class="flex-shrink-0">
                        <svg class="w-6 h-6 text-green-500 mt-1" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                        </svg>
                    </div>
                    <div class="ml-3">
                        <p class="text-lg text-gray-700">{{ use_case }}</p>
                    </div>
                </div>
                {% endfor %}
            </div>
        </div>
    </section>

    <!-- FAQ Section -->
    <section class="py-16 bg-gray-50">
        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-12">
                <h2 class="text-3xl font-bold text-gray-900 mb-4">Frequently Asked Questions</h2>
            </div>
            
            <div class="space-y-8">
                <div class="bg-white rounded-lg p-6 shadow-sm">
                    <h3 class="text-lg font-semibold text-gray-900 mb-2">What happens if I exceed my message limit?</h3>
                    <p class="text-gray-700">We'll notify you when you reach 80% of your limit. If you exceed it, we'll automatically upgrade you to the next tier for that month, or you can upgrade your plan anytime.</p>
                </div>
                
                <div class="bg-white rounded-lg p-6 shadow-sm">
                    <h3 class="text-lg font-semibold text-gray-900 mb-2">Can I change plans anytime?</h3>
                    <p class="text-gray-700">Yes! You can upgrade or downgrade your plan at any time. Changes take effect immediately, and we'll prorate the billing accordingly.</p>
                </div>
                
                <div class="bg-white rounded-lg p-6 shadow-sm">
                    <h3 class="text-lg font-semibold text-gray-900 mb-2">Is there a setup fee?</h3>
                    <p class="text-gray-700">No setup fees! We'll help you get started with your AI assistant at no additional cost. Our team will assist with initial configuration and training.</p>
                </div>
                
                <div class="bg-white rounded-lg p-6 shadow-sm">
                    <h3 class="text-lg font-semibold text-gray-900 mb-2">What kind of support do you provide?</h3>
                    <p class="text-gray-700">All plans include email support. Gold and Platinum plans get priority support with faster response times. Platinum includes a dedicated account manager.</p>
                </div>
                
                <div class="bg-white rounded-lg p-6 shadow-sm">
                    <h3 class="text-lg font-semibold text-gray-900 mb-2">Can I cancel anytime?</h3>
                    <p class="text-gray-700">Yes, you can cancel your subscription at any time. There are no long-term contracts or cancellation fees. Your service will continue until the end of your current billing period.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="hero-gradient text-white py-16">
        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 class="text-3xl font-bold mb-4">Ready to Transform Your {{ pricing_config.industry }}?</h2>
            <p class="text-xl mb-8">Join hundreds of {{ pricing_config.target_customers.lower() }} who have already revolutionized their client experience with AI.</p>
            <a href="/#trial" class="bg-white text-blue-600 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-gray-100 transition">Start Your Free Trial Today</a>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-900 text-white py-12">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid md:grid-cols-4 gap-8">
                <div>
                    <h3 class="text-lg font-semibold mb-4">{{ config.platform_type }}</h3>
                    <p class="text-gray-400">Transform your {{ pricing_config.industry.lower() }} with intelligent AI assistance.</p>
                </div>
                <div>
                    <h4 class="text-sm font-semibold mb-4">Product</h4>
                    <ul class="space-y-2 text-sm text-gray-400">
                        <li><a href="/#features" class="hover:text-white">Features</a></li>
                        <li><a href="/pricing" class="hover:text-white">Pricing</a></li>
                        <li><a href="/#demo" class="hover:text-white">Demo</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="text-sm font-semibold mb-4">Support</h4>
                    <ul class="space-y-2 text-sm text-gray-400">
                        <li><a href="/technical-documentation" class="hover:text-white">Documentation</a></li>
                        <li><a href="mailto:{{ config.support_email }}" class="hover:text-white">Contact Support</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="text-sm font-semibold mb-4">Legal</h4>
                    <ul class="space-y-2 text-sm text-gray-400">
                        <li><a href="/terms-of-service" class="hover:text-white">Terms of Service</a></li>
                        <li><a href="/privacy-policy" class="hover:text-white">Privacy Policy</a></li>
                    </ul>
                </div>
            </div>
            <div class="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
                <p>&copy; 2025 {{ config.platform_type }}. All rights reserved.</p>
            </div>
        </div>
    </footer>
</body>
</html>"""

@app.route('/pricing')
def pricing():
    """Pricing page for all domains except EdGPT.ai"""
    host = request.headers.get('Host', 'localhost')
    
    # EdGPT.ai doesn't have pricing - redirect to trial
    if 'edgpt.ai' in host:
        return redirect('/#trial')
    
    config = get_domain_config(host)
    
    # Domain-specific pricing content
    pricing_configs = {
        'gptsites.ai': {
            'industry': 'Business',
            'target_customers': 'Small to medium businesses',
            'use_cases': [
                'Customer support automation',
                'Lead qualification and capture',
                'Product information and pricing',
                'Business hours and contact info'
            ],
            'roi_stats': {
                'response_time': '95% faster response time',
                'availability': '24/7 customer support',
                'lead_capture': '3x more qualified leads',
                'cost_savings': '60% reduction in support costs'
            }
        },
        'lawfirmgpt.ai': {
            'industry': 'Legal Services',
            'target_customers': 'Law firms and legal practices',
            'use_cases': [
                'Initial client consultations',
                'Case type qualification',
                'Legal document requests',
                'Appointment scheduling'
            ],
            'roi_stats': {
                'client_intake': '80% faster client intake',
                'availability': '24/7 legal assistance',
                'qualified_leads': '4x more qualified consultations',
                'efficiency': '70% reduction in admin time'
            }
        },
        'cpafirm.ai': {
            'industry': 'Accounting Services',
            'target_customers': 'CPA firms and accounting practices',
            'use_cases': [
                'Tax preparation inquiries',
                'Bookkeeping service requests',
                'Financial document collection',
                'Appointment scheduling'
            ],
            'roi_stats': {
                'client_onboarding': '75% faster client onboarding',
                'availability': '24/7 accounting support',
                'document_collection': '5x faster document gathering',
                'seasonal_efficiency': '90% better during tax season'
            }
        },
        'taxprepgpt.ai': {
            'industry': 'Tax Preparation',
            'target_customers': 'Tax preparation services',
            'use_cases': [
                'Tax filing questions',
                'Document requirement guidance',
                'Refund status inquiries',
                'Appointment booking'
            ],
            'roi_stats': {
                'client_prep': '85% better client preparation',
                'availability': '24/7 tax assistance',
                'document_accuracy': '6x fewer missing documents',
                'peak_handling': '10x capacity during tax season'
            }
        },
        'businessbrokergpt.ai': {
            'industry': 'Business Brokerage',
            'target_customers': 'Business brokers and M&A firms',
            'use_cases': [
                'Business valuation requests',
                'Buyer/seller qualification',
                'Transaction process guidance',
                'Confidential inquiries'
            ],
            'roi_stats': {
                'lead_quality': '90% higher quality leads',
                'availability': '24/7 deal support',
                'qualification': '8x better buyer qualification',
                'deal_flow': '5x increase in deal pipeline'
            }
        }
    }
    
    domain_key = None
    for key in pricing_configs.keys():
        if key in host:
            domain_key = key
            break
    
    if not domain_key:
        domain_key = 'gptsites.ai'  # Default fallback
    
    pricing_config = pricing_configs[domain_key]
    
    return render_template_string(PRICING_TEMPLATE, 
                                config=config, 
                                pricing_config=pricing_config)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)


# Pricing Template

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)

