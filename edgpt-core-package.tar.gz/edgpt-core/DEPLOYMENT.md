# Deployment Guide

## Production Environment

### Server Details
- **Provider**: DigitalOcean
- **IP**: 64.225.91.11
- **OS**: Ubuntu 22.04 LTS
- **Python**: 3.11
- **Database**: SQLite3

### Directory Structure
```
/root/
├── app.py                    # Main Flask application
├── edgpt_platform.db        # SQLite database
├── app.log                   # Application logs
├── static/                   # Static assets
│   ├── edgpt_logo.png       # EdGPT logo
│   └── neural_logo.jpg      # Neural network icon
└── backups/                 # Database backups
```

## Deployment Process

### 1. Pre-Deployment Checklist
```bash
# Validate code syntax
python3 -m py_compile app.py

# Check static assets
ls -la static/

# Test database connection
python3 -c "import sqlite3; sqlite3.connect('test.db').close(); print('SQLite OK')"

# Verify SSH access
ssh -i ~/.ssh/edgpt_droplet_key root@64.225.91.11 "echo 'SSH OK'"
```

### 2. Backup Current Production
```bash
ssh -i ~/.ssh/edgpt_droplet_key root@64.225.91.11 "
    # Backup application
    cp /root/app.py /root/app.py.backup.\$(date +%Y%m%d_%H%M%S)
    
    # Backup database
    cp /root/edgpt_platform.db /root/edgpt_platform.db.backup.\$(date +%Y%m%d_%H%M%S)
    
    echo 'Backup completed'
"
```

### 3. Deploy Application
```bash
# Deploy main application
scp -i ~/.ssh/edgpt_droplet_key app.py root@64.225.91.11:/root/app.py

# Deploy static assets
scp -i ~/.ssh/edgpt_droplet_key static/* root@64.225.91.11:/root/static/

echo "Files deployed successfully"
```

### 4. Restart Application
```bash
ssh -i ~/.ssh/edgpt_droplet_key root@64.225.91.11 "
    # Stop existing application
    killall python3 2>/dev/null || true
    
    # Start new application
    cd /root
    nohup python3 app.py > app.log 2>&1 &
    
    # Wait for startup
    sleep 3
    
    # Verify application is running
    if ps aux | grep -q '[p]ython3 app.py'; then
        echo 'Application started successfully'
    else
        echo 'Application failed to start'
        exit 1
    fi
"
```

### 5. Health Checks
```bash
# Check all domains
for domain in edgpt.ai gptsites.ai lawfirmgpt.ai cpafirm.ai taxprepgpt.ai businessbrokergpt.ai; do
    if curl -s -o /dev/null -w "%{http_code}" https://$domain | grep -q "200"; then
        echo "✅ $domain responding"
    else
        echo "❌ $domain not responding"
    fi
done

# Check application logs
ssh -i ~/.ssh/edgpt_droplet_key root@64.225.91.11 "tail -5 /root/app.log"
```

## Database Management

### Schema Updates
```bash
# Connect to production database
ssh -i ~/.ssh/edgpt_droplet_key root@64.225.91.11 "
cd /root
python3 -c \"
import sqlite3
conn = sqlite3.connect('edgpt_platform.db')

# Example: Add new column
cursor = conn.cursor()
cursor.execute('ALTER TABLE trial_requests ADD COLUMN new_field TEXT')
conn.commit()

print('Schema updated')
conn.close()
\"
"
```

### Backup and Restore
```bash
# Create backup
ssh -i ~/.ssh/edgpt_droplet_key root@64.225.91.11 "
    cp /root/edgpt_platform.db /root/edgpt_platform.db.backup.\$(date +%Y%m%d_%H%M%S)
    echo 'Database backup created'
"

# Restore from backup
ssh -i ~/.ssh/edgpt_droplet_key root@64.225.91.11 "
    LATEST_BACKUP=\$(ls -t /root/edgpt_platform.db.backup.* | head -1)
    cp \$LATEST_BACKUP /root/edgpt_platform.db
    echo 'Database restored from: '\$LATEST_BACKUP
"
```

## Monitoring

### Application Status
```bash
# Check if application is running
ssh -i ~/.ssh/edgpt_droplet_key root@64.225.91.11 "
    if ps aux | grep -q '[p]ython3 app.py'; then
        echo 'Application: Running'
        ps aux | grep '[p]ython3 app.py'
    else
        echo 'Application: Not running'
    fi
"
```

### Log Monitoring
```bash
# View recent logs
ssh -i ~/.ssh/edgpt_droplet_key root@64.225.91.11 "tail -20 /root/app.log"

# Monitor logs in real-time
ssh -i ~/.ssh/edgpt_droplet_key root@64.225.91.11 "tail -f /root/app.log"

# Check for errors
ssh -i ~/.ssh/edgpt_droplet_key root@64.225.91.11 "grep -i error /root/app.log | tail -5"
```

### Performance Monitoring
```bash
# Check system resources
ssh -i ~/.ssh/edgpt_droplet_key root@64.225.91.11 "
    echo 'CPU and Memory:'
    top -bn1 | grep 'python3'
    
    echo 'Disk Usage:'
    df -h /root
    
    echo 'Database Size:'
    ls -lh /root/edgpt_platform.db
"
```

## Troubleshooting

### Common Issues

#### Application Won't Start
```bash
# Check Python syntax
ssh -i ~/.ssh/edgpt_droplet_key root@64.225.91.11 "
    cd /root
    python3 -m py_compile app.py
"

# Check for port conflicts
ssh -i ~/.ssh/edgpt_droplet_key root@64.225.91.11 "
    netstat -tlnp | grep :5000
"

# Check application logs
ssh -i ~/.ssh/edgpt_droplet_key root@64.225.91.11 "
    tail -20 /root/app.log
"
```

#### Database Issues
```bash
# Check database integrity
ssh -i ~/.ssh/edgpt_droplet_key root@64.225.91.11 "
    cd /root
    python3 -c \"
import sqlite3
conn = sqlite3.connect('edgpt_platform.db')
cursor = conn.cursor()
cursor.execute('PRAGMA integrity_check')
result = cursor.fetchone()
print(f'Database integrity: {result[0]}')
conn.close()
\"
"

# Check table schema
ssh -i ~/.ssh/edgpt_droplet_key root@64.225.91.11 "
    cd /root
    python3 -c \"
import sqlite3
conn = sqlite3.connect('edgpt_platform.db')
cursor = conn.cursor()
cursor.execute('PRAGMA table_info(trial_requests)')
schema = cursor.fetchall()
print('Table schema:')
for col in schema:
    print(f'  {col[1]} {col[2]}')
conn.close()
\"
"
```

#### Static Files Not Loading
```bash
# Check static files exist
ssh -i ~/.ssh/edgpt_droplet_key root@64.225.91.11 "ls -la /root/static/"

# Check Flask static configuration
ssh -i ~/.ssh/edgpt_droplet_key root@64.225.91.11 "
    grep -n 'static_folder' /root/app.py
"

# Test direct file access
curl -I https://edgpt.ai/static/edgpt_logo.png
```

### Emergency Recovery
```bash
# Complete application restart
ssh -i ~/.ssh/edgpt_droplet_key root@64.225.91.11 "
    # Kill all Python processes
    killall python3 2>/dev/null || true
    
    # Wait for cleanup
    sleep 2
    
    # Start fresh
    cd /root
    nohup python3 app.py > app.log 2>&1 &
    
    # Verify startup
    sleep 3
    if ps aux | grep -q '[p]ython3 app.py'; then
        echo 'Emergency restart successful'
    else
        echo 'Emergency restart failed - manual intervention required'
    fi
"
```

## Security

### SSH Key Management
```bash
# Verify SSH key permissions
chmod 600 ~/.ssh/edgpt_droplet_key

# Test SSH connection
ssh -i ~/.ssh/edgpt_droplet_key root@64.225.91.11 "echo 'SSH connection successful'"
```

### Firewall Configuration
```bash
# Check firewall status
ssh -i ~/.ssh/edgpt_droplet_key root@64.225.91.11 "ufw status"

# Allow HTTP/HTTPS traffic
ssh -i ~/.ssh/edgpt_droplet_key root@64.225.91.11 "
    ufw allow 80/tcp
    ufw allow 443/tcp
    ufw allow 22/tcp
"
```

## Automated Deployment Script

Create `deploy.sh`:
```bash
#!/bin/bash
set -e

echo "🚀 Starting EdGPT Platform Deployment..."

# Configuration
SERVER="root@64.225.91.11"
SSH_KEY="~/.ssh/edgpt_droplet_key"

# Pre-deployment checks
echo "📋 Running pre-deployment checks..."
python3 -m py_compile app.py
echo "✅ Code syntax validated"

# Backup production
echo "📦 Creating production backup..."
ssh -i $SSH_KEY $SERVER "
    cp /root/app.py /root/app.py.backup.\$(date +%Y%m%d_%H%M%S)
    cp /root/edgpt_platform.db /root/edgpt_platform.db.backup.\$(date +%Y%m%d_%H%M%S)
    echo '✅ Backup completed'
"

# Deploy files
echo "📤 Deploying application files..."
scp -i $SSH_KEY app.py $SERVER:/root/app.py
scp -i $SSH_KEY static/* $SERVER:/root/static/
echo "✅ Files deployed"

# Restart application
echo "🔄 Restarting application..."
ssh -i $SSH_KEY $SERVER "
    killall python3 2>/dev/null || true
    cd /root
    nohup python3 app.py > app.log 2>&1 &
    sleep 3
    if ps aux | grep -q '[p]ython3 app.py'; then
        echo '✅ Application restarted successfully'
    else
        echo '❌ Application failed to start'
        exit 1
    fi
"

# Health checks
echo "🏥 Running health checks..."
for domain in edgpt.ai gptsites.ai lawfirmgpt.ai; do
    if curl -s -o /dev/null -w "%{http_code}" https://$domain | grep -q "200"; then
        echo "✅ $domain responding"
    else
        echo "❌ $domain not responding"
    fi
done

echo "🎉 Deployment completed successfully!"
```

Make it executable:
```bash
chmod +x deploy.sh
```

Run deployment:
```bash
./deploy.sh
```

---

*Last Updated: August 9, 2025*

