# 🚀 EdGPT Platform v1.1m - Multi-LLM Deployment Integration & Testing Guide

## 🎯 **Complete Deployment Integration**

This guide covers the integration of the multi-LLM system into your existing EdGPT Platform v1.1m deployment at IP 64.23.163.0, ensuring seamless operation with all five LLM providers.

---

## 📦 **Deployment Integration Steps**

### **Step 1: Update Backend Dependencies**

Add the required packages to your backend requirements.txt:

```bash
# SSH into your server
ssh -i ~/.ssh/user_provided_key root@64.23.163.0

# Navigate to the backend directory
cd /opt/edgpt/backend

# Add new dependencies
cat >> requirements.txt << 'EOF'
# Multi-LLM Integration Dependencies
anthropic>=0.8.0
google-generativeai>=0.3.0
groq>=0.4.0
transformers>=4.35.0
torch>=2.0.0
aiohttp>=3.8.0
asyncio-throttle>=1.0.0
tenacity>=8.2.0
EOF

# Install new dependencies
pip install -r requirements.txt
```

### **Step 2: Update Flask Application**

Integrate the multi-LLM routes into your main Flask app:

```bash
# Update the main app.py file
cat >> /opt/edgpt/backend/app.py << 'EOF'

# Import Multi-LLM Blueprint
from src.routes.multi_llm import multi_llm_bp

# Register Multi-LLM Blueprint
app.register_blueprint(multi_llm_bp)

# Add Multi-LLM health check to main health endpoint
@app.route('/health')
def health_check():
    try:
        # Existing health checks...
        
        # Add Multi-LLM health check
        from src.services.multi_llm_service import multi_llm_service
        llm_status = multi_llm_service.get_provider_status()
        healthy_providers = [
            name for name, config in llm_status.items() 
            if config.get('enabled', False) and not config.get('rate_limited', False)
        ]
        
        return jsonify({
            "status": "healthy",
            "timestamp": datetime.now().isoformat(),
            "database": "connected",
            "redis": "connected",
            "llm_providers": {
                "total": len(llm_status),
                "healthy": len(healthy_providers),
                "providers": list(llm_status.keys())
            }
        }), 200
        
    except Exception as e:
        return jsonify({
            "status": "unhealthy",
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        }), 503

EOF
```

### **Step 3: Update Frontend Integration**

Add the Multi-LLM Dashboard to your React application:

```bash
# Update the main App.js to include Multi-LLM Dashboard
cat >> /opt/edgpt/frontend/src/App.js << 'EOF'

// Import Multi-LLM Dashboard
import MultiLLMDashboard from './components/MultiLLMDashboard';

// Add route for Multi-LLM Dashboard (inside your Routes component)
<Route path="/admin/multi-llm" element={<MultiLLMDashboard />} />

EOF

# Update navigation to include Multi-LLM Dashboard link
# This would be added to your admin navigation component
```

### **Step 4: Environment Variables Configuration**

Set up your environment variables on the server:

```bash
# Create or update the .env file
cat > /opt/edgpt/.env << 'EOF'
# Existing environment variables...

# Multi-LLM Configuration
OPENAI_API_KEY=your-openai-api-key-here
ANTHROPIC_API_KEY=your-anthropic-api-key-here
GOOGLE_API_KEY=your-google-api-key-here
GROQ_API_KEY=your-groq-api-key-here
HUGGINGFACE_API_KEY=your-huggingface-api-key-here

# Multi-LLM Settings
MULTI_LLM_ENABLED=true
FALLBACK_ENABLED=true
LOAD_BALANCING=true
COST_OPTIMIZATION=true

EOF

# Set proper permissions
chmod 600 /opt/edgpt/.env
```

### **Step 5: Update Docker Configuration**

If using Docker, update your docker-compose.yml:

```yaml
# Add to your existing docker-compose.yml
version: '3.8'
services:
  backend:
    environment:
      # Existing environment variables...
      - OPENAI_API_KEY=${OPENAI_API_KEY}
      - ANTHROPIC_API_KEY=${ANTHROPIC_API_KEY}
      - GOOGLE_API_KEY=${GOOGLE_API_KEY}
      - GROQ_API_KEY=${GROQ_API_KEY}
      - HUGGINGFACE_API_KEY=${HUGGINGFACE_API_KEY}
      - MULTI_LLM_ENABLED=${MULTI_LLM_ENABLED}
      - FALLBACK_ENABLED=${FALLBACK_ENABLED}
      - LOAD_BALANCING=${LOAD_BALANCING}
      - COST_OPTIMIZATION=${COST_OPTIMIZATION}
    volumes:
      # Add volume for model caching (optional)
      - ./models:/app/models
```

### **Step 6: Restart Services**

Restart your services to load the new configuration:

```bash
# If using Docker
cd /opt/edgpt
docker-compose down
docker-compose up -d

# If using systemd services
systemctl restart edgpt-backend
systemctl restart edgpt-frontend
systemctl restart nginx

# Check service status
systemctl status edgpt-backend
systemctl status edgpt-frontend
```

---

## 🧪 **Comprehensive Testing Suite**

### **Test 1: Provider Connectivity**

Test each LLM provider individually:

```bash
#!/bin/bash
# Multi-LLM Provider Test Script

SERVER_URL="http://64.23.163.0"
PROVIDERS=("openai" "anthropic" "google" "groq" "huggingface")

echo "🧪 Testing Multi-LLM Provider Connectivity..."
echo "================================================"

for provider in "${PROVIDERS[@]}"; do
    echo "Testing $provider..."
    
    response=$(curl -s -X POST "$SERVER_URL/api/llm/providers/$provider/test" \
        -H "Content-Type: application/json")
    
    if echo "$response" | grep -q '"success": true'; then
        echo "✅ $provider: PASSED"
    else
        echo "❌ $provider: FAILED"
        echo "   Response: $response"
    fi
    echo ""
done

echo "Provider connectivity test completed."
```

### **Test 2: Task-Based Routing**

Test intelligent routing for different task types:

```bash
#!/bin/bash
# Task-Based Routing Test Script

SERVER_URL="http://64.23.163.0"

echo "🎯 Testing Task-Based Routing..."
echo "================================"

# Test general chat
echo "Testing General Chat..."
curl -s -X POST "$SERVER_URL/api/llm/chat" \
    -H "Content-Type: application/json" \
    -d '{
        "prompt": "What are the school hours for Lincoln Elementary?",
        "task_type": "general_chat",
        "context": {"school_id": "lincoln_elementary"}
    }' | jq '.provider, .content' | head -2

echo ""

# Test emergency response
echo "Testing Emergency Response..."
curl -s -X POST "$SERVER_URL/api/llm/chat" \
    -H "Content-Type: application/json" \
    -d '{
        "prompt": "Is school closed today due to weather?",
        "task_type": "emergency_response",
        "priority_speed": true
    }' | jq '.provider, .response_time' | head -2

echo ""

# Test creative writing
echo "Testing Creative Writing..."
curl -s -X POST "$SERVER_URL/api/llm/chat" \
    -H "Content-Type: application/json" \
    -d '{
        "prompt": "Write a brief welcome message for new students.",
        "task_type": "creative_writing"
    }' | jq '.provider, .content' | head -2

echo ""

# Test factual lookup
echo "Testing Factual Lookup..."
curl -s -X POST "$SERVER_URL/api/llm/chat" \
    -H "Content-Type: application/json" \
    -d '{
        "prompt": "What is the school district policy on attendance?",
        "task_type": "factual_lookup"
    }' | jq '.provider, .content' | head -2

echo ""
echo "Task-based routing test completed."
```

### **Test 3: Fallback System**

Test the fallback mechanism:

```bash
#!/bin/bash
# Fallback System Test Script

SERVER_URL="http://64.23.163.0"

echo "🔄 Testing Fallback System..."
echo "============================="

# Disable primary provider (OpenAI) temporarily
echo "Disabling OpenAI provider..."
curl -s -X PUT "$SERVER_URL/api/llm/providers/openai/config" \
    -H "Content-Type: application/json" \
    -d '{"enabled": false}'

echo ""

# Test that system still works with fallback
echo "Testing fallback response..."
response=$(curl -s -X POST "$SERVER_URL/api/llm/chat" \
    -H "Content-Type: application/json" \
    -d '{
        "prompt": "Hello, this is a fallback test.",
        "task_type": "general_chat"
    }')

provider=$(echo "$response" | jq -r '.provider')
success=$(echo "$response" | jq -r '.success')

if [ "$success" = "true" ] && [ "$provider" != "openai" ]; then
    echo "✅ Fallback system working. Used provider: $provider"
else
    echo "❌ Fallback system failed"
fi

echo ""

# Re-enable OpenAI provider
echo "Re-enabling OpenAI provider..."
curl -s -X PUT "$SERVER_URL/api/llm/providers/openai/config" \
    -H "Content-Type: application/json" \
    -d '{"enabled": true}'

echo "Fallback system test completed."
```

### **Test 4: Performance Benchmarking**

Benchmark response times across providers:

```bash
#!/bin/bash
# Performance Benchmarking Script

SERVER_URL="http://64.23.163.0"
PROVIDERS=("openai" "anthropic" "google" "groq" "huggingface")

echo "⚡ Performance Benchmarking..."
echo "============================="

for provider in "${PROVIDERS[@]}"; do
    echo "Benchmarking $provider..."
    
    # Disable all other providers
    for other_provider in "${PROVIDERS[@]}"; do
        if [ "$other_provider" != "$provider" ]; then
            curl -s -X PUT "$SERVER_URL/api/llm/providers/$other_provider/config" \
                -H "Content-Type: application/json" \
                -d '{"enabled": false}' > /dev/null
        fi
    done
    
    # Enable current provider
    curl -s -X PUT "$SERVER_URL/api/llm/providers/$provider/config" \
        -H "Content-Type: application/json" \
        -d '{"enabled": true}' > /dev/null
    
    # Measure response time
    start_time=$(date +%s.%N)
    response=$(curl -s -X POST "$SERVER_URL/api/llm/chat" \
        -H "Content-Type: application/json" \
        -d '{
            "prompt": "What time does school start?",
            "task_type": "general_chat"
        }')
    end_time=$(date +%s.%N)
    
    total_time=$(echo "$end_time - $start_time" | bc)
    api_time=$(echo "$response" | jq -r '.response_time // 0')
    
    echo "  Total time: ${total_time}s"
    echo "  API time: ${api_time}s"
    echo ""
done

# Re-enable all providers
for provider in "${PROVIDERS[@]}"; do
    curl -s -X PUT "$SERVER_URL/api/llm/providers/$provider/config" \
        -H "Content-Type: application/json" \
        -d '{"enabled": true}' > /dev/null
done

echo "Performance benchmarking completed."
```

### **Test 5: Load Testing**

Test system under load:

```bash
#!/bin/bash
# Load Testing Script

SERVER_URL="http://64.23.163.0"
CONCURRENT_REQUESTS=10
TOTAL_REQUESTS=100

echo "🔥 Load Testing Multi-LLM System..."
echo "=================================="

# Create test prompts
prompts=(
    "What are the school hours?"
    "How do I contact the principal?"
    "What is the lunch menu today?"
    "When is the next parent-teacher conference?"
    "What are the school policies?"
)

# Function to make a request
make_request() {
    local prompt="${prompts[$((RANDOM % ${#prompts[@]}))]}"
    local task_type="general_chat"
    
    curl -s -X POST "$SERVER_URL/api/llm/chat" \
        -H "Content-Type: application/json" \
        -d "{
            \"prompt\": \"$prompt\",
            \"task_type\": \"$task_type\"
        }" | jq -r '.success, .provider, .response_time' | tr '\n' ' '
    echo ""
}

# Export function for parallel execution
export -f make_request
export SERVER_URL
export prompts

echo "Starting load test with $CONCURRENT_REQUESTS concurrent requests..."
echo "Total requests: $TOTAL_REQUESTS"
echo ""

# Run load test
seq 1 $TOTAL_REQUESTS | xargs -n1 -P$CONCURRENT_REQUESTS -I{} bash -c 'make_request'

echo ""
echo "Load testing completed."
```

### **Test 6: Cost Analysis**

Monitor costs across providers:

```bash
#!/bin/bash
# Cost Analysis Script

SERVER_URL="http://64.23.163.0"

echo "💰 Cost Analysis..."
echo "=================="

# Get analytics data
analytics=$(curl -s "$SERVER_URL/api/llm/analytics")

echo "Cost Analysis Results:"
echo "$analytics" | jq '{
    total_requests: .total_requests,
    cost_analysis: .cost_analysis,
    provider_costs: [
        .provider_metrics | to_entries[] | {
            provider: .key,
            requests: .value.performance.total_requests,
            cost_per_1k: .value.cost_per_1k_tokens,
            estimated_cost: (.value.performance.total_requests * .value.cost_per_1k_tokens / 1000)
        }
    ]
}'

echo ""
echo "Cost analysis completed."
```

---

## 📊 **Monitoring and Maintenance**

### **Health Check Monitoring**

Set up continuous monitoring:

```bash
#!/bin/bash
# Health Check Monitoring Script

SERVER_URL="http://64.23.163.0"
LOG_FILE="/var/log/edgpt-multi-llm-health.log"

while true; do
    timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    
    # Check overall health
    health_response=$(curl -s "$SERVER_URL/api/llm/health")
    health_status=$(echo "$health_response" | jq -r '.status')
    
    # Check individual providers
    provider_status=$(curl -s "$SERVER_URL/api/llm/status")
    
    # Log results
    echo "[$timestamp] Health: $health_status" >> "$LOG_FILE"
    echo "$provider_status" | jq -r 'to_entries[] | "[\($timestamp)] \(.key): enabled=\(.value.enabled), rate_limited=\(.value.rate_limited)"' >> "$LOG_FILE"
    
    # Alert if unhealthy
    if [ "$health_status" != "healthy" ]; then
        echo "[$timestamp] ALERT: Multi-LLM system unhealthy!" >> "$LOG_FILE"
        # Add notification logic here (email, Slack, etc.)
    fi
    
    sleep 300  # Check every 5 minutes
done
```

### **Performance Monitoring**

Track performance metrics:

```bash
#!/bin/bash
# Performance Monitoring Script

SERVER_URL="http://64.23.163.0"
METRICS_FILE="/var/log/edgpt-multi-llm-metrics.log"

collect_metrics() {
    timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    
    # Get analytics
    analytics=$(curl -s "$SERVER_URL/api/llm/analytics")
    
    # Extract key metrics
    total_requests=$(echo "$analytics" | jq -r '.total_requests')
    avg_response_time=$(echo "$analytics" | jq -r '.avg_response_time')
    avg_success_rate=$(echo "$analytics" | jq -r '.avg_success_rate')
    
    # Log metrics
    echo "[$timestamp] Requests: $total_requests, Avg Response: ${avg_response_time}s, Success Rate: ${avg_success_rate}%" >> "$METRICS_FILE"
    
    # Provider-specific metrics
    echo "$analytics" | jq -r '.provider_metrics | to_entries[] | "[\($timestamp)] \(.key): requests=\(.value.performance.total_requests), response_time=\(.value.performance.avg_response_time), success_rate=\(.value.performance.success_rate)"' >> "$METRICS_FILE"
}

# Collect metrics every minute
while true; do
    collect_metrics
    sleep 60
done
```

---

## 🔧 **Troubleshooting Guide**

### **Common Issues and Solutions**

#### **Issue 1: Provider Not Responding**

**Symptoms**: Specific provider always fails or times out

**Diagnosis**:
```bash
# Test specific provider
curl -X POST http://64.23.163.0/api/llm/providers/openai/test

# Check provider configuration
curl http://64.23.163.0/api/llm/status | jq '.openai'
```

**Solutions**:
1. Verify API key is correct and has proper permissions
2. Check rate limits and quotas
3. Verify network connectivity
4. Check provider service status

#### **Issue 2: High Response Times**

**Symptoms**: Slow responses across all providers

**Diagnosis**:
```bash
# Check performance metrics
curl http://64.23.163.0/api/llm/analytics | jq '.avg_response_time'

# Test individual providers
for provider in openai anthropic google groq huggingface; do
    echo "Testing $provider..."
    time curl -X POST http://64.23.163.0/api/llm/providers/$provider/test
done
```

**Solutions**:
1. Enable Groq for speed-critical tasks
2. Optimize prompt lengths
3. Check server resources (CPU, memory, network)
4. Implement response caching

#### **Issue 3: High Costs**

**Symptoms**: Unexpected high API costs

**Diagnosis**:
```bash
# Check cost analysis
curl http://64.23.163.0/api/llm/analytics | jq '.cost_analysis'

# Check usage patterns
curl http://64.23.163.0/api/llm/status | jq 'to_entries[] | {provider: .key, requests: .value.performance.total_requests, cost: .value.cost_per_1k_tokens}'
```

**Solutions**:
1. Implement cost-based routing
2. Set spending limits per provider
3. Use cheaper models for simple tasks
4. Implement intelligent caching

#### **Issue 4: Fallback Not Working**

**Symptoms**: System fails when primary provider is down

**Diagnosis**:
```bash
# Test fallback system
curl -X PUT http://64.23.163.0/api/llm/providers/openai/config \
    -H "Content-Type: application/json" \
    -d '{"enabled": false}'

curl -X POST http://64.23.163.0/api/llm/chat \
    -H "Content-Type: application/json" \
    -d '{"prompt": "Test fallback", "task_type": "general_chat"}'
```

**Solutions**:
1. Verify fallback is enabled in configuration
2. Check that backup providers are configured
3. Review fallback chain configuration
4. Test individual backup providers

---

## 📈 **Optimization Recommendations**

### **Performance Optimization**

1. **Provider Selection Strategy**:
   - Use Groq for real-time responses (< 1 second)
   - Use OpenAI GPT-4 for complex reasoning
   - Use Google Gemini for factual queries
   - Use Anthropic Claude for creative content

2. **Caching Implementation**:
   - Cache common school information responses
   - Implement Redis-based response caching
   - Use semantic similarity for cache hits
   - Set appropriate cache expiration times

3. **Load Balancing**:
   - Distribute requests across healthy providers
   - Implement circuit breakers for failed providers
   - Use weighted routing based on performance

### **Cost Optimization**

1. **Tiered Routing**:
   - Route simple queries to cheaper models
   - Use premium models only for complex tasks
   - Implement cost-based provider selection

2. **Usage Monitoring**:
   - Set daily/monthly spending limits
   - Monitor token usage patterns
   - Implement cost alerts and notifications

3. **Efficiency Improvements**:
   - Optimize prompt engineering
   - Reduce unnecessary API calls
   - Implement intelligent batching

---

## 🎉 **Deployment Verification Checklist**

### **Pre-Production Checklist**

- [ ] All 5 LLM providers configured and tested
- [ ] API keys validated and working
- [ ] Task-based routing functioning correctly
- [ ] Fallback system tested and working
- [ ] Performance benchmarks meet requirements
- [ ] Cost monitoring and alerts configured
- [ ] Health checks and monitoring active
- [ ] Load testing completed successfully
- [ ] Security review completed
- [ ] Documentation updated

### **Production Readiness**

- [ ] Multi-LLM dashboard accessible
- [ ] All providers showing healthy status
- [ ] Response times within acceptable limits
- [ ] Cost tracking and budgets configured
- [ ] Monitoring and alerting active
- [ ] Backup and recovery procedures tested
- [ ] Staff training completed
- [ ] Support procedures documented

---

## 🚀 **Go-Live Process**

### **Final Deployment Steps**

1. **Backup Current System**:
   ```bash
   # Create backup of current deployment
   cd /opt/edgpt
   tar -czf edgpt-backup-$(date +%Y%m%d).tar.gz .
   ```

2. **Deploy Multi-LLM System**:
   ```bash
   # Apply all configuration changes
   docker-compose down
   docker-compose up -d
   
   # Verify deployment
   curl http://64.23.163.0/api/llm/health
   ```

3. **Run Final Tests**:
   ```bash
   # Run comprehensive test suite
   ./test-multi-llm-system.sh
   ```

4. **Monitor Initial Performance**:
   ```bash
   # Monitor for first 24 hours
   tail -f /var/log/edgpt-multi-llm-health.log
   ```

### **Post-Deployment Tasks**

1. **Performance Monitoring**: Monitor response times and success rates
2. **Cost Tracking**: Review daily costs and usage patterns
3. **User Feedback**: Collect feedback on response quality
4. **Optimization**: Fine-tune provider selection and routing
5. **Documentation**: Update operational procedures

---

## 🎯 **Success Metrics**

Your multi-LLM integration is successful when you achieve:

- ✅ **99.9% Uptime** with automatic failover
- ✅ **Sub-2 Second Response Times** for general queries
- ✅ **Sub-1 Second Response Times** for emergency responses
- ✅ **95%+ Success Rate** across all providers
- ✅ **Cost Optimization** with 30%+ savings through intelligent routing
- ✅ **Enhanced Quality** with task-specific model selection

**Congratulations! Your EdGPT Platform v1.1m now has the most advanced multi-LLM integration available!** 🎉

---

*For technical support with deployment integration, contact our engineering team at support@edgpt.ai*

