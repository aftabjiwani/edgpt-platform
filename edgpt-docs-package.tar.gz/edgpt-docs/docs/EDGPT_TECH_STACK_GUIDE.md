# EdGPT Platform - Tech Stack & Secure Self-Deployment Guide

## 🏗️ **EdGPT Platform Tech Stack**

### **Frontend Architecture**
```
React 18.2.0
├── Modern Hooks & Context API
├── Tailwind CSS 3.3.0 (Responsive Design)
├── React Router 6.8.0 (Multi-page Navigation)
├── Axios (API Communication)
├── React Hook Form (Form Management)
└── Framer Motion (Animations)
```

### **Backend Architecture**
```
Flask 2.3.0 (Python Web Framework)
├── SQLAlchemy 2.0 (Database ORM)
├── Flask-JWT-Extended (Authentication)
├── Flask-CORS (Cross-Origin Support)
├── Flask-Migrate (Database Migrations)
├── Celery (Background Tasks)
└── Gunicorn (Production WSGI Server)
```

### **Database & Storage**
```
PostgreSQL 13+
├── Multi-tenant Architecture
├── Automated Backups
├── Connection Pooling
└── Performance Optimization

Redis 6+
├── Session Storage
├── Caching Layer
├── Rate Limiting
└── Background Job Queue
```

### **AI Integration**
```
Multi-Provider AI System
├── OpenAI GPT-4 (Primary)
├── Anthropic Claude (Secondary)
├── Google Gemini (Multimodal)
├── Ollama (Local/Private)
└── Smart Provider Routing
```

### **Infrastructure & DevOps**
```
Docker & Docker Compose
├── Containerized Services
├── Multi-stage Builds
├── Health Checks
└── Auto-restart Policies

Nginx (Reverse Proxy)
├── SSL Termination
├── Load Balancing
├── Rate Limiting
├── Security Headers
└── Static File Serving
```

### **Security & Monitoring**
```
Security Stack
├── JWT Authentication
├── Rate Limiting
├── CORS Protection
├── SQL Injection Prevention
├── XSS Protection
└── CSRF Protection

Monitoring
├── Health Check Endpoints
├── Application Metrics
├── Error Tracking
├── Performance Monitoring
└── Automated Alerts
```

---

## 🔐 **Secure Self-Deployment Strategy**

### **Why Self-Deployment is Better**
- ✅ **Full Control**: You own and control all code and infrastructure
- ✅ **Security**: No third-party access to your servers or code
- ✅ **Privacy**: Your API keys and data stay private
- ✅ **Customization**: Modify and extend as needed
- ✅ **Cost Control**: Direct relationship with cloud provider

### **Deployment Options**

#### **Option 1: GitHub + DigitalOcean (Recommended)**
```
Your Computer → GitHub (Private Repo) → DigitalOcean Droplet
```
- **Security**: Code stays in your private GitHub repo
- **Automation**: Push to deploy automatically
- **Backup**: Git history provides version control
- **Collaboration**: Easy team access when ready

#### **Option 2: Direct Upload to DigitalOcean**
```
Your Computer → SCP/SFTP → DigitalOcean Droplet
```
- **Security**: Direct file transfer, no third-party repos
- **Control**: Manual deployment process
- **Privacy**: Code never leaves your control

#### **Option 3: Local Development + Production Deploy**
```
Your Computer (Development) → Production Server (Manual Deploy)
```
- **Security**: Develop locally, deploy manually
- **Testing**: Full local testing before deployment
- **Control**: Complete manual oversight

---

## 🚀 **Secure Self-Deployment Process**

### **Phase 1: Prepare Your Environment**

#### **1. Set Up Your DigitalOcean Droplet**
```bash
# Recommended Droplet Configuration
Size: s-2vcpu-4gb ($24/month)
OS: Ubuntu 22.04 LTS
Region: Closest to your users
Backups: Enabled
Monitoring: Enabled
```

#### **2. Secure Your Droplet**
```bash
# SSH into your droplet
ssh root@YOUR_DROPLET_IP

# Update system
apt update && apt upgrade -y

# Create non-root user
adduser edgpt
usermod -aG sudo edgpt

# Configure SSH key authentication
mkdir -p /home/edgpt/.ssh
cp ~/.ssh/authorized_keys /home/edgpt/.ssh/
chown -R edgpt:edgpt /home/edgpt/.ssh
chmod 700 /home/edgpt/.ssh
chmod 600 /home/edgpt/.ssh/authorized_keys

# Disable root login
sed -i 's/PermitRootLogin yes/PermitRootLogin no/' /etc/ssh/sshd_config
systemctl restart ssh
```

#### **3. Install Required Software**
```bash
# Switch to edgpt user
su - edgpt

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker edgpt

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Install Nginx
sudo apt install nginx -y

# Install Certbot for SSL
sudo apt install certbot python3-certbot-nginx -y
```

### **Phase 2: Deploy Your Code**

#### **Method A: Using GitHub (Recommended)**

**1. Create Private GitHub Repository**
```bash
# On your computer, in the EdGPT project folder
git init
git add .
git commit -m "Initial EdGPT Platform commit"

# Create private repo on GitHub, then:
git remote add origin https://github.com/yourusername/edgpt-platform.git
git branch -M main
git push -u origin main
```

**2. Clone to Your Droplet**
```bash
# SSH into your droplet as edgpt user
ssh edgpt@YOUR_DROPLET_IP

# Clone your private repository
git clone https://github.com/yourusername/edgpt-platform.git
cd edgpt-platform
```

#### **Method B: Direct File Transfer**

**1. Prepare Your Code**
```bash
# On your computer, create deployment package
tar -czf edgpt-platform.tar.gz edgpt-platform/
```

**2. Transfer to Droplet**
```bash
# Upload to your droplet
scp edgpt-platform.tar.gz edgpt@YOUR_DROPLET_IP:~/

# SSH into droplet and extract
ssh edgpt@YOUR_DROPLET_IP
tar -xzf edgpt-platform.tar.gz
cd edgpt-platform
```

### **Phase 3: Configure Environment**

#### **1. Set Up Environment Variables**
```bash
# Create environment file
cp .env.example .env
nano .env

# Add your configuration:
FLASK_ENV=production
SECRET_KEY=your-secret-key-here
DATABASE_URL=postgresql://edgpt_user:password@localhost:5432/edgpt_platform
REDIS_URL=redis://localhost:6379/0

# AI Service Keys (add your own)
OPENAI_API_KEY=sk-your-openai-key
ANTHROPIC_API_KEY=sk-ant-your-anthropic-key
GOOGLE_AI_API_KEY=your-google-ai-key

# Email Configuration
SENDGRID_API_KEY=SG.your-sendgrid-key
SENDGRID_FROM_EMAIL=support@gptsites.ai

# Payment Configuration
STRIPE_SECRET_KEY=sk_live_your-stripe-key
STRIPE_PUBLIC_KEY=pk_live_your-stripe-key

# Domain Configuration
DOMAIN=gptsites.ai
CORS_ORIGINS=https://gptsites.ai,https://www.gptsites.ai
```

#### **2. Configure SSL Certificate**
```bash
# Generate SSL certificate for your domain
sudo certbot --nginx -d gptsites.ai -d www.gptsites.ai

# Set up auto-renewal
echo "0 12 * * * /usr/bin/certbot renew --quiet" | sudo crontab -
```

### **Phase 4: Deploy Services**

#### **1. Start Database Services**
```bash
# Start PostgreSQL and Redis
docker-compose up -d postgres redis

# Wait for services to start
sleep 30

# Initialize database
docker-compose exec backend flask db upgrade
```

#### **2. Build and Start Application**
```bash
# Build application containers
docker-compose build

# Start all services
docker-compose up -d

# Check service status
docker-compose ps
```

#### **3. Configure Nginx**
```bash
# Create Nginx configuration
sudo nano /etc/nginx/sites-available/edgpt

# Add configuration (see detailed config below)
# Enable site
sudo ln -s /etc/nginx/sites-available/edgpt /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### **Phase 5: Security Hardening**

#### **1. Configure Firewall**
```bash
# Set up UFW firewall
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
```

#### **2. Set Up Fail2Ban**
```bash
# Install and configure fail2ban
sudo apt install fail2ban -y
sudo systemctl enable fail2ban
sudo systemctl start fail2ban
```

#### **3. Configure Monitoring**
```bash
# Set up health check monitoring
crontab -e

# Add monitoring cron jobs:
*/5 * * * * curl -f http://localhost:5000/health || echo "Backend down" | mail -s "EdGPT Alert" your@email.com
0 2 * * * docker system prune -f
0 1 * * * docker-compose exec postgres pg_dump -U edgpt_user edgpt_platform > /home/edgpt/backups/db_$(date +%Y%m%d).sql
```

---

## 📋 **Detailed Nginx Configuration**

```nginx
# /etc/nginx/sites-available/edgpt

# Redirect HTTP to HTTPS
server {
    listen 80;
    server_name gptsites.ai www.gptsites.ai;
    return 301 https://$server_name$request_uri;
}

# Main HTTPS server
server {
    listen 443 ssl http2;
    server_name gptsites.ai www.gptsites.ai;
    
    # SSL Configuration
    ssl_certificate /etc/letsencrypt/live/gptsites.ai/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/gptsites.ai/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512;
    ssl_prefer_server_ciphers off;
    
    # Security Headers
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header X-Frame-Options DENY always;
    add_header X-Content-Type-Options nosniff always;
    add_header X-XSS-Protection "1; mode=block" always;
    
    # Rate Limiting
    limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
    limit_req_zone $binary_remote_addr zone=auth:10m rate=5r/s;
    
    # Frontend (React)
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
    
    # Backend API
    location /api/ {
        limit_req zone=api burst=20 nodelay;
        proxy_pass http://localhost:5000/api/;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # Authentication endpoints (stricter rate limiting)
    location /api/auth/ {
        limit_req zone=auth burst=10 nodelay;
        proxy_pass http://localhost:5000/api/auth/;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # Health check
    location /health {
        proxy_pass http://localhost:5000/health;
        access_log off;
    }
}
```

---

## 🔧 **Management & Maintenance**

### **Daily Operations**
```bash
# Check service status
docker-compose ps

# View logs
docker-compose logs -f

# Restart services
docker-compose restart

# Update application
git pull origin main
docker-compose build
docker-compose up -d
```

### **Backup Strategy**
```bash
# Database backup
docker-compose exec postgres pg_dump -U edgpt_user edgpt_platform > backup_$(date +%Y%m%d).sql

# Application backup
tar -czf app_backup_$(date +%Y%m%d).tar.gz edgpt-platform/

# Upload to DigitalOcean Spaces or S3
# Configure automated backups
```

### **Monitoring & Alerts**
```bash
# Set up monitoring endpoints
curl https://gptsites.ai/health
curl https://gptsites.ai/api/health

# Configure uptime monitoring (UptimeRobot, Pingdom, etc.)
# Set up log monitoring and alerts
```

---

## 💰 **Cost Breakdown**

### **Monthly Costs**
```
DigitalOcean Droplet (s-2vcpu-4gb): $24/month
DigitalOcean Backups: $4.80/month
Domain Registration: $12/year ($1/month)
SSL Certificate: Free (Let's Encrypt)
Monitoring Tools: $10-20/month (optional)

Total: ~$40-50/month
```

### **Scaling Costs**
```
Growth Stage (s-4vcpu-8gb): $48/month
High Traffic (s-8vcpu-16gb): $96/month
Load Balancer: $12/month (when needed)
Managed Database: $15-60/month (when needed)
```

---

## 🎯 **Security Best Practices**

### **Code Security**
- ✅ Use private GitHub repositories
- ✅ Never commit API keys or secrets
- ✅ Use environment variables for configuration
- ✅ Regular dependency updates
- ✅ Code review process

### **Infrastructure Security**
- ✅ SSH key authentication only
- ✅ Firewall configuration
- ✅ Regular security updates
- ✅ SSL/TLS encryption
- ✅ Rate limiting and DDoS protection

### **Application Security**
- ✅ JWT token authentication
- ✅ Input validation and sanitization
- ✅ SQL injection prevention
- ✅ XSS protection
- ✅ CSRF protection

---

## 🚀 **Deployment Checklist**

### **Pre-Deployment**
- [ ] DigitalOcean droplet created and secured
- [ ] Domain DNS pointed to droplet
- [ ] SSL certificate configured
- [ ] Environment variables set
- [ ] API keys obtained and configured

### **Deployment**
- [ ] Code uploaded/cloned to droplet
- [ ] Docker containers built and started
- [ ] Database initialized and migrated
- [ ] Nginx configured and started
- [ ] Services health checked

### **Post-Deployment**
- [ ] End-to-end testing completed
- [ ] Monitoring and alerts configured
- [ ] Backup strategy implemented
- [ ] Documentation updated
- [ ] Team access configured

---

## 🎊 **You're Ready to Deploy Securely!**

This guide gives you complete control over your EdGPT Platform deployment while maintaining security and privacy. You'll own and control:

✅ **Your Code** - Private repositories and secure deployment  
✅ **Your Infrastructure** - Direct DigitalOcean relationship  
✅ **Your Data** - Complete privacy and control  
✅ **Your API Keys** - Secure environment variable management  
✅ **Your Scaling** - Upgrade resources as needed  

**Need help with any specific step? I'm here to guide you through the secure deployment process!** 🔐

