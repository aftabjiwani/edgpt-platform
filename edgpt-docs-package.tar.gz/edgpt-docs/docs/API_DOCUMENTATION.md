# EdGPT Platform API Documentation

## 🔌 Complete API Reference for Developers

The EdGPT Platform v2.0 provides a comprehensive RESTful API for all platform functionality, including conversational AI, forms management, user authentication, and slideshow presentations. This documentation covers all available endpoints, request/response formats, and integration examples.

## 🚀 Base URL and Authentication

### Production Environment
```
Base URL: https://edgpt.ai/api
```

### Development Environment
```
Base URL: http://localhost:5000/api
```

### Authentication
Most API endpoints require authentication using session-based authentication or API keys.

```http
# Session-based (after login)
Cookie: session=your-session-token

# API Key authentication
Authorization: Bearer your-api-key
```

## 📋 Core API Endpoints

### 🏠 Landing Page and General

#### GET /
Returns the main landing page with embedded slideshow.

**Request:**
```http
GET / HTTP/1.1
Host: edgpt.ai
```

**Response:**
```html
<!DOCTYPE html>
<html>
<!-- Complete landing page HTML -->
</html>
```

#### GET /health
Health check endpoint for monitoring.

**Request:**
```http
GET /health HTTP/1.1
Host: edgpt.ai
```

**Response:**
```json
{
    "status": "healthy",
    "timestamp": "2025-08-05T01:54:00Z",
    "version": "2.0",
    "uptime": 86400
}
```

### 🎬 Slideshow API

#### GET /api/slideshow/{industry}
Returns industry-specific slideshow data.

**Parameters:**
- `industry` (string): One of `school`, `law`, `tax`, `cpa`, `business`, `broker`

**Request:**
```http
GET /api/slideshow/school HTTP/1.1
Host: edgpt.ai
```

**Response:**
```json
{
    "industry": "school",
    "title": "EdGPT for Schools",
    "slides": [
        {
            "id": "title_slide",
            "title": "Transform Your School Website Into an Intelligent EdGPT",
            "content": "...",
            "image": "/assets/edgpt_logo.png"
        },
        {
            "id": "statistics_slide",
            "title": "The Website Crisis: Why Traditional Sites Fail Visitors",
            "statistics": [
                {"value": "94.8%", "description": "of websites fail users with accessibility barriers"},
                {"value": "70%", "description": "of users prefer search over navigation"},
                {"value": "$6.9B", "description": "lost annually due to poor websites"}
            ]
        }
    ],
    "total_slides": 7,
    "branding": {
        "logo": "/assets/edgpt_logo.png",
        "colors": {
            "primary": "#6366f1",
            "secondary": "#8b5cf6"
        }
    }
}
```

#### POST /api/slideshow/navigate
Navigate to specific slide in slideshow.

**Request:**
```http
POST /api/slideshow/navigate HTTP/1.1
Host: edgpt.ai
Content-Type: application/json

{
    "industry": "school",
    "slide_index": 3,
    "direction": "next"
}
```

**Response:**
```json
{
    "success": true,
    "current_slide": 3,
    "total_slides": 7,
    "slide_data": {
        "id": "interactive_demo_slide",
        "title": "Interactive EdGPT Experience",
        "content": "..."
    }
}
```

### 💬 Conversation API

#### POST /api/chat
Send message to EdGPT and receive response.

**Request:**
```http
POST /api/chat HTTP/1.1
Host: edgpt.ai
Content-Type: application/json

{
    "message": "What are the school hours?",
    "context": "school",
    "user_id": "user_123",
    "voice_enabled": true
}
```

**Response:**
```json
{
    "response": "Our school hours are Monday through Friday, 8:00 AM to 3:30 PM. We also offer before-school care starting at 7:00 AM and after-school programs until 6:00 PM.",
    "response_type": "direct_answer",
    "confidence": 0.95,
    "voice_audio": "/api/audio/response_123.wav",
    "suggested_actions": [
        {
            "text": "Learn about enrollment",
            "action": "enrollment_info"
        },
        {
            "text": "View today's lunch menu",
            "action": "lunch_menu"
        }
    ],
    "timestamp": "2025-08-05T01:54:00Z"
}
```

#### POST /api/chat/voice
Process voice input and return text + audio response.

**Request:**
```http
POST /api/chat/voice HTTP/1.1
Host: edgpt.ai
Content-Type: multipart/form-data

audio_file: [binary audio data]
context: school
user_id: user_123
```

**Response:**
```json
{
    "transcribed_text": "What extracurricular activities are available?",
    "response": "We offer a variety of extracurricular activities including soccer, basketball, drama club, science club, art classes, and music lessons. All activities are available after school hours.",
    "audio_response": "/api/audio/response_124.wav",
    "confidence": 0.92,
    "processing_time": 1.2
}
```

### 👤 User Authentication

#### POST /api/auth/signup
Create new user account.

**Request:**
```http
POST /api/auth/signup HTTP/1.1
Host: edgpt.ai
Content-Type: application/json

{
    "school_name": "Lincoln Elementary School",
    "admin_name": "Dr. Sarah Johnson",
    "admin_title": "Principal",
    "admin_email": "principal@lincoln.edu",
    "website_url": "https://lincoln.edu",
    "student_count": "500-1000",
    "staff_contacts": [
        {
            "name": "Mary Smith",
            "department": "Administration",
            "email": "mary.smith@lincoln.edu",
            "phone": "(555) 123-4567"
        }
    ]
}
```

**Response:**
```json
{
    "success": true,
    "user_id": "user_456",
    "account_status": "trial",
    "trial_expires": "2025-08-12T01:54:00Z",
    "conversion_job_id": "job_789",
    "dashboard_url": "/dashboard",
    "message": "Account created successfully. Website conversion in progress."
}
```

#### POST /api/auth/login
Authenticate user and create session.

**Request:**
```http
POST /api/auth/login HTTP/1.1
Host: edgpt.ai
Content-Type: application/json

{
    "email": "principal@lincoln.edu",
    "password": "secure_password_123"
}
```

**Response:**
```json
{
    "success": true,
    "user_id": "user_456",
    "session_token": "sess_abc123def456",
    "account_type": "trial",
    "expires_in": 3600,
    "dashboard_url": "/dashboard"
}
```

#### POST /api/auth/logout
End user session.

**Request:**
```http
POST /api/auth/logout HTTP/1.1
Host: edgpt.ai
Cookie: session=sess_abc123def456
```

**Response:**
```json
{
    "success": true,
    "message": "Logged out successfully"
}
```

### 🏫 Website Conversion API

#### POST /api/conversion/start
Begin website conversion process.

**Request:**
```http
POST /api/conversion/start HTTP/1.1
Host: edgpt.ai
Content-Type: application/json
Authorization: Bearer your-api-key

{
    "website_url": "https://lincoln.edu",
    "user_id": "user_456",
    "conversion_type": "school",
    "priority": "high"
}
```

**Response:**
```json
{
    "success": true,
    "job_id": "conv_789abc",
    "status": "started",
    "estimated_completion": "2025-08-05T02:24:00Z",
    "progress_url": "/api/conversion/progress/conv_789abc",
    "initial_pages": 15,
    "total_pages_estimated": 45
}
```

#### GET /api/conversion/progress/{job_id}
Check conversion progress.

**Request:**
```http
GET /api/conversion/progress/conv_789abc HTTP/1.1
Host: edgpt.ai
Authorization: Bearer your-api-key
```

**Response:**
```json
{
    "job_id": "conv_789abc",
    "status": "processing",
    "progress_percentage": 65,
    "pages_processed": 29,
    "total_pages": 45,
    "current_phase": "content_extraction",
    "phases": [
        {"name": "website_discovery", "status": "completed", "duration": 120},
        {"name": "content_extraction", "status": "in_progress", "progress": 65},
        {"name": "knowledge_base_creation", "status": "pending"},
        {"name": "ai_training", "status": "pending"},
        {"name": "deployment", "status": "pending"}
    ],
    "estimated_completion": "2025-08-05T02:15:00Z",
    "statistics": {
        "pages_found": 45,
        "content_extracted": "2.3MB",
        "forms_detected": 8,
        "staff_contacts_found": 12
    }
}
```

#### GET /api/conversion/result/{job_id}
Get conversion results.

**Request:**
```http
GET /api/conversion/result/conv_789abc HTTP/1.1
Host: edgpt.ai
Authorization: Bearer your-api-key
```

**Response:**
```json
{
    "job_id": "conv_789abc",
    "status": "completed",
    "completion_time": "2025-08-05T02:12:00Z",
    "gptsite_url": "https://lincoln.edgpt.ai",
    "knowledge_base": {
        "total_entries": 156,
        "categories": ["enrollment", "academics", "staff", "events", "policies"],
        "forms_integrated": 8,
        "staff_contacts": 12
    },
    "features_enabled": [
        "voice_conversation",
        "forms_management",
        "message_center",
        "calendar_integration"
    ],
    "performance_metrics": {
        "response_time": "< 500ms",
        "accuracy_score": 0.94,
        "coverage_percentage": 98
    }
}
```

### 📋 Forms Management API

#### GET /api/forms
List all available forms.

**Request:**
```http
GET /api/forms HTTP/1.1
Host: edgpt.ai
Authorization: Bearer your-api-key
```

**Response:**
```json
{
    "forms": [
        {
            "id": "enrollment_form",
            "title": "Student Enrollment Application",
            "description": "Complete enrollment form for new students",
            "category": "enrollment",
            "fields": 15,
            "required_fields": 8,
            "estimated_time": "10-15 minutes",
            "status": "active"
        },
        {
            "id": "field_trip_permission",
            "title": "Field Trip Permission Slip",
            "description": "Permission form for student field trips",
            "category": "permissions",
            "fields": 6,
            "required_fields": 4,
            "estimated_time": "3-5 minutes",
            "status": "active"
        }
    ],
    "total_forms": 8,
    "categories": ["enrollment", "permissions", "lunch", "transportation", "emergency"]
}
```

#### GET /api/forms/{form_id}
Get specific form details and fields.

**Request:**
```http
GET /api/forms/enrollment_form HTTP/1.1
Host: edgpt.ai
Authorization: Bearer your-api-key
```

**Response:**
```json
{
    "id": "enrollment_form",
    "title": "Student Enrollment Application",
    "description": "Complete enrollment form for new students",
    "version": "2.1",
    "fields": [
        {
            "id": "student_name",
            "type": "text",
            "label": "Student Full Name",
            "required": true,
            "validation": "^[A-Za-z\\s]+$",
            "placeholder": "Enter student's full name"
        },
        {
            "id": "birth_date",
            "type": "date",
            "label": "Date of Birth",
            "required": true,
            "min_date": "2010-01-01",
            "max_date": "2020-12-31"
        },
        {
            "id": "grade_level",
            "type": "select",
            "label": "Grade Level",
            "required": true,
            "options": ["Kindergarten", "1st Grade", "2nd Grade", "3rd Grade", "4th Grade", "5th Grade"]
        }
    ],
    "submission_endpoint": "/api/forms/enrollment_form/submit",
    "success_message": "Enrollment application submitted successfully. You will receive a confirmation email within 24 hours."
}
```

#### POST /api/forms/{form_id}/submit
Submit completed form.

**Request:**
```http
POST /api/forms/enrollment_form/submit HTTP/1.1
Host: edgpt.ai
Content-Type: application/json
Authorization: Bearer your-api-key

{
    "student_name": "Emma Johnson",
    "birth_date": "2015-03-15",
    "grade_level": "3rd Grade",
    "parent_name": "Michael Johnson",
    "parent_email": "michael.johnson@email.com",
    "parent_phone": "(555) 987-6543",
    "emergency_contact": "Lisa Johnson",
    "emergency_phone": "(555) 987-6544",
    "medical_conditions": "None",
    "special_needs": "None"
}
```

**Response:**
```json
{
    "success": true,
    "submission_id": "sub_456def",
    "timestamp": "2025-08-05T01:54:00Z",
    "status": "received",
    "confirmation_number": "ENR-2025-0805-001",
    "next_steps": [
        "You will receive a confirmation email within 24 hours",
        "School staff will contact you to schedule an enrollment meeting",
        "Please bring required documents to the enrollment meeting"
    ],
    "staff_notified": true,
    "estimated_processing_time": "1-2 business days"
}
```

### 💌 Message Center API

#### GET /api/messages
Get all messages for authenticated user.

**Request:**
```http
GET /api/messages HTTP/1.1
Host: edgpt.ai
Authorization: Bearer your-api-key
```

**Response:**
```json
{
    "messages": [
        {
            "id": "msg_123",
            "type": "unanswered_query",
            "from": "parent@email.com",
            "subject": "Question about after-school programs",
            "message": "I'd like to know more about the after-school tutoring program. What subjects are covered and what are the costs?",
            "timestamp": "2025-08-05T01:30:00Z",
            "status": "unread",
            "priority": "normal",
            "assigned_to": "mary.smith@lincoln.edu"
        },
        {
            "id": "msg_124",
            "type": "form_submission",
            "from": "michael.johnson@email.com",
            "subject": "Enrollment Application Submitted",
            "message": "New enrollment application for Emma Johnson (3rd Grade)",
            "timestamp": "2025-08-05T01:54:00Z",
            "status": "unread",
            "priority": "high",
            "form_id": "enrollment_form",
            "submission_id": "sub_456def"
        }
    ],
    "total_messages": 15,
    "unread_count": 8,
    "filters": {
        "status": ["unread", "read", "archived"],
        "type": ["unanswered_query", "form_submission", "general_inquiry"],
        "priority": ["low", "normal", "high", "urgent"]
    }
}
```

#### POST /api/messages/{message_id}/reply
Reply to a message.

**Request:**
```http
POST /api/messages/msg_123/reply HTTP/1.1
Host: edgpt.ai
Content-Type: application/json
Authorization: Bearer your-api-key

{
    "reply_message": "Thank you for your interest in our after-school tutoring program. We offer tutoring in Math, Reading, and Science for grades 1-5. The cost is $15 per session or $200 for a monthly unlimited package. Please call our office at (555) 123-4567 to enroll.",
    "send_email": true,
    "mark_resolved": true
}
```

**Response:**
```json
{
    "success": true,
    "reply_id": "reply_789",
    "timestamp": "2025-08-05T02:00:00Z",
    "email_sent": true,
    "message_status": "resolved",
    "parent_notified": true
}
```

### 📊 Dashboard API

#### GET /api/dashboard/stats
Get dashboard statistics and metrics.

**Request:**
```http
GET /api/dashboard/stats HTTP/1.1
Host: edgpt.ai
Authorization: Bearer your-api-key
```

**Response:**
```json
{
    "overview": {
        "total_conversations": 1247,
        "conversations_today": 23,
        "average_response_time": "0.8s",
        "satisfaction_score": 4.7,
        "uptime_percentage": 99.9
    },
    "conversations": {
        "total_this_month": 456,
        "growth_percentage": 15.3,
        "most_common_topics": [
            {"topic": "enrollment", "count": 89, "percentage": 19.5},
            {"topic": "school_hours", "count": 67, "percentage": 14.7},
            {"topic": "lunch_menu", "count": 45, "percentage": 9.9}
        ]
    },
    "forms": {
        "total_submissions": 78,
        "submissions_this_week": 12,
        "most_popular_forms": [
            {"form": "enrollment_form", "submissions": 23},
            {"form": "field_trip_permission", "submissions": 18},
            {"form": "lunch_application", "submissions": 15}
        ]
    },
    "messages": {
        "total_messages": 34,
        "unread_messages": 8,
        "average_response_time": "2.3 hours",
        "resolution_rate": 94.1
    }
}
```

#### GET /api/dashboard/analytics
Get detailed analytics data.

**Request:**
```http
GET /api/dashboard/analytics HTTP/1.1
Host: edgpt.ai
Authorization: Bearer your-api-key
```

**Response:**
```json
{
    "time_period": "last_30_days",
    "conversation_trends": [
        {"date": "2025-07-06", "conversations": 15, "unique_users": 12},
        {"date": "2025-07-07", "conversations": 18, "unique_users": 14},
        {"date": "2025-07-08", "conversations": 22, "unique_users": 18}
    ],
    "user_engagement": {
        "average_session_duration": "4.2 minutes",
        "pages_per_session": 3.1,
        "bounce_rate": 12.3,
        "return_visitor_rate": 67.8
    },
    "performance_metrics": {
        "average_response_time": "0.8s",
        "successful_queries": 94.7,
        "escalated_to_staff": 5.3,
        "user_satisfaction": 4.7
    },
    "top_queries": [
        {"query": "What time does school start?", "count": 45},
        {"query": "How do I enroll my child?", "count": 38},
        {"query": "What's for lunch today?", "count": 29}
    ]
}
```

## 🔧 Integration Examples

### JavaScript Frontend Integration

```javascript
// Initialize EdGPT Chat
class EdGPTChat {
    constructor(apiKey, baseUrl = 'https://edgpt.ai/api') {
        this.apiKey = apiKey;
        this.baseUrl = baseUrl;
        this.sessionId = null;
    }

    async sendMessage(message, context = 'school') {
        const response = await fetch(`${this.baseUrl}/chat`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${this.apiKey}`
            },
            body: JSON.stringify({
                message: message,
                context: context,
                session_id: this.sessionId
            })
        });

        const data = await response.json();
        this.sessionId = data.session_id;
        return data;
    }

    async sendVoiceMessage(audioBlob, context = 'school') {
        const formData = new FormData();
        formData.append('audio_file', audioBlob);
        formData.append('context', context);
        formData.append('session_id', this.sessionId);

        const response = await fetch(`${this.baseUrl}/chat/voice`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${this.apiKey}`
            },
            body: formData
        });

        return await response.json();
    }
}

// Usage example
const chat = new EdGPTChat('your-api-key');

// Send text message
chat.sendMessage('What are the school hours?')
    .then(response => {
        console.log('EdGPT Response:', response.response);
        if (response.voice_audio) {
            // Play audio response
            const audio = new Audio(response.voice_audio);
            audio.play();
        }
    });

// Handle voice input
navigator.mediaDevices.getUserMedia({ audio: true })
    .then(stream => {
        const mediaRecorder = new MediaRecorder(stream);
        const audioChunks = [];

        mediaRecorder.ondataavailable = event => {
            audioChunks.push(event.data);
        };

        mediaRecorder.onstop = () => {
            const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
            chat.sendVoiceMessage(audioBlob)
                .then(response => {
                    console.log('Transcribed:', response.transcribed_text);
                    console.log('Response:', response.response);
                });
        };

        // Start recording
        mediaRecorder.start();
        
        // Stop recording after 5 seconds
        setTimeout(() => mediaRecorder.stop(), 5000);
    });
```

### Python Backend Integration

```python
import requests
import json

class EdGPTAPI:
    def __init__(self, api_key, base_url='https://edgpt.ai/api'):
        self.api_key = api_key
        self.base_url = base_url
        self.session = requests.Session()
        self.session.headers.update({
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json'
        })

    def send_message(self, message, context='school', user_id=None):
        """Send a message to EdGPT and get response"""
        payload = {
            'message': message,
            'context': context,
            'user_id': user_id
        }
        
        response = self.session.post(
            f'{self.base_url}/chat',
            json=payload
        )
        
        return response.json()

    def get_forms(self):
        """Get list of available forms"""
        response = self.session.get(f'{self.base_url}/forms')
        return response.json()

    def submit_form(self, form_id, form_data):
        """Submit a completed form"""
        response = self.session.post(
            f'{self.base_url}/forms/{form_id}/submit',
            json=form_data
        )
        return response.json()

    def get_messages(self, status=None, message_type=None):
        """Get messages from message center"""
        params = {}
        if status:
            params['status'] = status
        if message_type:
            params['type'] = message_type
            
        response = self.session.get(
            f'{self.base_url}/messages',
            params=params
        )
        return response.json()

    def start_conversion(self, website_url, user_id, conversion_type='school'):
        """Start website conversion process"""
        payload = {
            'website_url': website_url,
            'user_id': user_id,
            'conversion_type': conversion_type
        }
        
        response = self.session.post(
            f'{self.base_url}/conversion/start',
            json=payload
        )
        return response.json()

    def check_conversion_progress(self, job_id):
        """Check conversion progress"""
        response = self.session.get(
            f'{self.base_url}/conversion/progress/{job_id}'
        )
        return response.json()

# Usage example
api = EdGPTAPI('your-api-key')

# Send a message
response = api.send_message('What are the school hours?')
print(f"EdGPT: {response['response']}")

# Get available forms
forms = api.get_forms()
print(f"Available forms: {len(forms['forms'])}")

# Submit enrollment form
enrollment_data = {
    'student_name': 'Emma Johnson',
    'birth_date': '2015-03-15',
    'grade_level': '3rd Grade',
    'parent_name': 'Michael Johnson',
    'parent_email': 'michael.johnson@email.com'
}

result = api.submit_form('enrollment_form', enrollment_data)
print(f"Form submitted: {result['confirmation_number']}")

# Start website conversion
conversion = api.start_conversion(
    'https://lincoln.edu',
    'user_456',
    'school'
)
print(f"Conversion started: {conversion['job_id']}")

# Check progress
progress = api.check_conversion_progress(conversion['job_id'])
print(f"Progress: {progress['progress_percentage']}%")
```

### PHP Integration

```php
<?php
class EdGPTAPI {
    private $apiKey;
    private $baseUrl;
    
    public function __construct($apiKey, $baseUrl = 'https://edgpt.ai/api') {
        $this->apiKey = $apiKey;
        $this->baseUrl = $baseUrl;
    }
    
    private function makeRequest($endpoint, $method = 'GET', $data = null) {
        $url = $this->baseUrl . $endpoint;
        
        $options = [
            'http' => [
                'method' => $method,
                'header' => [
                    'Authorization: Bearer ' . $this->apiKey,
                    'Content-Type: application/json'
                ]
            ]
        ];
        
        if ($data && $method !== 'GET') {
            $options['http']['content'] = json_encode($data);
        }
        
        $context = stream_context_create($options);
        $response = file_get_contents($url, false, $context);
        
        return json_decode($response, true);
    }
    
    public function sendMessage($message, $context = 'school', $userId = null) {
        $data = [
            'message' => $message,
            'context' => $context,
            'user_id' => $userId
        ];
        
        return $this->makeRequest('/chat', 'POST', $data);
    }
    
    public function getForms() {
        return $this->makeRequest('/forms');
    }
    
    public function submitForm($formId, $formData) {
        return $this->makeRequest("/forms/{$formId}/submit", 'POST', $formData);
    }
    
    public function getMessages($status = null, $type = null) {
        $endpoint = '/messages';
        $params = [];
        
        if ($status) $params['status'] = $status;
        if ($type) $params['type'] = $type;
        
        if (!empty($params)) {
            $endpoint .= '?' . http_build_query($params);
        }
        
        return $this->makeRequest($endpoint);
    }
}

// Usage example
$api = new EdGPTAPI('your-api-key');

// Send message
$response = $api->sendMessage('What are the school hours?');
echo "EdGPT: " . $response['response'] . "\n";

// Get forms
$forms = $api->getForms();
echo "Available forms: " . count($forms['forms']) . "\n";

// Submit form
$enrollmentData = [
    'student_name' => 'Emma Johnson',
    'birth_date' => '2015-03-15',
    'grade_level' => '3rd Grade',
    'parent_name' => 'Michael Johnson',
    'parent_email' => 'michael.johnson@email.com'
];

$result = $api->submitForm('enrollment_form', $enrollmentData);
echo "Form submitted: " . $result['confirmation_number'] . "\n";
?>
```

## 🔒 Security and Rate Limiting

### API Rate Limits
- **Free Tier**: 100 requests per hour
- **Trial Accounts**: 500 requests per hour
- **Paid Accounts**: 5,000 requests per hour
- **Enterprise**: Custom limits

### Security Headers
All API responses include security headers:
```http
X-RateLimit-Limit: 500
X-RateLimit-Remaining: 487
X-RateLimit-Reset: 1625097600
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
X-XSS-Protection: 1; mode=block
```

### Error Handling
Standard HTTP status codes are used:

```json
{
    "error": {
        "code": 400,
        "message": "Invalid request format",
        "details": "The 'message' field is required",
        "timestamp": "2025-08-05T01:54:00Z",
        "request_id": "req_123abc"
    }
}
```

Common error codes:
- `400` - Bad Request
- `401` - Unauthorized
- `403` - Forbidden
- `404` - Not Found
- `429` - Too Many Requests
- `500` - Internal Server Error

## 📞 Support and Resources

### API Support
- **Documentation**: https://edgpt.ai/docs/api
- **Support Email**: api-support@gptai.com
- **Status Page**: https://status.edgpt.ai
- **Community Forum**: https://community.edgpt.ai

### SDKs and Libraries
- **JavaScript/Node.js**: `npm install edgpt-sdk`
- **Python**: `pip install edgpt-python`
- **PHP**: `composer require edgpt/php-sdk`
- **Ruby**: `gem install edgpt-ruby`

---

**© 2025 GPT AI Corporation. All rights reserved.**

*This API documentation provides complete integration guidance for the EdGPT Platform v2.0 RESTful API.*

