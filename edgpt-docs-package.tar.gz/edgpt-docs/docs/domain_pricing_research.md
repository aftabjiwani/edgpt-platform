# Domain Pricing Research

## GPTsites.ai Pricing (Business Domain)

**Billing:** Monthly credit card billing via Stripe API
**Trial:** 7-day free trial, no credit card required upfront
**Payment:** Credit card required after trial

### Pricing Plans:

**Silver Plan - $49/month**
- 5,000 chats/month
- 50 documents in knowledge base
- Standard AI models (GPT-4o Mini)
- AI-powered assistant setup
- Website knowledge extraction
- 24/7 automated responses
- Chat overage available ($5/500 chats)
- Basic analytics dashboard
- Email support

**Gold Plan - $99/month** (Most Popular)
- 25,000 chats/month
- 150 documents in knowledge base
- Premium AI models (GPT-4o, Claude, Gemini)
- Everything in Silver
- Advanced conversation flows
- Lead capture & routing
- Custom branding options
- Priority email support
- Phone support

**Platinum Plan - $149/month**
- Unlimited chats
- 500 documents in knowledge base
- Premium AI models included
- Everything in Gold
- Multiple AI assistants
- Advanced integrations
- Custom development
- Dedicated account manager
- 24/7 priority support

**Features Included in All Plans:**
- SSL security
- Automatic backups
- 99.9% uptime guarantee
- No setup fees
- Free migration
- 30-day money-back guarantee

**Trial Management:**
- 7-day free trial
- No credit card required initially
- Email alerts every 3 days during trial
- Credit card capture on day 3 alert for subscription
- One month free with credit card payment




## LawFirmGPT.ai Pricing (Legal Domain)

**Billing:** Monthly credit card billing via Stripe API
**Trial:** 7-day free trial, no credit card required upfront
**Payment:** Credit card required after trial

### Pricing Plans (Same as GPTsites):

**Silver Plan - $49/month**
- 5,000 chats/month
- 50 documents in knowledge base
- Standard AI models (GPT-4o Mini)
- AI-powered assistant setup
- Website knowledge extraction
- 24/7 automated responses
- Chat overage available ($5/500 chats)
- Basic analytics dashboard
- Email support

**Gold Plan - $99/month** (Most Popular)
- 25,000 chats/month
- 150 documents in knowledge base
- Premium AI models (GPT-4o, Claude, Gemini)
- Everything in Silver
- Advanced conversation flows
- Lead capture & routing
- Custom branding options
- Priority email support
- Phone support

**Platinum Plan - $149/month**
- Unlimited chats
- 500 documents in knowledge base
- Premium AI models included
- Everything in Gold
- Multiple AI assistants
- Advanced integrations
- Custom development
- Dedicated account manager
- 24/7 priority support

**Legal-Specific Features:**
- 24/7 AI Legal Assistant
- Client Inquiry Automation (85% automation rate)
- Lead Capture & Analytics
- Professional Management Tools
- Compliance with legal industry standards

**Trial Management:**
- 7-day free trial
- No credit card required initially
- Email alerts every 3 days during trial
- Credit card capture on day 3 alert for subscription
- One month free with credit card payment


## CPAFirm.ai Pricing (Accounting Domain)

**Billing:** Monthly credit card billing via Stripe API
**Trial:** 7-day free trial, no credit card required upfront
**Payment:** Credit card required after trial

### Pricing Plans (Same structure as other domains):

**Silver Plan - $49/month**
- 5,000 chats/month
- 50 documents in knowledge base
- Standard AI models (GPT-4o Mini)
- AI-powered assistant setup
- Website knowledge extraction
- 24/7 automated responses
- Chat overage available ($5/500 chats)
- Basic analytics dashboard
- Email support

**Gold Plan - $99/month** (Most Popular)
- 25,000 chats/month
- 150 documents in knowledge base
- Premium AI models (GPT-4o, Claude, Gemini)
- Everything in Silver
- Advanced conversation flows
- Lead capture & routing
- Custom branding options
- Priority email support
- Phone support

**Platinum Plan - $149/month**
- Unlimited chats
- 500 documents in knowledge base
- Premium AI models included
- Everything in Gold
- Multiple AI assistants
- Advanced integrations
- Custom development
- Dedicated account manager
- 24/7 priority support

**CPA-Specific Features:**
- AI Accounting Assistant (24/7 availability)
- Client Management Automation (90% automation rate)
- Advanced Analytics Suite
- Professional Dashboard
- Tax deadline reminders and document collection

**Trial Management:**
- 7-day free trial
- No credit card required initially
- Email alerts every 3 days during trial
- Credit card capture on day 3 alert for subscription
- One month free with credit card payment


## TaxPrepGPT.ai Pricing (Tax Preparation Domain)

**Billing:** Monthly credit card billing via Stripe API
**Trial:** 7-day free trial, no credit card required upfront
**Payment:** Credit card required after trial

### Pricing Plans (Same structure as other domains):

**Silver Plan - $49/month**
- 5,000 chats/month
- 50 documents in knowledge base
- Standard AI models (GPT-4o Mini)
- AI-powered assistant setup
- Website knowledge extraction
- 24/7 automated responses
- Chat overage available ($5/500 chats)
- Basic analytics dashboard
- Email support

**Gold Plan - $99/month** (Most Popular)
- 25,000 chats/month
- 150 documents in knowledge base
- Premium AI models (GPT-4o, Claude, Gemini)
- Everything in Silver
- Advanced conversation flows
- Lead capture & routing
- Custom branding options
- Priority email support
- Phone support

**Platinum Plan - $149/month**
- Unlimited chats
- 500 documents in knowledge base
- Premium AI models included
- Everything in Gold
- Multiple AI assistants
- Advanced integrations
- Custom development
- Dedicated account manager
- 24/7 priority support

**Tax-Specific Features:**
- AI Tax Season Assistant (24/7 availability)
- Tax Client Automation (95% automation rate)
- Peak Season Analytics (real-time)
- Tax Professional Tools
- Deadline reminders and document tracking

**Trial Management:**
- 7-day free trial
- No credit card required initially
- Email alerts every 3 days during trial
- Credit card capture on day 3 alert for subscription
- One month free with credit card payment


## BusinessBrokerGPT.ai Pricing (Business Brokerage Domain)

**Billing:** Monthly credit card billing via Stripe API
**Trial:** 7-day free trial, no credit card required upfront
**Payment:** Credit card required after trial

### Pricing Plans (Same structure as other domains):

**Silver Plan - $49/month**
- 5,000 chats/month
- 50 documents in knowledge base
- Standard AI models (GPT-4o Mini)
- AI-powered assistant setup
- Website knowledge extraction
- 24/7 automated responses
- Chat overage available ($5/500 chats)
- Basic analytics dashboard
- Email support

**Gold Plan - $99/month** (Most Popular)
- 25,000 chats/month
- 150 documents in knowledge base
- Premium AI models (GPT-4o, Claude, Gemini)
- Everything in Silver
- Advanced conversation flows
- Lead capture & routing
- Custom branding options
- Priority email support
- Phone support

**Platinum Plan - $149/month**
- Unlimited chats
- 500 documents in knowledge base
- Premium AI models included
- Everything in Gold
- Multiple AI assistants
- Advanced integrations
- Custom development
- Dedicated account manager
- 24/7 priority support

**Business Broker-Specific Features:**
- AI Business Broker Assistant (24/7 availability)
- Deal Flow Automation (80% automation rate)
- Transaction Analytics (advanced)
- Broker Management Suite
- Buyer qualification and seller onboarding

**Trial Management:**
- 7-day free trial
- No credit card required initially
- Email alerts every 3 days during trial
- Credit card capture on day 3 alert for subscription
- One month free with credit card payment

---

## EdGPT.ai Pricing (Educational Domain) - SPECIAL REQUIREMENTS

**Billing:** School-specific billing with fiscal year alignment
**Trial:** 7-day free trial, no credit card required upfront
**Payment Options:** Invoice OR Credit Card
**Fiscal Year:** July 1 - June 30 (all schools)

### EdGPT Pricing Structure:
- **NO PUBLIC PRICING** on landing page
- Pricing displayed ONLY inside school dashboard after login
- Custom pricing based on school size and requirements
- Invoice billing available for schools
- Credit card option with one month free bonus

### School Billing Features:
**Invoice Billing:**
- From: The GPT AI Corporation Inc.
- Address: PO Box 2434, Fullerton CA 92837
- Annual billing based on monthly price
- Prorated billing based on signup date within fiscal year
- Schools can choose invoice or credit card payment

**Credit Card Billing:**
- One month free with annual credit card payment
- Same prorated billing structure
- Stripe API integration for payments

**Trial Management for Schools:**
- 7-day free trial
- Email alerts every 3 days during trial
- Option to choose invoice or credit card on day 3
- Special school onboarding process

### Key Differences for EdGPT:
1. No pricing on public landing page
2. Custom pricing per school in dashboard
3. Fiscal year billing (July 1 - June 30)
4. Invoice option with GPT AI Corporation Inc. details
5. Prorated billing based on signup date
6. One month free with credit card annual payment
7. School-specific trial management process

