# Live DigitalOcean Deployment Guide - Step by Step

## 🎯 **Let's Get Your EdGPT Platform Live Right Now!**

Follow these exact steps to deploy your platform in 15 minutes.

---

## 📋 **Step 1: Get Your DigitalOcean API Token**

### **🔑 Create API Token**

1. **Go to DigitalOcean Dashboard**
   - Visit: https://cloud.digitalocean.com/account/api/tokens

2. **Generate New Token**
   - Click **"Generate New Token"**
   - **Name**: `EdGPT Platform Token`
   - **Scopes**: Select **"Read"** and **"Write"**
   - Click **"Generate Token"**

3. **Copy Your Token**
   - **IMPORTANT**: Copy the token immediately (you won't see it again!)
   - Save it somewhere safe - you'll need it in a moment
   - It looks like: `dop_v1_abc123def456...`

---

## 🔐 **Step 2: Set Up SSH Key**

### **🔑 Generate SSH Key (if you don't have one)**

**On Windows (PowerShell):**
```powershell
ssh-keygen -t ed25519 -C "support@gptsites.ai"
# Press Enter for default location
# Press Enter twice for no passphrase
type $env:USERPROFILE\.ssh\id_ed25519.pub
```

**On Mac/Linux (Terminal):**
```bash
ssh-keygen -t ed25519 -C "support@gptsites.ai"
# Press Enter for default location
# Press Enter twice for no passphrase
cat ~/.ssh/id_ed25519.pub
```

### **📤 Add SSH Key to DigitalOcean**

1. **Copy the SSH key output** from above command
2. **Go to DigitalOcean Security**
   - Visit: https://cloud.digitalocean.com/account/security
3. **Add SSH Key**
   - Click **"Add SSH Key"**
   - Paste your public key
   - **Name**: `EdGPT Platform Key`
   - Click **"Add SSH Key"**
4. **Note the Key ID**
   - After adding, note the key ID or fingerprint (you'll need this)

---

## 🚀 **Step 3: Deploy Your Platform**

### **📥 Download Deployment Package**

1. **Download the package** I provided earlier:
   - `DigitalOcean-EdGPT-Deployment.tar.gz`

2. **Extract the package**:

**On Windows:**
```powershell
# Extract using Windows Explorer or:
tar -xzf DigitalOcean-EdGPT-Deployment.tar.gz
cd digitalocean-deployment
```

**On Mac/Linux:**
```bash
tar -xzf DigitalOcean-EdGPT-Deployment.tar.gz
cd digitalocean-deployment
```

### **🎯 Run Deployment Command**

**Replace the placeholders with your actual values:**

```bash
./scripts/create-droplet.sh \
  --token YOUR_DO_API_TOKEN_HERE \
  --ssh-key YOUR_SSH_KEY_ID_HERE \
  --name edgpt-platform \
  --size s-2vcpu-4gb \
  --region nyc1 \
  --setup
```

**Example with real values:**
```bash
./scripts/create-droplet.sh \
  --token dop_v1_abc123def456... \
  --ssh-key 12:34:56:78:90:ab:cd:ef \
  --name edgpt-platform \
  --size s-2vcpu-4gb \
  --region nyc1 \
  --setup
```

### **⏱️ Wait for Deployment**

The script will:
1. **Create your droplet** (2-3 minutes)
2. **Install all software** (5-7 minutes)
3. **Deploy your platform** (3-5 minutes)
4. **Configure security** (2-3 minutes)

**Total time: ~15 minutes**

You'll see output like:
```
[INFO] Creating DigitalOcean droplet...
[SUCCESS] Droplet created successfully!
[INFO] Droplet IP: 123.456.789.012
[INFO] Waiting for droplet to be ready...
[SUCCESS] Droplet is active
[INFO] Running deployment script on droplet...
[SUCCESS] Deployment completed successfully
```

---

## 🌐 **Step 4: Configure Your Domain**

### **📍 Get Your Droplet IP**

After deployment completes, you'll see:
```
Droplet IP: 123.456.789.012
```

### **🔗 Point Your Domain to DigitalOcean**

**For gptsites.ai (or your domain):**

1. **Go to your domain registrar** (GoDaddy, Namecheap, etc.)
2. **Find DNS Management** or **DNS Settings**
3. **Add these DNS records:**

```
Type: A
Name: @
Value: 123.456.789.012
TTL: 300

Type: A  
Name: www
Value: 123.456.789.012
TTL: 300

Type: A
Name: api
Value: 123.456.789.012
TTL: 300
```

### **⏰ Wait for DNS Propagation**

- **DNS changes take 5-30 minutes** to propagate
- **Test with**: `nslookup gptsites.ai`
- **Should return your droplet IP**

---

## 🔧 **Step 5: Configure Your Platform**

### **🔑 Add Your API Keys**

1. **SSH into your droplet:**
```bash
ssh root@123.456.789.012
```

2. **Edit the environment file:**
```bash
nano /opt/edgpt-platform/.env
```

3. **Add your API keys:**
```bash
# AI Services
OPENAI_API_KEY=sk-your-openai-key-here
ANTHROPIC_API_KEY=sk-ant-your-anthropic-key
GOOGLE_AI_API_KEY=your-google-ai-key

# Email Service
SENDGRID_API_KEY=SG.your-sendgrid-key
SENDGRID_FROM_EMAIL=support@gptsites.ai

# Payment Processing
STRIPE_SECRET_KEY=sk_live_your-stripe-key
STRIPE_PUBLIC_KEY=pk_live_your-stripe-key

# Domain Configuration
DOMAIN=gptsites.ai
EMAIL=support@gptsites.ai
```

4. **Save and restart:**
```bash
# Press Ctrl+X, then Y, then Enter to save
edgpt-restart
```

---

## ✅ **Step 6: Test Your Platform**

### **🌐 Test Your Website**

1. **Visit your domain:**
   - Go to: `https://gptsites.ai`
   - Should show your EdGPT landing page

2. **Test the API:**
   - Go to: `https://gptsites.ai/health`
   - Should return: `{"status": "healthy"}`

3. **Test the chat:**
   - Try the live demo on your landing page
   - Should respond with AI-powered answers

### **📊 Check Platform Status**

```bash
# SSH into your droplet
ssh root@YOUR_DROPLET_IP

# Check all services
edgpt-status

# View logs
edgpt-logs

# Check health
edgpt-health
```

---

## 🎉 **Step 7: You're Live!**

### **🎯 Your Platform is Now Running:**

- **Frontend**: https://gptsites.ai
- **API**: https://gptsites.ai/api
- **Health Check**: https://gptsites.ai/health
- **Admin Dashboard**: https://gptsites.ai/admin

### **🔧 Management Commands:**

```bash
# Start services
edgpt-start

# Stop services  
edgpt-stop

# Restart services
edgpt-restart

# Check status
edgpt-status

# View logs
edgpt-logs

# Follow logs
edgpt-logs -f

# Create backup
edgpt-backup

# Update platform
edgpt-update
```

---

## 🚀 **Next Steps: Start Getting Customers**

### **📈 Immediate Actions:**

1. **Test all features** thoroughly
2. **Upload sample content** for demos
3. **Configure payment processing** 
4. **Start customer outreach** campaigns
5. **Monitor performance** and optimize

### **💰 Customer Acquisition:**

1. **Target small businesses** with websites
2. **Offer 7-day free trials**
3. **Focus on pain points**: website engagement, customer support
4. **Collect testimonials** from early customers
5. **Scale outreach** to 50+ prospects per day

### **📊 Track Key Metrics:**

- **Trial signups** per day
- **Trial-to-paid conversion** rate
- **Monthly recurring revenue** (MRR)
- **Customer satisfaction** scores
- **Platform performance** metrics

---

## 🆘 **If You Need Help**

### **🔧 Common Issues:**

**Platform not loading:**
```bash
ssh root@YOUR_IP
edgpt-restart
edgpt-logs
```

**SSL certificate issues:**
```bash
sudo certbot renew
sudo systemctl restart nginx
```

**High memory usage:**
```bash
edgpt-optimize
docker system prune -f
```

### **📞 Getting Support:**

1. **Check logs first**: `edgpt-logs`
2. **Try restart**: `edgpt-restart`
3. **GitHub issues**: Report problems
4. **Email support**: support@gptsites.ai

---

## 🎊 **Congratulations!**

**Your EdGPT Platform is now live and ready to generate revenue!**

### **What You've Accomplished:**

✅ **Enterprise-grade platform** deployed to DigitalOcean  
✅ **Automated SSL certificates** and security  
✅ **Professional domain** configuration  
✅ **AI-powered chat** system ready  
✅ **Payment processing** configured  
✅ **Monitoring and backups** automated  

### **Your Next 30 Days:**

- **Week 1**: Test and optimize platform
- **Week 2-3**: Acquire 25-50 customers  
- **Week 4**: Prepare for fundraising
- **Goal**: $1,500-3,500 MRR

**Your AI empire starts now!** 🚀

---

**Need help with any step? Let me know and I'll guide you through it!** 🎯

