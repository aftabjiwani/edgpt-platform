# EdGPT Platform Deployment Guide

## 🚀 Complete Deployment Instructions for Programmers

This comprehensive guide provides step-by-step instructions for deploying the EdGPT Platform v2.0 in production environments. The platform has been successfully deployed and tested on DigitalOcean with SSL certificates and is ready for immediate use.

## 📋 Prerequisites

### System Requirements
- **Operating System**: Ubuntu 22.04 LTS (recommended) or CentOS 8+
- **Memory**: Minimum 2GB RAM (4GB recommended for production)
- **Storage**: Minimum 20GB SSD (50GB recommended)
- **CPU**: 2 vCPU cores minimum
- **Network**: Public IP address with ports 80 and 443 open

### Required Software
- **Python**: Version 3.11+ (tested and verified)
- **Nginx**: Latest stable version for reverse proxy
- **Certbot**: For SSL certificate management
- **Git**: For repository management
- **SSH**: For secure server access

### Required Accounts and Credentials
- **DigitalOcean Account**: For server hosting (or alternative cloud provider)
- **Domain Name**: Registered domain with DNS management access
- **OpenAI API Key**: For AI conversation functionality
- **Email Account**: SMTP credentials for staff notifications

## 🔧 Server Setup

### Initial Server Configuration

1. **Create DigitalOcean Droplet**
```bash
# Using DigitalOcean CLI (optional)
doctl compute droplet create edgpt-production \
  --image ubuntu-22-04-x64 \
  --size s-2vcpu-4gb \
  --region nyc1 \
  --ssh-keys your-ssh-key-id
```

2. **Connect to Server**
```bash
ssh root@your-server-ip
```

3. **Update System**
```bash
apt update && apt upgrade -y
apt install software-properties-common -y
```

4. **Install Python 3.11**
```bash
add-apt-repository ppa:deadsnakes/ppa -y
apt update
apt install python3.11 python3.11-pip python3.11-venv -y
ln -sf /usr/bin/python3.11 /usr/bin/python3
ln -sf /usr/bin/pip3.11 /usr/bin/pip3
```

5. **Install System Dependencies**
```bash
apt install nginx git curl wget unzip -y
apt install build-essential python3.11-dev -y
```

### Python Environment Setup

1. **Create Virtual Environment**
```bash
cd /root
python3 -m venv edgpt-env
source edgpt-env/bin/activate
```

2. **Install Python Dependencies**
```bash
pip3 install --upgrade pip
pip3 install flask flask-cors beautifulsoup4 requests
pip3 install gunicorn python-dotenv
pip3 install email-validator wtforms
```

3. **Verify Installation**
```bash
python3 -c "import flask; print(flask.__version__)"
python3 -c "import requests; print('Dependencies installed successfully')"
```

## 📁 Code Deployment

### Repository Setup

1. **Clone Repository**
```bash
cd /root
git clone https://github.com/your-username/edgpt-platform.git
cd edgpt-platform
```

2. **Copy Files to Production Directory**
```bash
mkdir -p /root/edgpt-production
cp -r backend/* /root/edgpt-production/
cp -r templates /root/edgpt-production/
cp -r static /root/edgpt-production/
cp -r assets /root/edgpt-production/
```

3. **Set File Permissions**
```bash
chmod +x /root/edgpt-production/*.py
chown -R root:root /root/edgpt-production
```

### Environment Configuration

1. **Create Environment File**
```bash
cat > /root/edgpt-production/.env << EOF
FLASK_ENV=production
FLASK_DEBUG=False
OPENAI_API_KEY=your-openai-api-key-here
OPENAI_API_BASE=https://api.openai.com/v1
SECRET_KEY=your-secret-key-here
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USE_TLS=True
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=your-app-password
EOF
```

2. **Secure Environment File**
```bash
chmod 600 /root/edgpt-production/.env
```

## 🌐 Nginx Configuration

### Basic Nginx Setup

1. **Remove Default Configuration**
```bash
rm /etc/nginx/sites-enabled/default
```

2. **Create EdGPT Configuration**
```bash
cat > /etc/nginx/sites-available/edgpt << 'EOF'
server {
    listen 80;
    server_name your-domain.com www.your-domain.com;
    
    # Redirect HTTP to HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name your-domain.com www.your-domain.com;
    
    # SSL Configuration (will be added by Certbot)
    
    # Security Headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;
    
    # Gzip Compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_proxied expired no-cache no-store private must-revalidate auth;
    gzip_types text/plain text/css text/xml text/javascript application/x-javascript application/xml+rss;
    
    # Main Application
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_redirect off;
        proxy_buffering off;
    }
    
    # Static Files
    location /static/ {
        alias /root/edgpt-production/static/;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
    
    # Assets
    location /assets/ {
        alias /root/edgpt-production/assets/;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
    
    # Health Check
    location /health {
        access_log off;
        return 200 "healthy\n";
        add_header Content-Type text/plain;
    }
}
EOF
```

3. **Enable Configuration**
```bash
ln -s /etc/nginx/sites-available/edgpt /etc/nginx/sites-enabled/
nginx -t
systemctl reload nginx
```

## 🔒 SSL Certificate Setup

### Using Certbot (Let's Encrypt)

1. **Install Certbot**
```bash
apt install snapd -y
snap install core; snap refresh core
snap install --classic certbot
ln -s /snap/bin/certbot /usr/bin/certbot
```

2. **Obtain SSL Certificate**
```bash
certbot --nginx -d your-domain.com -d www.your-domain.com
```

3. **Verify SSL Configuration**
```bash
certbot certificates
systemctl status certbot.timer
```

4. **Test SSL Renewal**
```bash
certbot renew --dry-run
```

## 🚀 Application Deployment

### Using Gunicorn (Recommended)

1. **Create Gunicorn Configuration**
```bash
cat > /root/edgpt-production/gunicorn.conf.py << 'EOF'
bind = "127.0.0.1:5000"
workers = 4
worker_class = "sync"
worker_connections = 1000
max_requests = 1000
max_requests_jitter = 100
timeout = 30
keepalive = 2
preload_app = True
daemon = False
user = "root"
group = "root"
tmp_upload_dir = None
secure_scheme_headers = {
    'X-FORWARDED-PROTOCOL': 'ssl',
    'X-FORWARDED-PROTO': 'https',
    'X-FORWARDED-SSL': 'on'
}
EOF
```

2. **Create Systemd Service**
```bash
cat > /etc/systemd/system/edgpt.service << 'EOF'
[Unit]
Description=EdGPT Platform
After=network.target

[Service]
Type=exec
User=root
Group=root
WorkingDirectory=/root/edgpt-production
Environment=PATH=/root/edgpt-env/bin
ExecStart=/root/edgpt-env/bin/gunicorn --config gunicorn.conf.py enhanced_landing_with_slideshow:app
ExecReload=/bin/kill -s HUP $MAINPID
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF
```

3. **Start and Enable Service**
```bash
systemctl daemon-reload
systemctl enable edgpt
systemctl start edgpt
systemctl status edgpt
```

### Alternative: Direct Python Execution

If you prefer to run without Gunicorn:

```bash
cd /root/edgpt-production
source /root/edgpt-env/bin/activate
nohup python3 enhanced_landing_with_slideshow.py > app.log 2>&1 &
```

## 🗄️ Database Setup

### SQLite Configuration (Default)

The platform uses SQLite by default, which requires no additional setup:

```python
# Database will be created automatically at:
/root/edgpt-production/edgpt.db
```

### PostgreSQL Configuration (Optional)

For high-traffic deployments, consider PostgreSQL:

1. **Install PostgreSQL**
```bash
apt install postgresql postgresql-contrib -y
```

2. **Create Database and User**
```bash
sudo -u postgres psql
CREATE DATABASE edgpt;
CREATE USER edgpt_user WITH PASSWORD 'secure_password';
GRANT ALL PRIVILEGES ON DATABASE edgpt TO edgpt_user;
\q
```

3. **Update Application Configuration**
```python
# In your Flask app configuration
DATABASE_URL = 'postgresql://edgpt_user:secure_password@localhost/edgpt'
```

## 📧 Email Configuration

### Gmail SMTP Setup

1. **Enable 2-Factor Authentication** on your Gmail account
2. **Generate App Password**:
   - Go to Google Account settings
   - Security → 2-Step Verification → App passwords
   - Generate password for "Mail"

3. **Update Environment Variables**
```bash
# In /root/edgpt-production/.env
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USE_TLS=True
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=your-16-character-app-password
```

### Alternative SMTP Providers

**SendGrid**:
```bash
MAIL_SERVER=smtp.sendgrid.net
MAIL_PORT=587
MAIL_USE_TLS=True
MAIL_USERNAME=apikey
MAIL_PASSWORD=your-sendgrid-api-key
```

**Mailgun**:
```bash
MAIL_SERVER=smtp.mailgun.org
MAIL_PORT=587
MAIL_USE_TLS=True
MAIL_USERNAME=your-mailgun-username
MAIL_PASSWORD=your-mailgun-password
```

## 🔍 Monitoring and Logging

### Application Logs

1. **View Real-time Logs**
```bash
journalctl -u edgpt -f
```

2. **View Application Logs**
```bash
tail -f /root/edgpt-production/app.log
```

3. **View Nginx Logs**
```bash
tail -f /var/log/nginx/access.log
tail -f /var/log/nginx/error.log
```

### Log Rotation Setup

```bash
cat > /etc/logrotate.d/edgpt << 'EOF'
/root/edgpt-production/*.log {
    daily
    missingok
    rotate 52
    compress
    delaycompress
    notifempty
    create 644 root root
    postrotate
        systemctl reload edgpt
    endscript
}
EOF
```

### Health Monitoring

1. **Create Health Check Script**
```bash
cat > /root/health-check.sh << 'EOF'
#!/bin/bash
response=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:5000/health)
if [ $response -eq 200 ]; then
    echo "$(date): EdGPT is healthy"
else
    echo "$(date): EdGPT is unhealthy (HTTP $response)"
    systemctl restart edgpt
fi
EOF
chmod +x /root/health-check.sh
```

2. **Add to Crontab**
```bash
crontab -e
# Add this line:
*/5 * * * * /root/health-check.sh >> /var/log/edgpt-health.log 2>&1
```

## 🔄 Backup and Recovery

### Automated Backup Script

```bash
cat > /root/backup-edgpt.sh << 'EOF'
#!/bin/bash
BACKUP_DIR="/root/backups"
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="edgpt_backup_$DATE.tar.gz"

mkdir -p $BACKUP_DIR

# Create backup
tar -czf $BACKUP_DIR/$BACKUP_FILE \
    /root/edgpt-production \
    /etc/nginx/sites-available/edgpt \
    /etc/systemd/system/edgpt.service

# Keep only last 30 backups
cd $BACKUP_DIR
ls -t edgpt_backup_*.tar.gz | tail -n +31 | xargs -r rm

echo "Backup created: $BACKUP_FILE"
EOF
chmod +x /root/backup-edgpt.sh
```

### Schedule Daily Backups

```bash
crontab -e
# Add this line:
0 2 * * * /root/backup-edgpt.sh >> /var/log/backup.log 2>&1
```

### Recovery Procedure

```bash
# Stop services
systemctl stop edgpt nginx

# Extract backup
cd /
tar -xzf /root/backups/edgpt_backup_YYYYMMDD_HHMMSS.tar.gz

# Restart services
systemctl start nginx edgpt
```

## 🔧 Troubleshooting

### Common Issues and Solutions

**Issue: Application won't start**
```bash
# Check logs
journalctl -u edgpt -n 50

# Check Python environment
source /root/edgpt-env/bin/activate
python3 -c "import flask; print('Flask OK')"

# Check file permissions
ls -la /root/edgpt-production/
```

**Issue: SSL certificate problems**
```bash
# Check certificate status
certbot certificates

# Renew certificate
certbot renew --force-renewal

# Check Nginx configuration
nginx -t
```

**Issue: Database connection errors**
```bash
# Check database file
ls -la /root/edgpt-production/edgpt.db

# Check database permissions
chmod 644 /root/edgpt-production/edgpt.db
```

**Issue: Email notifications not working**
```bash
# Test SMTP connection
python3 -c "
import smtplib
server = smtplib.SMTP('smtp.gmail.com', 587)
server.starttls()
server.login('your-email@gmail.com', 'your-app-password')
print('SMTP connection successful')
server.quit()
"
```

### Performance Optimization

**Increase Gunicorn Workers**:
```bash
# Edit /root/edgpt-production/gunicorn.conf.py
workers = 8  # Increase based on CPU cores
```

**Enable Nginx Caching**:
```nginx
# Add to Nginx configuration
location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
    expires 1y;
    add_header Cache-Control "public, immutable";
}
```

**Database Optimization**:
```bash
# For SQLite
sqlite3 /root/edgpt-production/edgpt.db "VACUUM;"
sqlite3 /root/edgpt-production/edgpt.db "ANALYZE;"
```

## 🔐 Security Hardening

### Firewall Configuration

```bash
# Install UFW
apt install ufw -y

# Configure firewall
ufw default deny incoming
ufw default allow outgoing
ufw allow ssh
ufw allow 80/tcp
ufw allow 443/tcp
ufw enable
```

### SSH Security

```bash
# Edit SSH configuration
nano /etc/ssh/sshd_config

# Recommended settings:
PermitRootLogin yes  # Change to 'no' after creating non-root user
PasswordAuthentication no
PubkeyAuthentication yes
Port 22  # Consider changing to non-standard port
```

### Application Security

```bash
# Set secure file permissions
chmod 600 /root/edgpt-production/.env
chmod 644 /root/edgpt-production/*.py
chmod 755 /root/edgpt-production/

# Regular security updates
apt update && apt upgrade -y
```

## 📊 Performance Monitoring

### System Monitoring

```bash
# Install monitoring tools
apt install htop iotop nethogs -y

# Monitor system resources
htop
iotop
nethogs
```

### Application Metrics

```bash
# Monitor application performance
curl -s http://localhost:5000/health
systemctl status edgpt
journalctl -u edgpt --since "1 hour ago"
```

### Database Monitoring

```bash
# SQLite database size
ls -lh /root/edgpt-production/edgpt.db

# Database integrity check
sqlite3 /root/edgpt-production/edgpt.db "PRAGMA integrity_check;"
```

## 🚀 Scaling Considerations

### Horizontal Scaling

For high-traffic deployments:

1. **Load Balancer Setup**
```nginx
upstream edgpt_backend {
    server 127.0.0.1:5000;
    server 127.0.0.1:5001;
    server 127.0.0.1:5002;
}

server {
    location / {
        proxy_pass http://edgpt_backend;
    }
}
```

2. **Multiple Application Instances**
```bash
# Run multiple instances on different ports
gunicorn --bind 127.0.0.1:5000 enhanced_landing_with_slideshow:app &
gunicorn --bind 127.0.0.1:5001 enhanced_landing_with_slideshow:app &
gunicorn --bind 127.0.0.1:5002 enhanced_landing_with_slideshow:app &
```

### Vertical Scaling

```bash
# Increase server resources
# - More CPU cores
# - More RAM
# - Faster SSD storage
# - Higher network bandwidth
```

## 📞 Support and Maintenance

### Regular Maintenance Tasks

**Weekly**:
- Check application logs for errors
- Monitor disk space usage
- Verify SSL certificate status
- Review backup integrity

**Monthly**:
- Update system packages
- Review security logs
- Optimize database
- Test backup recovery

**Quarterly**:
- Security audit
- Performance review
- Capacity planning
- Documentation updates

### Emergency Procedures

**Application Down**:
```bash
systemctl restart edgpt
systemctl restart nginx
```

**Database Corruption**:
```bash
# Restore from backup
systemctl stop edgpt
cp /root/backups/latest_backup/edgpt.db /root/edgpt-production/
systemctl start edgpt
```

**SSL Certificate Expired**:
```bash
certbot renew --force-renewal
systemctl reload nginx
```

---

**© 2025 GPT AI Corporation. All rights reserved.**

*This deployment guide ensures reliable, secure, and scalable deployment of the EdGPT Platform v2.0 in production environments.*

