# SSH Key Creation Guide - Step by Step

## 🔑 **What is an SSH Key?**

An SSH key is like a super-secure password that lets you connect to your server safely. It's actually two files:
- **Private key**: Stays on your computer (never share this!)
- **Public key**: Goes to DigitalOcean (safe to share)

---

## 💻 **Step-by-Step SSH Key Creation**

### **🪟 For Windows Users**

#### **Option 1: Using PowerShell (Recommended)**

1. **Open PowerShell**
   - Press `Windows + R`
   - Type `powershell`
   - Press Enter

2. **Run this command:**
```powershell
ssh-keygen -t ed25519 -C "support@gptsites.ai"
```

3. **You'll see this:**
```
Generating public/private ed25519 key pair.
Enter file in which to save the key (C:\Users\YourName\.ssh\id_ed25519):
```
**Just press Enter** (use default location)

4. **You'll see this:**
```
Enter passphrase (empty for no passphrase):
```
**Just press Enter** (no passphrase for simplicity)

5. **You'll see this:**
```
Enter same passphrase again:
```
**Just press Enter again**

6. **Success! You'll see:**
```
Your identification has been saved in C:\Users\YourName\.ssh\id_ed25519
Your public key has been saved in C:\Users\YourName\.ssh\id_ed25519.pub
The key fingerprint is:
SHA256:abc123def456... support@gptsites.ai
```

7. **Get your public key:**
```powershell
type $env:USERPROFILE\.ssh\id_ed25519.pub
```

#### **Option 2: Using Command Prompt**

1. **Open Command Prompt**
   - Press `Windows + R`
   - Type `cmd`
   - Press Enter

2. **Run this command:**
```cmd
ssh-keygen -t ed25519 -C "support@gptsites.ai"
```

3. **Follow the same steps as PowerShell above**

4. **Get your public key:**
```cmd
type %USERPROFILE%\.ssh\id_ed25519.pub
```

### **🍎 For Mac Users**

1. **Open Terminal**
   - Press `Cmd + Space`
   - Type `terminal`
   - Press Enter

2. **Run this command:**
```bash
ssh-keygen -t ed25519 -C "support@gptsites.ai"
```

3. **Follow the same prompts as Windows (just press Enter for each)**

4. **Get your public key:**
```bash
cat ~/.ssh/id_ed25519.pub
```

### **🐧 For Linux Users**

1. **Open Terminal**
   - Press `Ctrl + Alt + T`

2. **Run this command:**
```bash
ssh-keygen -t ed25519 -C "support@gptsites.ai"
```

3. **Follow the same prompts (just press Enter for each)**

4. **Get your public key:**
```bash
cat ~/.ssh/id_ed25519.pub
```

---

## 🔍 **What Your SSH Key Looks Like**

### **📄 Your Public Key Will Look Like This:**

```
ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIGQw7+kPtO9lVK8B3p2xQf5mN8hL9dR2sT6vU4wX1yZ3 support@gptsites.ai
```

**Key parts:**
- `ssh-ed25519` - The key type
- `AAAAC3NzaC1lZDI1NTE5AAAAIGQw7+kPtO9lVK8B3p2xQf5mN8hL9dR2sT6vU4wX1yZ3` - The actual key (yours will be different)
- `support@gptsites.ai` - Your email/comment

### **📋 Copy This Entire Line**

**IMPORTANT**: Copy the ENTIRE line, including:
- The `ssh-ed25519` part at the beginning
- The long string of letters/numbers in the middle  
- The email at the end

---

## 📤 **Add SSH Key to DigitalOcean**

### **Step 1: Copy Your Public Key**

After running the command above, you'll see output like:
```
ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIGQw7+kPtO9lVK8B3p2xQf5mN8hL9dR2sT6vU4wX1yZ3 support@gptsites.ai
```

**Select and copy this ENTIRE line**

### **Step 2: Add to DigitalOcean**

1. **Go to DigitalOcean**
   - Visit: https://cloud.digitalocean.com/account/security

2. **Click "Add SSH Key"**

3. **Paste Your Key**
   - In the big text box, paste your entire public key
   - **Name**: `EdGPT Platform Key`

4. **Click "Add SSH Key"**

5. **Note the Key Info**
   - After adding, you'll see your key listed
   - Note the **fingerprint** (looks like: `12:34:56:78:90:ab:cd:ef`)
   - Or note the **ID number**

---

## 🔍 **Troubleshooting**

### **❌ "ssh-keygen command not found"**

**On Windows:**
- Install Git for Windows: https://git-scm.com/download/win
- Or use Windows Subsystem for Linux (WSL)

**On Mac:**
- SSH should be pre-installed
- If not, install Xcode Command Line Tools: `xcode-select --install`

### **❌ "Permission denied" or "Access denied"**

- Make sure you're running as administrator (Windows)
- Or use `sudo` on Mac/Linux if needed

### **❌ "File already exists"**

If you see:
```
/Users/yourname/.ssh/id_ed25519 already exists.
Overwrite (y/n)?
```

**Type `n` and press Enter**, then:
```bash
cat ~/.ssh/id_ed25519.pub
```
(Use your existing key)

---

## 📋 **What You Need for Deployment**

After creating your SSH key, you'll have:

1. **Your API Token** (from DigitalOcean dashboard)
   - Looks like: `dop_v1_abc123def456...`

2. **Your SSH Key Fingerprint** (from DigitalOcean security page)
   - Looks like: `12:34:56:78:90:ab:cd:ef`
   - Or an ID number like: `12345678`

**Save both of these - you'll need them for deployment!**

---

## 🚀 **Ready for Deployment?**

Once you have:
- ✅ SSH key created
- ✅ SSH key added to DigitalOcean  
- ✅ API token from DigitalOcean
- ✅ SSH key fingerprint/ID noted

**You're ready to deploy your platform!**

---

## 💡 **Quick Reference**

### **Create SSH Key:**
```bash
ssh-keygen -t ed25519 -C "support@gptsites.ai"
```

### **View Public Key:**

**Windows PowerShell:**
```powershell
type $env:USERPROFILE\.ssh\id_ed25519.pub
```

**Windows Command Prompt:**
```cmd
type %USERPROFILE%\.ssh\id_ed25519.pub
```

**Mac/Linux:**
```bash
cat ~/.ssh/id_ed25519.pub
```

### **Add to DigitalOcean:**
- Go to: https://cloud.digitalocean.com/account/security
- Click "Add SSH Key"
- Paste your public key
- Name it "EdGPT Platform Key"

---

**Need help with any step? Let me know exactly what you see and I'll guide you through it!** 🎯

