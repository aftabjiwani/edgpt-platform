# EdGPT Platform Testing Guide

## AI-Powered Website Intelligence Platform

This guide provides comprehensive testing procedures for the EdGPT platform, including unit tests, integration tests, end-to-end tests, and manual testing procedures.

## Table of Contents

1. [Testing Overview](#testing-overview)
2. [Test Environment Setup](#test-environment-setup)
3. [Unit Testing](#unit-testing)
4. [Integration Testing](#integration-testing)
5. [End-to-End Testing](#end-to-end-testing)
6. [API Testing](#api-testing)
7. [Performance Testing](#performance-testing)
8. [Security Testing](#security-testing)
9. [Manual Testing](#manual-testing)
10. [Deployment Testing](#deployment-testing)

## Testing Overview

The EdGPT platform uses a comprehensive testing strategy that includes:

- **Unit Tests**: Test individual components and functions
- **Integration Tests**: Test component interactions and API endpoints
- **End-to-End Tests**: Test complete user workflows
- **Performance Tests**: Test system performance under load
- **Security Tests**: Test security vulnerabilities and compliance
- **Manual Tests**: Test user experience and edge cases

### Testing Stack

- **Backend**: pytest, pytest-flask, factory-boy, faker
- **Frontend**: Jest, React Testing Library, Cypress
- **API**: Postman, curl, custom test scripts
- **Performance**: Artillery, Apache Bench, Lighthouse
- **Security**: OWASP ZAP, Bandit, Safety

## Test Environment Setup

### Prerequisites

```bash
# Install testing dependencies
pip install pytest pytest-flask pytest-cov factory-boy faker
npm install --save-dev jest @testing-library/react @testing-library/jest-dom cypress
```

### Environment Configuration

Create a test environment configuration:

```bash
# Copy test environment template
cp .env.example .env.test

# Configure test settings
cat >> .env.test << EOF
FLASK_ENV=testing
DATABASE_URL=sqlite:///test.db
REDIS_URL=redis://localhost:6379/1
SECRET_KEY=test-secret-key
JWT_SECRET_KEY=test-jwt-secret
OPENAI_API_KEY=test-openai-key
EOF
```

### Test Database Setup

```bash
# Create test database
docker-compose -f docker-compose.test.yml up -d postgres redis

# Initialize test database
python -c "
import os
os.environ['FLASK_ENV'] = 'testing'
from src.database import init_db
init_db()
"
```

## Unit Testing

### Backend Unit Tests

#### Test Structure

```
backend/tests/
├── conftest.py              # Test configuration and fixtures
├── test_models/             # Model tests
│   ├── test_user.py
│   ├── test_organization.py
│   └── test_conversation.py
├── test_services/           # Service tests
│   ├── test_ai_service.py
│   └── test_email_service.py
├── test_routes/             # Route tests
│   ├── test_auth.py
│   ├── test_chat.py
│   └── test_dashboard.py
└── test_utils/              # Utility tests
    └── test_validators.py
```

#### Example Test Configuration

```python
# backend/tests/conftest.py
import pytest
import tempfile
import os
from src.app import create_app
from src.database import db
from src.config import TestingConfig

@pytest.fixture
def app():
    """Create application for testing."""
    app = create_app(TestingConfig)
    
    with app.app_context():
        db.create_all()
        yield app
        db.drop_all()

@pytest.fixture
def client(app):
    """Create test client."""
    return app.test_client()

@pytest.fixture
def auth_headers(client):
    """Create authentication headers."""
    # Create test user and login
    response = client.post('/api/auth/login', json={
        'email': 'test@example.com',
        'password': 'testpassword'
    })
    token = response.json['access_token']
    return {'Authorization': f'Bearer {token}'}
```

#### Example Model Tests

```python
# backend/tests/test_models/test_user.py
import pytest
from src.models.user import User
from src.database import db

class TestUser:
    def test_create_user(self, app):
        """Test user creation."""
        with app.app_context():
            user = User(
                email='test@example.com',
                first_name='Test',
                last_name='User'
            )
            user.set_password('password123')
            user.save()
            
            assert user.id is not None
            assert user.email == 'test@example.com'
            assert user.check_password('password123')
    
    def test_user_validation(self, app):
        """Test user validation."""
        with app.app_context():
            # Test invalid email
            user = User(email='invalid-email')
            with pytest.raises(ValueError):
                user.save()
    
    def test_password_hashing(self, app):
        """Test password hashing."""
        with app.app_context():
            user = User(email='test@example.com')
            user.set_password('password123')
            
            assert user.password_hash != 'password123'
            assert user.check_password('password123')
            assert not user.check_password('wrongpassword')
```

#### Example Service Tests

```python
# backend/tests/test_services/test_ai_service.py
import pytest
from unittest.mock import Mock, patch
from src.services.ai_service import AIService

class TestAIService:
    def test_provider_selection(self):
        """Test AI provider selection logic."""
        ai_service = AIService()
        
        # Mock providers
        ai_service.providers = {
            'openai': {'quality_tier': 'high', 'cost_tier': 'high'},
            'ollama': {'quality_tier': 'medium', 'cost_tier': 'free'}
        }
        
        # Test high quality preference
        provider, info = ai_service.select_optimal_provider(
            query_complexity='high',
            cost_preference='high_quality'
        )
        assert provider == 'openai'
        
        # Test low cost preference
        provider, info = ai_service.select_optimal_provider(
            query_complexity='low',
            cost_preference='low_cost'
        )
        assert provider == 'ollama'
    
    @patch('openai.ChatCompletion.create')
    def test_openai_integration(self, mock_openai):
        """Test OpenAI API integration."""
        # Mock OpenAI response
        mock_response = Mock()
        mock_response.choices = [Mock()]
        mock_response.choices[0].message.content = "Test response"
        mock_response.usage.total_tokens = 100
        mock_openai.return_value = mock_response
        
        ai_service = AIService()
        # Test implementation
```

### Frontend Unit Tests

#### Test Structure

```
frontend/src/
├── __tests__/               # Test files
│   ├── components/
│   │   ├── LandingPage.test.js
│   │   ├── Dashboard.test.js
│   │   └── Chat.test.js
│   ├── services/
│   │   └── api.test.js
│   └── utils/
│       └── helpers.test.js
├── __mocks__/               # Mock files
│   └── api.js
└── setupTests.js            # Test setup
```

#### Example Component Tests

```javascript
// frontend/src/__tests__/components/LandingPage.test.js
import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import LandingPage from '../../components/LandingPage';

describe('LandingPage', () => {
  test('renders landing page with correct title', () => {
    render(<LandingPage />);
    
    expect(screen.getByText(/EdGPT/i)).toBeInTheDocument();
    expect(screen.getByText(/AI-Powered Website Intelligence/i)).toBeInTheDocument();
  });
  
  test('opens trial signup modal when CTA clicked', () => {
    render(<LandingPage />);
    
    const ctaButton = screen.getByText(/Start Free Trial/i);
    fireEvent.click(ctaButton);
    
    expect(screen.getByText(/Start Your Free Trial/i)).toBeInTheDocument();
  });
  
  test('displays correct features for domain', () => {
    const mockDomainConfig = {
      name: 'EdGPT',
      industry: 'education'
    };
    
    render(<LandingPage domainConfig={mockDomainConfig} />);
    
    expect(screen.getByText(/Educational Intelligence/i)).toBeInTheDocument();
  });
});
```

### Running Unit Tests

```bash
# Backend tests
cd backend
pytest tests/ -v --cov=src --cov-report=html

# Frontend tests
cd frontend
npm test -- --coverage --watchAll=false

# Run specific test file
pytest tests/test_models/test_user.py -v
npm test LandingPage.test.js
```

## Integration Testing

### API Integration Tests

```python
# backend/tests/test_integration/test_chat_flow.py
import pytest
from src.models.organization import Organization
from src.models.conversation import Conversation

class TestChatIntegration:
    def test_complete_chat_flow(self, client, app):
        """Test complete chat conversation flow."""
        with app.app_context():
            # Create test organization
            org = Organization(
                name='Test School',
                domain='edgpt',
                status='active'
            )
            org.save()
            
            # Start conversation
            response = client.post('/api/chat/start', json={
                'organization_id': org.id,
                'visitor_name': 'Test User',
                'visitor_email': 'test@example.com'
            })
            
            assert response.status_code == 201
            data = response.json
            conversation_id = data['conversation_id']
            
            # Send message
            response = client.post('/api/chat/message', json={
                'conversation_id': conversation_id,
                'message': 'What are your school hours?'
            })
            
            assert response.status_code == 200
            assert 'response' in response.json
            
            # Check conversation was created
            conversation = Conversation.query.get(conversation_id)
            assert conversation is not None
            assert conversation.message_count >= 2  # Welcome + user message + AI response
```

### Database Integration Tests

```python
# backend/tests/test_integration/test_database.py
import pytest
from src.models.user import User
from src.models.organization import Organization
from src.database import db

class TestDatabaseIntegration:
    def test_user_organization_relationship(self, app):
        """Test user-organization relationship."""
        with app.app_context():
            # Create organization
            org = Organization(name='Test Org', domain='test')
            org.save()
            
            # Create user
            user = User(
                email='test@example.com',
                first_name='Test',
                last_name='User',
                organization_id=org.id
            )
            user.save()
            
            # Test relationship
            assert user.organization == org
            assert user in org.users
            
            # Test cascade delete
            db.session.delete(org)
            db.session.commit()
            
            # User should still exist but organization_id should be None
            user = User.query.get(user.id)
            assert user is not None
            assert user.organization_id is None
```

## End-to-End Testing

### Cypress E2E Tests

#### Test Structure

```
frontend/cypress/
├── fixtures/                # Test data
│   ├── users.json
│   └── organizations.json
├── integration/             # Test files
│   ├── auth.spec.js
│   ├── chat.spec.js
│   ├── dashboard.spec.js
│   └── trial-signup.spec.js
├── plugins/
│   └── index.js
├── support/
│   ├── commands.js
│   └── index.js
└── cypress.json             # Configuration
```

#### Example E2E Tests

```javascript
// frontend/cypress/integration/chat.spec.js
describe('Chat Functionality', () => {
  beforeEach(() => {
    cy.visit('/');
    cy.intercept('POST', '/api/chat/start').as('startChat');
    cy.intercept('POST', '/api/chat/message').as('sendMessage');
  });
  
  it('should start a chat conversation', () => {
    // Click chat button
    cy.get('[data-testid="chat-button"]').click();
    
    // Fill in visitor information
    cy.get('[data-testid="visitor-name"]').type('Test User');
    cy.get('[data-testid="visitor-email"]').type('test@example.com');
    cy.get('[data-testid="start-chat"]').click();
    
    // Wait for chat to start
    cy.wait('@startChat');
    
    // Verify welcome message
    cy.get('[data-testid="chat-messages"]')
      .should('contain', 'Hello! How can I help you today?');
  });
  
  it('should send and receive messages', () => {
    // Start chat first
    cy.startChat();
    
    // Send message
    cy.get('[data-testid="message-input"]')
      .type('What are your school hours?');
    cy.get('[data-testid="send-button"]').click();
    
    // Wait for response
    cy.wait('@sendMessage');
    
    // Verify message appears
    cy.get('[data-testid="chat-messages"]')
      .should('contain', 'What are your school hours?');
    
    // Verify AI response
    cy.get('[data-testid="chat-messages"]')
      .should('contain', 'Our school hours are');
  });
  
  it('should handle escalation to human', () => {
    cy.startChat();
    
    // Send escalation trigger
    cy.get('[data-testid="message-input"]')
      .type('I need to speak to a human');
    cy.get('[data-testid="send-button"]').click();
    
    // Verify escalation message
    cy.get('[data-testid="chat-messages"]')
      .should('contain', 'I\'ve notified our staff');
  });
});

// Custom commands
// frontend/cypress/support/commands.js
Cypress.Commands.add('startChat', () => {
  cy.get('[data-testid="chat-button"]').click();
  cy.get('[data-testid="visitor-name"]').type('Test User');
  cy.get('[data-testid="visitor-email"]').type('test@example.com');
  cy.get('[data-testid="start-chat"]').click();
  cy.wait('@startChat');
});

Cypress.Commands.add('login', (email, password) => {
  cy.visit('/login');
  cy.get('[data-testid="email"]').type(email);
  cy.get('[data-testid="password"]').type(password);
  cy.get('[data-testid="login-button"]').click();
});
```

### Running E2E Tests

```bash
# Open Cypress Test Runner
npx cypress open

# Run tests headlessly
npx cypress run

# Run specific test file
npx cypress run --spec "cypress/integration/chat.spec.js"

# Run tests in different browsers
npx cypress run --browser chrome
npx cypress run --browser firefox
```

## API Testing

### Postman Collection Testing

```json
{
  "info": {
    "name": "EdGPT API Tests",
    "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
  },
  "item": [
    {
      "name": "Authentication",
      "item": [
        {
          "name": "Login",
          "event": [
            {
              "listen": "test",
              "script": {
                "exec": [
                  "pm.test('Login successful', function () {",
                  "    pm.response.to.have.status(200);",
                  "    pm.expect(pm.response.json()).to.have.property('access_token');",
                  "});",
                  "",
                  "if (pm.response.code === 200) {",
                  "    pm.environment.set('access_token', pm.response.json().access_token);",
                  "}"
                ]
              }
            }
          ],
          "request": {
            "method": "POST",
            "header": [
              {
                "key": "Content-Type",
                "value": "application/json"
              }
            ],
            "body": {
              "mode": "raw",
              "raw": "{\n  \"email\": \"{{test_email}}\",\n  \"password\": \"{{test_password}}\"\n}"
            },
            "url": {
              "raw": "{{base_url}}/api/auth/login",
              "host": ["{{base_url}}"],
              "path": ["api", "auth", "login"]
            }
          }
        }
      ]
    }
  ]
}
```

### Custom API Test Scripts

```python
# tests/api_tests.py
import requests
import pytest
import json

class TestEdGPTAPI:
    def __init__(self):
        self.base_url = 'http://localhost:5000/api'
        self.access_token = None
    
    def setup_method(self):
        """Setup for each test method."""
        self.login()
    
    def login(self):
        """Login and get access token."""
        response = requests.post(f'{self.base_url}/auth/login', json={
            'email': 'test@example.com',
            'password': 'testpassword'
        })
        
        assert response.status_code == 200
        self.access_token = response.json()['access_token']
    
    def get_headers(self):
        """Get authentication headers."""
        return {
            'Authorization': f'Bearer {self.access_token}',
            'Content-Type': 'application/json'
        }
    
    def test_chat_flow(self):
        """Test complete chat flow."""
        # Start conversation
        response = requests.post(f'{self.base_url}/chat/start', json={
            'organization_id': 'test-org-id',
            'visitor_name': 'Test User'
        })
        
        assert response.status_code == 201
        conversation_id = response.json()['conversation_id']
        
        # Send message
        response = requests.post(f'{self.base_url}/chat/message', json={
            'conversation_id': conversation_id,
            'message': 'Hello, I need help'
        })
        
        assert response.status_code == 200
        assert 'response' in response.json()
    
    def test_knowledge_management(self):
        """Test knowledge base management."""
        headers = self.get_headers()
        
        # Create knowledge item
        response = requests.post(f'{self.base_url}/knowledge', 
            headers=headers,
            json={
                'title': 'Test Knowledge',
                'content': 'This is test content',
                'category': 'general'
            }
        )
        
        assert response.status_code == 201
        item_id = response.json()['id']
        
        # Get knowledge item
        response = requests.get(f'{self.base_url}/knowledge/{item_id}', 
            headers=headers
        )
        
        assert response.status_code == 200
        assert response.json()['title'] == 'Test Knowledge'
        
        # Update knowledge item
        response = requests.put(f'{self.base_url}/knowledge/{item_id}',
            headers=headers,
            json={'title': 'Updated Knowledge'}
        )
        
        assert response.status_code == 200
        
        # Delete knowledge item
        response = requests.delete(f'{self.base_url}/knowledge/{item_id}',
            headers=headers
        )
        
        assert response.status_code == 204
```

## Performance Testing

### Load Testing with Artillery

```yaml
# artillery-config.yml
config:
  target: 'http://localhost:5000'
  phases:
    - duration: 60
      arrivalRate: 10
      name: "Warm up"
    - duration: 120
      arrivalRate: 50
      name: "Ramp up load"
    - duration: 300
      arrivalRate: 100
      name: "Sustained load"

scenarios:
  - name: "Chat conversation flow"
    weight: 70
    flow:
      - post:
          url: "/api/chat/start"
          json:
            organization_id: "test-org-id"
            visitor_name: "Load Test User"
          capture:
            - json: "$.conversation_id"
              as: "conversationId"
      - post:
          url: "/api/chat/message"
          json:
            conversation_id: "{{ conversationId }}"
            message: "What are your hours?"
  
  - name: "API authentication"
    weight: 20
    flow:
      - post:
          url: "/api/auth/login"
          json:
            email: "test@example.com"
            password: "testpassword"
          capture:
            - json: "$.access_token"
              as: "token"
      - get:
          url: "/api/users/me"
          headers:
            Authorization: "Bearer {{ token }}"
  
  - name: "Knowledge base queries"
    weight: 10
    flow:
      - get:
          url: "/api/knowledge"
          qs:
            page: 1
            per_page: 20
```

### Running Performance Tests

```bash
# Install Artillery
npm install -g artillery

# Run load test
artillery run artillery-config.yml

# Generate HTML report
artillery run artillery-config.yml --output report.json
artillery report report.json

# Quick test
artillery quick --duration 60 --rate 10 http://localhost:5000/api/health
```

### Database Performance Testing

```python
# tests/performance/test_database.py
import time
import pytest
from src.models.conversation import Conversation
from src.models.message import Message

class TestDatabasePerformance:
    def test_conversation_creation_performance(self, app):
        """Test conversation creation performance."""
        with app.app_context():
            start_time = time.time()
            
            # Create 1000 conversations
            conversations = []
            for i in range(1000):
                conv = Conversation(
                    organization_id='test-org',
                    visitor_name=f'User {i}',
                    visitor_email=f'user{i}@example.com'
                )
                conversations.append(conv)
            
            # Bulk insert
            db.session.bulk_save_objects(conversations)
            db.session.commit()
            
            end_time = time.time()
            duration = end_time - start_time
            
            # Should create 1000 conversations in less than 5 seconds
            assert duration < 5.0
            print(f"Created 1000 conversations in {duration:.2f} seconds")
    
    def test_message_query_performance(self, app):
        """Test message query performance."""
        with app.app_context():
            # Create test data
            conv = Conversation(organization_id='test-org')
            conv.save()
            
            # Add 1000 messages
            for i in range(1000):
                msg = Message(
                    conversation_id=conv.id,
                    content=f'Message {i}',
                    message_type='user'
                )
                msg.save()
            
            # Test query performance
            start_time = time.time()
            
            messages = Message.query.filter_by(
                conversation_id=conv.id
            ).order_by(Message.created_at.desc()).limit(50).all()
            
            end_time = time.time()
            duration = end_time - start_time
            
            # Should query 50 messages from 1000 in less than 0.1 seconds
            assert duration < 0.1
            assert len(messages) == 50
```

## Security Testing

### Automated Security Scanning

```bash
# Install security tools
pip install bandit safety
npm install -g retire

# Backend security scan
bandit -r backend/src/

# Check for known vulnerabilities
safety check

# Frontend security scan
retire --path frontend/

# Docker security scan
docker run --rm -v /var/run/docker.sock:/var/run/docker.sock \
  aquasec/trivy image edgpt_backend_prod
```

### Security Test Cases

```python
# tests/security/test_auth_security.py
import pytest
import jwt
from src.models.user import User

class TestAuthSecurity:
    def test_password_strength_requirements(self, client):
        """Test password strength requirements."""
        weak_passwords = [
            '123456',
            'password',
            'abc123',
            'qwerty'
        ]
        
        for password in weak_passwords:
            response = client.post('/api/auth/register', json={
                'email': 'test@example.com',
                'password': password,
                'first_name': 'Test',
                'last_name': 'User'
            })
            
            assert response.status_code == 400
            assert 'password' in response.json['error'].lower()
    
    def test_jwt_token_security(self, client, app):
        """Test JWT token security."""
        # Login to get token
        response = client.post('/api/auth/login', json={
            'email': 'test@example.com',
            'password': 'ValidPassword123!'
        })
        
        token = response.json['access_token']
        
        # Test token structure
        decoded = jwt.decode(token, options={"verify_signature": False})
        assert 'exp' in decoded  # Token should have expiration
        assert 'iat' in decoded  # Token should have issued at
        
        # Test expired token
        with app.app_context():
            expired_token = jwt.encode({
                'user_id': 'test-user',
                'exp': 1234567890  # Past timestamp
            }, app.config['JWT_SECRET_KEY'])
            
            response = client.get('/api/users/me', headers={
                'Authorization': f'Bearer {expired_token}'
            })
            
            assert response.status_code == 401
    
    def test_sql_injection_protection(self, client):
        """Test SQL injection protection."""
        malicious_inputs = [
            "'; DROP TABLE users; --",
            "' OR '1'='1",
            "admin'--",
            "' UNION SELECT * FROM users --"
        ]
        
        for malicious_input in malicious_inputs:
            response = client.post('/api/auth/login', json={
                'email': malicious_input,
                'password': 'password'
            })
            
            # Should return 401 (invalid credentials) not 500 (server error)
            assert response.status_code == 401
    
    def test_rate_limiting(self, client):
        """Test rate limiting protection."""
        # Attempt multiple failed logins
        for i in range(10):
            response = client.post('/api/auth/login', json={
                'email': 'test@example.com',
                'password': 'wrongpassword'
            })
        
        # Should be rate limited after multiple attempts
        response = client.post('/api/auth/login', json={
            'email': 'test@example.com',
            'password': 'wrongpassword'
        })
        
        assert response.status_code == 429  # Too Many Requests
```

### OWASP ZAP Security Testing

```bash
# Start ZAP daemon
docker run -u zap -p 8080:8080 -i owasp/zap2docker-stable zap.sh -daemon \
  -host 0.0.0.0 -port 8080 -config api.addrs.addr.name=.* \
  -config api.addrs.addr.regex=true

# Run baseline scan
docker run -v $(pwd):/zap/wrk/:rw -t owasp/zap2docker-stable \
  zap-baseline.py -t http://localhost:5000 -g gen.conf -r testreport.html

# Run full scan
docker run -v $(pwd):/zap/wrk/:rw -t owasp/zap2docker-stable \
  zap-full-scan.py -t http://localhost:5000 -g gen.conf -r fullreport.html
```

## Manual Testing

### Test Scenarios

#### User Registration and Authentication

1. **Valid Registration**
   - Navigate to registration page
   - Fill in valid information
   - Verify email confirmation
   - Test login with new credentials

2. **Invalid Registration**
   - Test with invalid email formats
   - Test with weak passwords
   - Test with existing email
   - Verify error messages

3. **Password Reset**
   - Request password reset
   - Check email delivery
   - Reset password with valid token
   - Test login with new password

#### Chat Functionality

1. **Basic Chat Flow**
   - Start new conversation
   - Send various types of messages
   - Verify AI responses
   - Test conversation persistence

2. **Edge Cases**
   - Very long messages
   - Special characters and emojis
   - Multiple rapid messages
   - Network interruption scenarios

3. **Escalation Testing**
   - Trigger human escalation
   - Verify escalation notifications
   - Test human agent takeover

#### Multi-Domain Testing

1. **Domain-Specific Content**
   - Test each domain (EdGPT, GPTsites, etc.)
   - Verify domain-specific AI personalities
   - Check domain-specific features

2. **Cross-Domain Functionality**
   - Test domain switching
   - Verify isolated data
   - Check shared infrastructure

### Browser Compatibility Testing

Test on multiple browsers and devices:

- **Desktop Browsers**
  - Chrome (latest)
  - Firefox (latest)
  - Safari (latest)
  - Edge (latest)

- **Mobile Browsers**
  - Chrome Mobile
  - Safari Mobile
  - Samsung Internet

- **Devices**
  - Desktop (1920x1080, 1366x768)
  - Tablet (768x1024)
  - Mobile (375x667, 414x896)

### Accessibility Testing

```bash
# Install accessibility testing tools
npm install -g @axe-core/cli lighthouse

# Run accessibility audit
axe http://localhost:3000

# Run Lighthouse audit
lighthouse http://localhost:3000 --only-categories=accessibility

# Manual accessibility checks
# - Keyboard navigation
# - Screen reader compatibility
# - Color contrast
# - Focus indicators
# - Alt text for images
```

## Deployment Testing

### Pre-Deployment Checklist

- [ ] All tests passing
- [ ] Security scan completed
- [ ] Performance benchmarks met
- [ ] Database migrations tested
- [ ] Environment variables configured
- [ ] SSL certificates valid
- [ ] Backup procedures tested
- [ ] Monitoring configured

### Deployment Verification

```bash
# Test deployment script
./install.sh --dev --skip-docker -d localhost --no-ssl

# Verify services
docker-compose -f docker-compose.production.yml ps

# Test health endpoints
curl http://localhost/health
curl http://localhost:5000/health

# Test API endpoints
curl -X POST http://localhost:5000/api/chat/start \
  -H "Content-Type: application/json" \
  -d '{"organization_id":"test-org","visitor_name":"Test"}'

# Test frontend
curl http://localhost:3000
```

### Production Smoke Tests

```python
# tests/smoke/test_production.py
import requests
import pytest

class TestProductionSmoke:
    def __init__(self, base_url):
        self.base_url = base_url
    
    def test_health_endpoints(self):
        """Test health endpoints are responding."""
        endpoints = [
            '/health',
            '/api/health'
        ]
        
        for endpoint in endpoints:
            response = requests.get(f'{self.base_url}{endpoint}')
            assert response.status_code == 200
    
    def test_ssl_certificate(self):
        """Test SSL certificate is valid."""
        if self.base_url.startswith('https'):
            response = requests.get(self.base_url)
            assert response.status_code in [200, 301, 302]
    
    def test_basic_functionality(self):
        """Test basic chat functionality."""
        response = requests.post(f'{self.base_url}/api/chat/start', json={
            'organization_id': 'test-org',
            'visitor_name': 'Smoke Test'
        })
        
        assert response.status_code == 201
        assert 'conversation_id' in response.json()

# Run smoke tests
if __name__ == '__main__':
    import sys
    base_url = sys.argv[1] if len(sys.argv) > 1 else 'http://localhost'
    
    smoke_tests = TestProductionSmoke(base_url)
    smoke_tests.test_health_endpoints()
    smoke_tests.test_ssl_certificate()
    smoke_tests.test_basic_functionality()
    
    print("✅ All smoke tests passed!")
```

## Continuous Integration

### GitHub Actions Workflow

```yaml
# .github/workflows/test.yml
name: Test Suite

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]

jobs:
  backend-tests:
    runs-on: ubuntu-latest
    
    services:
      postgres:
        image: postgres:13
        env:
          POSTGRES_PASSWORD: postgres
          POSTGRES_DB: test_db
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
      
      redis:
        image: redis:6
        options: >-
          --health-cmd "redis-cli ping"
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
    
    steps:
    - uses: actions/checkout@v2
    
    - name: Set up Python
      uses: actions/setup-python@v2
      with:
        python-version: 3.11
    
    - name: Install dependencies
      run: |
        cd backend
        pip install -r requirements.txt
    
    - name: Run tests
      run: |
        cd backend
        pytest tests/ -v --cov=src --cov-report=xml
      env:
        DATABASE_URL: postgresql://postgres:postgres@localhost/test_db
        REDIS_URL: redis://localhost:6379/0
    
    - name: Upload coverage
      uses: codecov/codecov-action@v1
      with:
        file: ./backend/coverage.xml

  frontend-tests:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v2
    
    - name: Set up Node.js
      uses: actions/setup-node@v2
      with:
        node-version: '18'
    
    - name: Install dependencies
      run: |
        cd frontend
        npm ci
    
    - name: Run tests
      run: |
        cd frontend
        npm test -- --coverage --watchAll=false
    
    - name: Run E2E tests
      run: |
        cd frontend
        npm run build
        npm start &
        npx wait-on http://localhost:3000
        npx cypress run

  security-scan:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v2
    
    - name: Run security scan
      run: |
        pip install bandit safety
        bandit -r backend/src/
        safety check -r backend/requirements.txt
```

## Test Reporting

### Coverage Reports

```bash
# Generate coverage reports
pytest --cov=src --cov-report=html --cov-report=term
npm test -- --coverage

# View HTML reports
open backend/htmlcov/index.html
open frontend/coverage/lcov-report/index.html
```

### Test Documentation

Generate test documentation:

```bash
# Generate test documentation
pytest --collect-only --quiet | grep "test_" > test_inventory.txt

# Generate API test documentation
postman-to-openapi postman_collection.json > api_tests.yaml
```

## Conclusion

This testing guide provides comprehensive coverage for the EdGPT platform. Regular execution of these tests ensures:

- **Code Quality**: Unit tests catch bugs early
- **Integration Reliability**: Integration tests verify component interactions
- **User Experience**: E2E tests validate complete workflows
- **Performance**: Load tests ensure scalability
- **Security**: Security tests protect against vulnerabilities
- **Deployment Safety**: Deployment tests verify production readiness

For questions or issues with testing procedures, contact the development team or refer to the project documentation.

