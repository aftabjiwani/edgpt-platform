# EdGPT Platform Production Deployment Configuration
## Phase 2: Production Environment Setup and Configuration

**Author:** Manus AI  
**Date:** July 30, 2025  
**Version:** 1.0  
**Phase:** Production Configuration and Environment Setup

---

## Overview

This document provides comprehensive configuration specifications and implementation guidance for deploying the EdGPT platform to production AWS infrastructure. The configuration encompasses environment variables, security hardening, performance optimization, and operational procedures necessary for stable, scalable production operations.

## Production Environment Variables

The production environment configuration requires careful management of sensitive credentials, API keys, and configuration parameters across multiple services and domains. This section provides complete environment variable specifications with security considerations and management procedures.

### Core Application Configuration

```bash
# Application Environment
NODE_ENV=production
FLASK_ENV=production
FLASK_DEBUG=false
SECRET_KEY=<generated-256-bit-key>
JWT_SECRET_KEY=<generated-256-bit-key>
JWT_ACCESS_TOKEN_EXPIRES=3600
JWT_REFRESH_TOKEN_EXPIRES=2592000

# Database Configuration
DATABASE_URL=postgresql://edgpt_user:<password>@<rds-endpoint>:5432/edgpt_production
DATABASE_POOL_SIZE=20
DATABASE_MAX_OVERFLOW=30
DATABASE_POOL_TIMEOUT=30
DATABASE_POOL_RECYCLE=3600

# Redis Configuration
REDIS_URL=redis://<elasticache-endpoint>:6379/0
REDIS_PASSWORD=<redis-auth-token>
REDIS_SSL=true
REDIS_POOL_SIZE=10
```

### Multi-Domain Configuration

```bash
# Domain Configuration
ALLOWED_DOMAINS=edgpt.ai,gptsites.ai,lawfirmgpt.ai,cpafirm.ai,taxprepgpt.ai,businessbrokergpt.ai
CORS_ORIGINS=https://edgpt.ai,https://gptsites.ai,https://lawfirmgpt.ai,https://cpafirm.ai,https://taxprepgpt.ai,https://businessbrokergpt.ai
COOKIE_DOMAIN=.edgpt.ai
COOKIE_SECURE=true
COOKIE_SAMESITE=Lax

# SSL/TLS Configuration
SSL_REDIRECT=true
HSTS_MAX_AGE=31536000
HSTS_INCLUDE_SUBDOMAINS=true
HSTS_PRELOAD=true
```

### External Service Integration

```bash
# SendGrid Configuration
SENDGRID_API_KEY=<sendgrid-api-key>
FROM_EMAIL=noreply@edgpt.ai
FROM_NAME=EdGPT Team
SENDGRID_WEBHOOK_SECRET=<webhook-secret>

# Stripe Configuration
STRIPE_PUBLIC_KEY=<stripe-public-key>
STRIPE_SECRET_KEY=<stripe-secret-key>
STRIPE_WEBHOOK_SECRET=<webhook-secret>
STRIPE_WEBHOOK_ENDPOINT=https://api.edgpt.ai/webhooks/stripe

# AI Provider Configuration
OPENAI_API_KEY=<openai-api-key>
OPENAI_API_BASE=https://api.openai.com/v1
OPENAI_MODEL=gpt-4o-mini
OPENAI_MAX_TOKENS=2000
OPENAI_TEMPERATURE=0.7

# Ollama Configuration (for local models)
OLLAMA_BASE_URL=http://ollama-service:11434
OLLAMA_MODEL=llama3.2:3b
OLLAMA_TIMEOUT=30
```

### AWS Service Configuration

```bash
# AWS Configuration
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=<iam-access-key>
AWS_SECRET_ACCESS_KEY=<iam-secret-key>
AWS_S3_BUCKET=edgpt-platform-storage
AWS_S3_REGION=us-east-1
AWS_CLOUDFRONT_DOMAIN=cdn.edgpt.ai

# Monitoring and Logging
CLOUDWATCH_LOG_GROUP=/aws/ecs/edgpt-platform
CLOUDWATCH_REGION=us-east-1
XRAY_TRACING_NAME=edgpt-platform
ENABLE_XRAY=true
```

## Infrastructure as Code Configuration

The production deployment utilizes AWS CloudFormation templates to ensure consistent, repeatable infrastructure provisioning with proper version control and change management procedures.

### VPC and Network Configuration

```yaml
# vpc-template.yaml
AWSTemplateFormatVersion: '2010-09-09'
Description: 'EdGPT Platform VPC and Network Infrastructure'

Parameters:
  Environment:
    Type: String
    Default: production
    AllowedValues: [development, staging, production]
  
  VpcCidr:
    Type: String
    Default: '10.0.0.0/16'
    Description: 'CIDR block for VPC'

Resources:
  VPC:
    Type: AWS::EC2::VPC
    Properties:
      CidrBlock: !Ref VpcCidr
      EnableDnsHostnames: true
      EnableDnsSupport: true
      Tags:
        - Key: Name
          Value: !Sub '${Environment}-edgpt-vpc'
        - Key: Environment
          Value: !Ref Environment

  PublicSubnet1:
    Type: AWS::EC2::Subnet
    Properties:
      VpcId: !Ref VPC
      CidrBlock: '10.0.1.0/24'
      AvailabilityZone: !Select [0, !GetAZs '']
      MapPublicIpOnLaunch: true
      Tags:
        - Key: Name
          Value: !Sub '${Environment}-public-subnet-1'

  PublicSubnet2:
    Type: AWS::EC2::Subnet
    Properties:
      VpcId: !Ref VPC
      CidrBlock: '10.0.2.0/24'
      AvailabilityZone: !Select [1, !GetAZs '']
      MapPublicIpOnLaunch: true
      Tags:
        - Key: Name
          Value: !Sub '${Environment}-public-subnet-2'

  PrivateSubnet1:
    Type: AWS::EC2::Subnet
    Properties:
      VpcId: !Ref VPC
      CidrBlock: '10.0.11.0/24'
      AvailabilityZone: !Select [0, !GetAZs '']
      Tags:
        - Key: Name
          Value: !Sub '${Environment}-private-subnet-1'

  PrivateSubnet2:
    Type: AWS::EC2::Subnet
    Properties:
      VpcId: !Ref VPC
      CidrBlock: '10.0.12.0/24'
      AvailabilityZone: !Select [1, !GetAZs '']
      Tags:
        - Key: Name
          Value: !Sub '${Environment}-private-subnet-2'

  DatabaseSubnet1:
    Type: AWS::EC2::Subnet
    Properties:
      VpcId: !Ref VPC
      CidrBlock: '10.0.21.0/24'
      AvailabilityZone: !Select [0, !GetAZs '']
      Tags:
        - Key: Name
          Value: !Sub '${Environment}-database-subnet-1'

  DatabaseSubnet2:
    Type: AWS::EC2::Subnet
    Properties:
      VpcId: !Ref VPC
      CidrBlock: '10.0.22.0/24'
      AvailabilityZone: !Select [1, !GetAZs '']
      Tags:
        - Key: Name
          Value: !Sub '${Environment}-database-subnet-2'
```

### Security Group Configuration

```yaml
# security-groups-template.yaml
Resources:
  ALBSecurityGroup:
    Type: AWS::EC2::SecurityGroup
    Properties:
      GroupDescription: 'Security group for Application Load Balancer'
      VpcId: !ImportValue
        Fn::Sub: '${Environment}-vpc-id'
      SecurityGroupIngress:
        - IpProtocol: tcp
          FromPort: 80
          ToPort: 80
          CidrIp: '0.0.0.0/0'
          Description: 'HTTP traffic'
        - IpProtocol: tcp
          FromPort: 443
          ToPort: 443
          CidrIp: '0.0.0.0/0'
          Description: 'HTTPS traffic'
      Tags:
        - Key: Name
          Value: !Sub '${Environment}-alb-security-group'

  ECSSecurityGroup:
    Type: AWS::EC2::SecurityGroup
    Properties:
      GroupDescription: 'Security group for ECS tasks'
      VpcId: !ImportValue
        Fn::Sub: '${Environment}-vpc-id'
      SecurityGroupIngress:
        - IpProtocol: tcp
          FromPort: 3000
          ToPort: 3000
          SourceSecurityGroupId: !Ref ALBSecurityGroup
          Description: 'Frontend container port'
        - IpProtocol: tcp
          FromPort: 5000
          ToPort: 5000
          SourceSecurityGroupId: !Ref ALBSecurityGroup
          Description: 'Backend container port'
      Tags:
        - Key: Name
          Value: !Sub '${Environment}-ecs-security-group'

  DatabaseSecurityGroup:
    Type: AWS::EC2::SecurityGroup
    Properties:
      GroupDescription: 'Security group for RDS database'
      VpcId: !ImportValue
        Fn::Sub: '${Environment}-vpc-id'
      SecurityGroupIngress:
        - IpProtocol: tcp
          FromPort: 5432
          ToPort: 5432
          SourceSecurityGroupId: !Ref ECSSecurityGroup
          Description: 'PostgreSQL access from ECS'
      Tags:
        - Key: Name
          Value: !Sub '${Environment}-database-security-group'

  CacheSecurityGroup:
    Type: AWS::EC2::SecurityGroup
    Properties:
      GroupDescription: 'Security group for ElastiCache Redis'
      VpcId: !ImportValue
        Fn::Sub: '${Environment}-vpc-id'
      SecurityGroupIngress:
        - IpProtocol: tcp
          FromPort: 6379
          ToPort: 6379
          SourceSecurityGroupId: !Ref ECSSecurityGroup
          Description: 'Redis access from ECS'
      Tags:
        - Key: Name
          Value: !Sub '${Environment}-cache-security-group'
```

## Database Configuration and Optimization

The production database configuration implements performance optimization, security hardening, and backup strategies appropriate for the platform's multi-tenant architecture and compliance requirements.

### RDS PostgreSQL Configuration

```yaml
# database-template.yaml
Resources:
  DatabaseSubnetGroup:
    Type: AWS::RDS::DBSubnetGroup
    Properties:
      DBSubnetGroupDescription: 'Subnet group for EdGPT database'
      SubnetIds:
        - !ImportValue
          Fn::Sub: '${Environment}-database-subnet-1'
        - !ImportValue
          Fn::Sub: '${Environment}-database-subnet-2'
      Tags:
        - Key: Name
          Value: !Sub '${Environment}-database-subnet-group'

  DatabaseParameterGroup:
    Type: AWS::RDS::DBParameterGroup
    Properties:
      Family: postgres15
      Description: 'Parameter group for EdGPT PostgreSQL database'
      Parameters:
        shared_preload_libraries: 'pg_stat_statements'
        log_statement: 'all'
        log_min_duration_statement: 1000
        max_connections: 200
        shared_buffers: '{DBInstanceClassMemory/4}'
        effective_cache_size: '{DBInstanceClassMemory*3/4}'
        maintenance_work_mem: '{DBInstanceClassMemory/16}'
        checkpoint_completion_target: 0.9
        wal_buffers: '16MB'
        default_statistics_target: 100
        random_page_cost: 1.1
        effective_io_concurrency: 200

  Database:
    Type: AWS::RDS::DBInstance
    DeletionPolicy: Snapshot
    Properties:
      DBInstanceIdentifier: !Sub '${Environment}-edgpt-database'
      DBInstanceClass: db.t3.medium
      Engine: postgres
      EngineVersion: '15.4'
      AllocatedStorage: 100
      StorageType: gp3
      StorageEncrypted: true
      KmsKeyId: !ImportValue
        Fn::Sub: '${Environment}-database-kms-key'
      
      DBName: edgpt_production
      MasterUsername: edgpt_admin
      ManageMasterUserPassword: true
      MasterUserSecret:
        Description: 'Master user password for EdGPT database'
        KmsKeyId: !ImportValue
          Fn::Sub: '${Environment}-secrets-kms-key'
      
      VPCSecurityGroups:
        - !ImportValue
          Fn::Sub: '${Environment}-database-security-group'
      DBSubnetGroupName: !Ref DatabaseSubnetGroup
      DBParameterGroupName: !Ref DatabaseParameterGroup
      
      BackupRetentionPeriod: 35
      PreferredBackupWindow: '03:00-04:00'
      PreferredMaintenanceWindow: 'sun:04:00-sun:05:00'
      
      MultiAZ: true
      PubliclyAccessible: false
      DeletionProtection: true
      
      EnablePerformanceInsights: true
      PerformanceInsightsRetentionPeriod: 7
      PerformanceInsightsKMSKeyId: !ImportValue
        Fn::Sub: '${Environment}-database-kms-key'
      
      MonitoringInterval: 60
      MonitoringRoleArn: !GetAtt DatabaseMonitoringRole.Arn
      
      Tags:
        - Key: Name
          Value: !Sub '${Environment}-edgpt-database'
        - Key: Environment
          Value: !Ref Environment
```

### ElastiCache Redis Configuration

```yaml
# cache-template.yaml
Resources:
  CacheSubnetGroup:
    Type: AWS::ElastiCache::SubnetGroup
    Properties:
      Description: 'Subnet group for EdGPT cache'
      SubnetIds:
        - !ImportValue
          Fn::Sub: '${Environment}-private-subnet-1'
        - !ImportValue
          Fn::Sub: '${Environment}-private-subnet-2'

  CacheParameterGroup:
    Type: AWS::ElastiCache::ParameterGroup
    Properties:
      CacheParameterGroupFamily: redis7.x
      Description: 'Parameter group for EdGPT Redis cache'
      Properties:
        maxmemory-policy: allkeys-lru
        timeout: 300
        tcp-keepalive: 60
        maxclients: 1000

  CacheReplicationGroup:
    Type: AWS::ElastiCache::ReplicationGroup
    Properties:
      ReplicationGroupId: !Sub '${Environment}-edgpt-cache'
      Description: 'Redis cache for EdGPT platform'
      
      Engine: redis
      EngineVersion: '7.0'
      CacheNodeType: cache.t3.micro
      NumCacheClusters: 2
      
      CacheParameterGroupName: !Ref CacheParameterGroup
      CacheSubnetGroupName: !Ref CacheSubnetGroup
      SecurityGroupIds:
        - !ImportValue
          Fn::Sub: '${Environment}-cache-security-group'
      
      AtRestEncryptionEnabled: true
      TransitEncryptionEnabled: true
      AuthToken: !Ref CacheAuthToken
      
      AutomaticFailoverEnabled: true
      MultiAZEnabled: true
      
      SnapshotRetentionLimit: 7
      SnapshotWindow: '03:00-05:00'
      PreferredMaintenanceWindow: 'sun:05:00-sun:07:00'
      
      Tags:
        - Key: Name
          Value: !Sub '${Environment}-edgpt-cache'
        - Key: Environment
          Value: !Ref Environment
```

## Application Load Balancer Configuration

The Application Load Balancer configuration implements multi-domain routing, SSL termination, and security features necessary for the platform's production operations.

### ALB and Target Group Configuration

```yaml
# load-balancer-template.yaml
Resources:
  ApplicationLoadBalancer:
    Type: AWS::ElasticLoadBalancingV2::LoadBalancer
    Properties:
      Name: !Sub '${Environment}-edgpt-alb'
      Type: application
      Scheme: internet-facing
      IpAddressType: ipv4
      
      Subnets:
        - !ImportValue
          Fn::Sub: '${Environment}-public-subnet-1'
        - !ImportValue
          Fn::Sub: '${Environment}-public-subnet-2'
      
      SecurityGroups:
        - !ImportValue
          Fn::Sub: '${Environment}-alb-security-group'
      
      LoadBalancerAttributes:
        - Key: idle_timeout.timeout_seconds
          Value: '60'
        - Key: routing.http2.enabled
          Value: 'true'
        - Key: access_logs.s3.enabled
          Value: 'true'
        - Key: access_logs.s3.bucket
          Value: !Sub '${Environment}-edgpt-access-logs'
        - Key: deletion_protection.enabled
          Value: 'true'
      
      Tags:
        - Key: Name
          Value: !Sub '${Environment}-edgpt-alb'
        - Key: Environment
          Value: !Ref Environment

  FrontendTargetGroup:
    Type: AWS::ElasticLoadBalancingV2::TargetGroup
    Properties:
      Name: !Sub '${Environment}-frontend-tg'
      Port: 3000
      Protocol: HTTP
      TargetType: ip
      VpcId: !ImportValue
        Fn::Sub: '${Environment}-vpc-id'
      
      HealthCheckEnabled: true
      HealthCheckPath: /health
      HealthCheckProtocol: HTTP
      HealthCheckIntervalSeconds: 30
      HealthCheckTimeoutSeconds: 5
      HealthyThresholdCount: 2
      UnhealthyThresholdCount: 3
      
      TargetGroupAttributes:
        - Key: deregistration_delay.timeout_seconds
          Value: '30'
        - Key: stickiness.enabled
          Value: 'false'
      
      Tags:
        - Key: Name
          Value: !Sub '${Environment}-frontend-target-group'

  BackendTargetGroup:
    Type: AWS::ElasticLoadBalancingV2::TargetGroup
    Properties:
      Name: !Sub '${Environment}-backend-tg'
      Port: 5000
      Protocol: HTTP
      TargetType: ip
      VpcId: !ImportValue
        Fn::Sub: '${Environment}-vpc-id'
      
      HealthCheckEnabled: true
      HealthCheckPath: /api/health
      HealthCheckProtocol: HTTP
      HealthCheckIntervalSeconds: 30
      HealthCheckTimeoutSeconds: 5
      HealthyThresholdCount: 2
      UnhealthyThresholdCount: 3
      
      TargetGroupAttributes:
        - Key: deregistration_delay.timeout_seconds
          Value: '30'
        - Key: stickiness.enabled
          Value: 'true'
        - Key: stickiness.type
          Value: 'lb_cookie'
        - Key: stickiness.lb_cookie.duration_seconds
          Value: '86400'
      
      Tags:
        - Key: Name
          Value: !Sub '${Environment}-backend-target-group'
```

### SSL Certificate and Domain Configuration

```yaml
# ssl-certificate-template.yaml
Resources:
  SSLCertificate:
    Type: AWS::CertificateManager::Certificate
    Properties:
      DomainName: '*.edgpt.ai'
      SubjectAlternativeNames:
        - 'edgpt.ai'
        - '*.gptsites.ai'
        - 'gptsites.ai'
        - '*.lawfirmgpt.ai'
        - 'lawfirmgpt.ai'
        - '*.cpafirm.ai'
        - 'cpafirm.ai'
        - '*.taxprepgpt.ai'
        - 'taxprepgpt.ai'
        - '*.businessbrokergpt.ai'
        - 'businessbrokergpt.ai'
      ValidationMethod: DNS
      DomainValidationOptions:
        - DomainName: '*.edgpt.ai'
          HostedZoneId: !Ref HostedZone
        - DomainName: '*.gptsites.ai'
          HostedZoneId: !Ref GPTSitesHostedZone
        - DomainName: '*.lawfirmgpt.ai'
          HostedZoneId: !Ref LawFirmGPTHostedZone
        - DomainName: '*.cpafirm.ai'
          HostedZoneId: !Ref CPAFirmHostedZone
        - DomainName: '*.taxprepgpt.ai'
          HostedZoneId: !Ref TaxPrepGPTHostedZone
        - DomainName: '*.businessbrokergpt.ai'
          HostedZoneId: !Ref BusinessBrokerGPTHostedZone
      
      Tags:
        - Key: Name
          Value: !Sub '${Environment}-edgpt-ssl-certificate'
        - Key: Environment
          Value: !Ref Environment
```

---

