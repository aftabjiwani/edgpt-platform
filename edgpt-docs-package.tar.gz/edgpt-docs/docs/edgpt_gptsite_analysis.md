# EdGPT.ai GPTsite Layout Analysis

## Complete Layout Structure

### Header Section
- **EdGPT Logo** (top left) with tagline "See your AI school receptionist in action"
- **Back to Home** button (top right)
- **Live AI Demonstrations** badge/indicator

### Main Hero Section
- **Large Headline**: "See Your AI School Receptionist Convert Visitors into Engaged Families"
- **Subheading**: Watch realistic conversations showing exactly how your school AI assistant will help visitors get instant answers, feel understood, and naturally convert into qualified families and inquiries 24/7.

### Three Feature Cards
1. **Natural Conversations** - AI understands context and provides helpful, human-like responses with professional voice
2. **Industry Expertise** - Each demo shows domain-specific knowledge for your exact business type and industry  
3. **Lead Generation** - Watch how visitors naturally provide contact information and book consultations

### Call-to-Action Section
- **Headline**: "Get Complete Enhancement to Transfer your website to EdGPT now"
- **Subtext**: Experience natural two-way voice conversations with your intelligent website assistant - speak your questions and receive human-like voice responses

### Main GPTsite Demo Interface
**Header Bar (Purple/Blue Gradient)**:
- **School Logo** (left side) with house icon
- **School Name**: "Riverside Elementary School" 
- **Tagline**: "Home of the Eagles"
- **School Logo Placeholder** (right side) with eagle icon

**Navigation Buttons** (colored tabs):
- About (green)
- Lunch Menu (blue) 
- Enrollment (orange)
- Calendar (purple)
- Staff (blue)
- Parents (purple)

**Main Content Area**:
- **Welcome Message**: "Welcome to Riverside Elementary"
- **Description**: "We provide an exceptional learning environment where every student can reach their full potential. Our dedicated staff and supportive community create opportunities for academic excellence and personal growth."

**AI Chat Interface**:
- **AI Avatar**: Circular purple avatar with "AI" text
- **AI Name**: "EdGPT Assistant"
- **AI Tagline**: "Ask me anything about our school!"
- **Voice Controls**: 
  - Voice On/Off toggle (blue)
  - Start Live button (orange)
  - Start Auto Demo button (green)
- **Chat Input**: Text input field with "Type your question here..." placeholder
- **Send Button**: Purple send button

**Footer Contact Info**:
- **School Name**: Riverside Elementary School
- **Address**: 123 Education Drive, Learning City, ST 12345
- **Contact**: Phone: (555) 123-4567 | Email: info@riverside-elementary.edu

### Benefits Section (Dark Purple Gradient Background)
**Main Headline**: "Why Your School Needs an AI Receptionist"
**Subheading**: Transform your website from a static brochure into an intelligent school receptionist that works 24/7 to convert visitors into engaged families and prospective students.

**Six Benefit Cards** (in grid layout):
1. **40% More Inquiries** - AI receptionists capture family inquiries that would otherwise leave your website without contacting you
2. **24/7 Availability** - Never miss a potential family - your AI receptionist works around the clock
3. **Instant Responses** - No more waiting for callbacks - families get immediate answers to their questions
4. **Better Support** - AI pre-qualifies inquiries and gathers key information before families contact your staff
5. **Professional Image** - Show families you're innovative and student-focused with cutting-edge technology
6. **Easy Setup** - Your AI receptionist learns from your existing website content and goes live in 48 hours

### Final CTA Section
- **Headline**: "Ready to Transform Your Website?"
- **Text**: Get your own AI assistant that provides this level of intelligent, personalized help to every visitor on your website.

## Design Elements to Clone

### Color Scheme
- **Primary**: Purple/Blue gradient (#7C3AED to #3B82F6)
- **Accent Colors**: Green, Orange, Blue for navigation buttons
- **Background**: White main area, dark purple gradient for benefits
- **Text**: Dark gray/black for main content, white for dark sections

### Typography
- **Headlines**: Large, bold sans-serif
- **Body Text**: Clean, readable sans-serif
- **Button Text**: Medium weight, clear

### Layout Structure
- **Full-width header** with logo and navigation
- **Centered content** with max-width container
- **Card-based design** for features and benefits
- **Prominent chat interface** as main focal point
- **Gradient backgrounds** for visual appeal

### Interactive Elements
- **Colored navigation tabs** with hover effects
- **Voice control buttons** with distinct styling
- **Chat input field** with placeholder text
- **Send button** with brand colors
- **Benefit cards** with icons and descriptions

This layout should be cloned for all 6 domains with domain-specific:
- Colors and branding
- Navigation button labels
- Content and messaging
- Contact information
- Industry-specific benefits

